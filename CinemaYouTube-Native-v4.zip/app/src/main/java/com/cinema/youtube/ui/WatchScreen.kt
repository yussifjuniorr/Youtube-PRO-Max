package com.cinema.youtube.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.media.AudioManager
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.ClosedCaptionOff
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.rounded.ThumbUpOffAlt
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.cinema.youtube.data.AdBlockEngine
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.GoogleSession
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay
import org.json.JSONObject

private enum class TabletWatchTab { UP_NEXT, COMMENTS, DETAILS }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WatchScreen(
    video: VideoItem,
    initialPositionSec: Long,
    gl: String,
    hl: String,
    session: GoogleSession?,
    isTablet: Boolean,
    isLandscape: Boolean,
    isInPipMode: Boolean,
    isLiked: Boolean,
    isSubscribed: (String) -> Boolean,
    playlists: List<UserPlaylist>,
    onToggleLike: (String) -> Unit,
    onSetLandscape: (Boolean) -> Unit,
    onEnterPip: () -> Unit,
    onBack: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onToggleVideoInPlaylist: (String, VideoItem) -> Unit,
    onSaveProgress: (VideoItem, Long, Long) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    var details by remember(video.id) { mutableStateOf<VideoDetails?>(null) }
    var comments by remember(video.id) { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsLoaded by remember(video.id) { mutableStateOf(false) }

    // Real-time Native Player State synced from Pure Video Engine
    var playerReady by remember(video.id) { mutableStateOf(false) }
    var isPlaying by remember(video.id) { mutableStateOf(false) }
    var isBuffering by remember(video.id) { mutableStateOf(true) }
    var positionMs by remember(video.id) { mutableLongStateOf(initialPositionSec * 1000L) }
    var durationMs by remember(video.id) { mutableLongStateOf(0L) }
    var bufferedMs by remember(video.id) { mutableLongStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var sliderFraction by remember(video.id) { mutableFloatStateOf(0f) }

    var currentQualityKey by remember(video.id) { mutableStateOf("auto") }
    var availableQualities by remember(video.id) { mutableStateOf<List<String>>(emptyList()) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var isBoost2x by remember { mutableStateOf(false) }
    var ccAvailable by remember(video.id) { mutableStateOf(false) }
    var ccEnabled by remember(video.id) { mutableStateOf(false) }
    var isZoomFill by remember { mutableStateOf(false) }

    var showControls by remember(video.id) { mutableStateOf(true) }
    var showPlayerSettings by remember { mutableStateOf(false) }
    var showCommentsSheet by remember(video.id) { mutableStateOf(false) }
    var showDescriptionSheet by remember(video.id) { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var tabletTab by remember { mutableStateOf(TabletWatchTab.UP_NEXT) }
    var reloadNonce by remember(video.id) { mutableIntStateOf(0) }
    var useFallbackThumb by remember(video.id) { mutableStateOf(false) }

    // Gesture overlays
    var doubleTapSide by remember { mutableIntStateOf(0) } // -1 left, +1 right
    var doubleTapSeconds by remember { mutableIntStateOf(0) }
    var doubleTapNonce by remember { mutableIntStateOf(0) }

    var gestureType by remember { mutableIntStateOf(0) } // 1 brightness, 2 volume
    var gesturePercent by remember { mutableFloatStateOf(0.5f) }
    var gestureNonce by remember { mutableIntStateOf(0) }

    val latestVideo by rememberUpdatedState(video)
    val latestDetails by rememberUpdatedState(details)
    val latestOnSaveProgress by rememberUpdatedState(onSaveProgress)
    val latestOnOpenVideo by rememberUpdatedState(onOpenVideo)
    val latestIsSeeking by rememberUpdatedState(isSeeking)

    LaunchedEffect(doubleTapNonce) {
        if (doubleTapNonce > 0) {
            delay(800)
            doubleTapSide = 0
            doubleTapSeconds = 0
        }
    }

    LaunchedEffect(gestureNonce) {
        if (gestureNonce > 0) {
            delay(750)
            gestureType = 0
        }
    }

    // Auto-hide controls after 3.2s when playing
    LaunchedEffect(showControls, isPlaying, isSeeking, showPlayerSettings, playerReady) {
        if (showControls && isPlaying && playerReady && !isSeeking && !showPlayerSettings) {
            delay(3200)
            showControls = false
        }
    }

    // Persistent FrameLayout + Invisible-Chrome Hardware-Accelerated WebView (survives rotation!)
    val playerContainer = remember(context) {
        FrameLayout(context).apply {
            setBackgroundColor(AndroidColor.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }

    var lastSavedTickMs by remember(video.id) { mutableLongStateOf(0L) }

    val webView = remember(context) {
        WebView(context).apply {
            setBackgroundColor(AndroidColor.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36"

            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            addJavascriptInterface(
                object {
                    @JavascriptInterface
                    fun onState(jsonStr: String) {
                        post {
                            try {
                                val o = JSONObject(jsonStr)
                                val ready = o.optBoolean("ready", false)
                                val playing = o.optBoolean("playing", false)
                                val buffering = o.optBoolean("buffering", true)
                                val pos = o.optLong("posMs", 0L).coerceAtLeast(0L)
                                val dur = o.optLong("durMs", 0L).coerceAtLeast(0L)
                                val buf = o.optLong("bufMs", 0L).coerceAtLeast(0L)
                                val q = o.optString("quality", "auto")
                                val ccAv = o.optBoolean("ccAvailable", false)
                                val ccOn = o.optBoolean("ccEnabled", false)

                                if (ready) playerReady = true
                                isPlaying = playing
                                isBuffering = buffering
                                durationMs = dur
                                bufferedMs = buf
                                if (!latestIsSeeking) {
                                    positionMs = pos
                                    sliderFraction = if (dur > 0L) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f
                                }
                                if (q.isNotBlank() && q != "unknown") {
                                    currentQualityKey = q
                                }
                                ccAvailable = ccAv
                                ccEnabled = ccOn

                                val qArr = o.optJSONArray("qualities")
                                if (qArr != null && qArr.length() > 0) {
                                    val list = mutableListOf<String>()
                                    for (i in 0 until qArr.length()) {
                                        val lv = qArr.optString(i)
                                        if (lv.isNotBlank() && lv != "unknown" && !list.contains(lv)) {
                                            list.add(lv)
                                        }
                                    }
                                    if (list.isNotEmpty()) availableQualities = list
                                }

                                // Persist Continue Watching every ~6s
                                val now = System.currentTimeMillis()
                                if (ready && playing && dur > 5000L && now - lastSavedTickMs > 6000L) {
                                    lastSavedTickMs = now
                                    val d = latestDetails
                                    val v = latestVideo
                                    val enriched = v.copy(
                                        title = d?.title?.ifBlank { v.title } ?: v.title,
                                        channelName = d?.channelName?.ifBlank { v.channelName } ?: v.channelName,
                                        channelId = d?.channelId?.ifBlank { v.channelId } ?: v.channelId,
                                        channelAvatar = d?.channelAvatar?.ifBlank { v.channelAvatar } ?: v.channelAvatar
                                    )
                                    latestOnSaveProgress(enriched, pos, dur)
                                }
                            } catch (_: Exception) {
                            }
                        }
                    }

                    @JavascriptInterface
                    fun onVideoEnded() {
                        post {
                            val next = latestDetails?.relatedVideos?.firstOrNull()
                            if (next != null) {
                                latestOnOpenVideo(next)
                            }
                        }
                    }
                },
                "CinemaBridge"
            )
        }
    }

    fun runJs(cmd: String) {
        webView.evaluateJavascript(cmd, null)
    }

    // Attach WebView & enforce AdBlock + Pure Surface Injection
    DisposableEffect(webView, playerContainer) {
        if (webView.parent == null) {
            playerContainer.addView(webView)
        }

        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                if (AdBlockEngine.isAdRequest(request?.url)) {
                    return AdBlockEngine.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: ""
                if (scheme != "http" && scheme != "https") return true
                val host = uri.host?.lowercase() ?: ""
                return !(host.contains("youtube.com") || host.contains("google.com"))
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                view?.evaluateJavascript(AdBlockEngine.PURE_VIDEO_ENGINE_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(AdBlockEngine.PURE_VIDEO_ENGINE_JS, null)
                view?.evaluateJavascript("window.__cinemaCmd && window.__cinemaCmd.setSpeed($playbackSpeed);", null)
                view?.evaluateJavascript("window.__cinemaCmd && window.__cinemaCmd.setZoom($isZoomFill);", null)
            }
        }

        onDispose {
            runCatching {
                webView.evaluateJavascript("window.__cinemaCmd && window.__cinemaCmd.pause();", null)
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.onPause()
                playerContainer.removeAllViews()
                webView.destroy()
            }
        }
    }

    // Save progress when leaving current video
    DisposableEffect(video.id) {
        onDispose {
            if (positionMs > 2000L && durationMs > 5000L) {
                val d = latestDetails
                onSaveProgress(
                    video.copy(
                        title = d?.title?.ifBlank { video.title } ?: video.title,
                        channelName = d?.channelName?.ifBlank { video.channelName } ?: video.channelName,
                        channelId = d?.channelId?.ifBlank { video.channelId } ?: video.channelId,
                        channelAvatar = d?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
                    ),
                    positionMs,
                    durationMs
                )
            }
        }
    }

    // Load video into Pure Video Surface
    LaunchedEffect(video.id, reloadNonce) {
        playerReady = false
        isPlaying = false
        isBuffering = true
        durationMs = 0L
        bufferedMs = 0L
        sliderFraction = 0f
        availableQualities = emptyList()
        val startParam = if (initialPositionSec > 5L) "&t=${initialPositionSec}s" else ""
        webView.loadUrl("https://m.youtube.com/watch?v=${video.id}$startParam")
    }

    // Fetch Native Metadata, Related Videos & Comments
    LaunchedEffect(video.id) {
        details = InnerTubeClient.fetchWatchDetails(video.id, gl, hl, session)
        val token = details?.commentsContinuation
        if (!token.isNullOrBlank()) {
            comments = InnerTubeClient.fetchComments(token, gl, hl)
            commentsLoaded = true
        }
    }

    val displayTitle = details?.title?.ifBlank { video.title } ?: video.title
    val displayChannel = details?.channelName?.ifBlank { video.channelName } ?: video.channelName
    val displayChannelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId
    val displayAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
    val relatedVideos = details?.relatedVideos ?: emptyList()

    fun shareCurrentVideo() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, displayTitle)
            putExtra(Intent.EXTRA_TEXT, "$displayTitle\nhttps://youtu.be/${video.id}")
        }
        runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share video")) }
    }

    // ---------- 100% NATIVE CINEMA PRO PLAYER VIEWPORT ----------
    val nativeProPlayerBox: @Composable (Modifier) -> Unit = { boxModifier ->
        Box(
            modifier = boxModifier
                .background(Color.Black)
                .pointerInput(video.id, isInPipMode) {
                    if (isInPipMode) return@pointerInput
                    detectTapGestures(
                        onPress = {
                            tryAwaitRelease()
                            if (isBoost2x) {
                                isBoost2x = false
                                runJs("window.__cinemaCmd && window.__cinemaCmd.setSpeed($playbackSpeed);")
                            }
                        },
                        onLongPress = {
                            if (isPlaying) {
                                isBoost2x = true
                                runJs("window.__cinemaCmd && window.__cinemaCmd.setSpeed(2.0);")
                            }
                        },
                        onTap = {
                            showControls = !showControls
                        },
                        onDoubleTap = { offset ->
                            val isRight = offset.x >= size.width / 2f
                            val deltaSec = if (isRight) 10 else -10
                            runJs("window.__cinemaCmd && window.__cinemaCmd.seekBy($deltaSec);")
                            val side = if (isRight) 1 else -1
                            doubleTapSeconds = if (doubleTapSide == side) doubleTapSeconds + 10 else 10
                            doubleTapSide = side
                            doubleTapNonce++
                        }
                    )
                }
                .pointerInput(video.id, isInPipMode) {
                    if (isInPipMode) return@pointerInput
                    var dragMode = 0
                    var accumDelta = 0f
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            accumDelta = 0f
                            dragMode = when {
                                offset.x < size.width * 0.40f -> 1
                                offset.x > size.width * 0.60f -> 2
                                else -> 0
                            }
                        },
                        onVerticalDrag = { _, dragAmount ->
                            if (dragMode == 1 && activity != null) {
                                val lp = activity.window.attributes
                                val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                val next = (cur - dragAmount / (size.height.coerceAtLeast(300) * 1.1f)).coerceIn(0.05f, 1f)
                                lp.screenBrightness = next
                                activity.window.attributes = lp
                                gestureType = 1
                                gesturePercent = next
                                gestureNonce++
                            } else if (dragMode == 2 && audioManager != null) {
                                accumDelta -= dragAmount
                                val stepPx = (size.height.coerceAtLeast(300) / 16f)
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                var curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                if (kotlin.math.abs(accumDelta) >= stepPx) {
                                    val steps = (accumDelta / stepPx).toInt()
                                    accumDelta -= steps * stepPx
                                    curVol = (curVol + steps).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, curVol, 0)
                                }
                                gestureType = 2
                                gesturePercent = curVol.toFloat() / maxVol.toFloat()
                                gestureNonce++
                            }
                        }
                    )
                }
        ) {
            // Layer 1: Pure Ad-Free Hardware Video Surface (Zero Website Chrome)
            AndroidView(
                factory = {
                    (playerContainer.parent as? ViewGroup)?.removeView(playerContainer)
                    playerContainer
                },
                modifier = Modifier.fillMaxSize()
            )

            // Layer 2: Crisp Video Thumbnail Curtain (completely hides WebView until real video frames are playing!)
            if (!playerReady) {
                AsyncImage(
                    model = if (useFallbackThumb) video.thumbnailUrl else video.heroThumbnailUrl,
                    contentDescription = displayTitle,
                    contentScale = ContentScale.Crop,
                    onError = { useFallbackThumb = true },
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x66000000))
                )
            }

            // In Picture-in-Picture mode, render pure video with zero overlays!
            if (isInPipMode) return@Box

            // Layer 3: Hold-for-2x Speed Floating Pill
            AnimatedVisibility(
                visible = isBoost2x,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
            ) {
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text("2x", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Rounded.FastForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Layer 4: Double-Tap ±10s Seek Feedback Pill
            AnimatedVisibility(
                visible = doubleTapSide != 0,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(if (doubleTapSide < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 28.dp)
            ) {
                Surface(
                    color = Color(0xBA000000),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp)
                    ) {
                        Icon(
                            imageVector = if (doubleTapSide < 0) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Text("${doubleTapSeconds}s", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Layer 5: Brightness / Volume Swipe HUD Pill
            AnimatedVisibility(
                visible = gestureType != 0,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Surface(
                    color = Color(0xCC121216),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp)
                    ) {
                        Icon(
                            imageVector = if (gestureType == 1) Icons.Rounded.Brightness6 else Icons.Rounded.VolumeUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Box(
                            modifier = Modifier
                                .width(105.dp)
                                .height(5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(Color(0x40FFFFFF))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(gesturePercent.coerceIn(0f, 1f))
                                    .background(Color.White)
                            )
                        }
                        Text("${(gesturePercent * 100).toInt()}%", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Layer 6: 100% Native Cinema Pro Player HUD (Top Bar + Center Play/Pause + Bottom Red Seekbar)
            AnimatedVisibility(
                visible = showControls || !playerReady || !isPlaying,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Subtle Top & Bottom Cinema Gradients
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isLandscape) 96.dp else 64.dp)
                            .align(Alignment.TopCenter)
                            .background(Brush.verticalGradient(listOf(Color(0xC8000000), Color.Transparent)))
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isLandscape) 124.dp else 82.dp)
                            .align(Alignment.BottomCenter)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD8000000))))
                    )

                    // TOP CONTROLS INSIDE PLAYER
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (isLandscape) Modifier.statusBarsPadding() else Modifier)
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .align(Alignment.TopCenter),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            PlayerGlassIcon(
                                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                size = if (isLandscape) 40.dp else 34.dp,
                                onClick = { if (isLandscape) onSetLandscape(false) else onBack() }
                            )
                            if (isLandscape) {
                                Text(
                                    text = displayTitle,
                                    color = Color.White,
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 360.dp)
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (ccAvailable) {
                                PlayerGlassIcon(
                                    icon = if (ccEnabled) Icons.Rounded.ClosedCaption else Icons.Rounded.ClosedCaptionOff,
                                    contentDescription = "Captions",
                                    size = if (isLandscape) 38.dp else 33.dp,
                                    tint = if (ccEnabled) CinemaColors.YtRed else Color.White,
                                    onClick = {
                                        val next = !ccEnabled
                                        ccEnabled = next
                                        runJs("window.__cinemaCmd && window.__cinemaCmd.toggleCaptions($next);")
                                    }
                                )
                            }
                            PlayerGlassIcon(
                                icon = Icons.Rounded.PictureInPictureAlt,
                                contentDescription = "PiP",
                                size = if (isLandscape) 38.dp else 33.dp,
                                onClick = onEnterPip
                            )
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Refresh,
                                contentDescription = "Reload",
                                size = if (isLandscape) 38.dp else 33.dp,
                                onClick = { reloadNonce++ }
                            )
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Settings,
                                contentDescription = "Settings",
                                size = if (isLandscape) 38.dp else 33.dp,
                                onClick = { showPlayerSettings = true }
                            )
                        }
                    }

                    // CENTER CONTROLS: -10s | BIG PLAY/PAUSE (or Spinner) | +10s | Next
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(if (isLandscape) 28.dp else 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (playerReady) {
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Replay10,
                                contentDescription = "-10s",
                                size = if (isLandscape) 48.dp else 40.dp,
                                onClick = { runJs("window.__cinemaCmd && window.__cinemaCmd.seekBy(-10);") }
                            )
                        }

                        // Central Play/Pause Circle (Shows Spinner ring around or inside while buffering)
                        Surface(
                            color = Color(0xF2FFFFFF),
                            shape = CircleShape,
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .size(if (isLandscape) 62.dp else 54.dp)
                                .clickable {
                                    if (!playerReady || !isPlaying) {
                                        isPlaying = true
                                        runJs("window.__cinemaCmd && window.__cinemaCmd.play();")
                                    } else {
                                        isPlaying = false
                                        runJs("window.__cinemaCmd && window.__cinemaCmd.pause();")
                                    }
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (!playerReady || (isBuffering && isPlaying)) {
                                    CircularProgressIndicator(
                                        color = Color.Black,
                                        strokeWidth = 2.8.dp,
                                        modifier = Modifier.size(26.dp)
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.Black,
                                        modifier = Modifier.size(if (isLandscape) 34.dp else 30.dp)
                                    )
                                }
                            }
                        }

                        if (playerReady) {
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Forward10,
                                contentDescription = "+10s",
                                size = if (isLandscape) 48.dp else 40.dp,
                                onClick = { runJs("window.__cinemaCmd && window.__cinemaCmd.seekBy(10);") }
                            )
                            if (isLandscape && relatedVideos.isNotEmpty()) {
                                PlayerGlassIcon(
                                    icon = Icons.Rounded.SkipNext,
                                    contentDescription = "Next",
                                    size = 44.dp,
                                    onClick = { onOpenVideo(relatedVideos.first()) }
                                )
                            }
                        }
                    }

                    // BOTTOM CONTROLS: Live Time + Speed/Quality Chips + Fullscreen + Red Seekbar
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(
                                horizontal = if (isLandscape) 18.dp else 10.dp,
                                vertical = if (isLandscape) 12.dp else 4.dp
                            )
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${formatPlayerTime(positionMs)} / ${formatPlayerTime(durationMs)}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isLandscape) {
                                    PlayerMiniPill(
                                        text = if (isZoomFill) "Fill" else "Fit",
                                        onClick = {
                                            isZoomFill = !isZoomFill
                                            runJs("window.__cinemaCmd && window.__cinemaCmd.setZoom($isZoomFill);")
                                        }
                                    )
                                }
                                PlayerMiniPill(
                                    text = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                    onClick = { showPlayerSettings = true }
                                )
                                PlayerMiniPill(
                                    text = qualityKeyToLabel(currentQualityKey),
                                    onClick = { showPlayerSettings = true }
                                )
                                Icon(
                                    imageVector = if (isLandscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                    contentDescription = "Fullscreen",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .clickable { onSetLandscape(!isLandscape) }
                                        .padding(5.dp)
                                )
                            }
                        }

                        // Scrubbable YouTube-Red Seekbar with Buffered Track
                        Box(
                            modifier = Modifier.fillMaxWidth().height(26.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // Buffered track bar underneath
                            if (durationMs > 0L && bufferedMs > 0L) {
                                val bufFrac = (bufferedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(Color(0x33FFFFFF))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth(bufFrac)
                                            .background(Color(0x66FFFFFF))
                                    )
                                }
                            }
                            Slider(
                                value = sliderFraction,
                                onValueChange = { v ->
                                    isSeeking = true
                                    sliderFraction = v
                                    if (durationMs > 0L) positionMs = (v * durationMs).toLong()
                                },
                                onValueChangeFinished = {
                                    if (durationMs > 0L) {
                                        val seekSec = (sliderFraction * durationMs) / 1000.0
                                        runJs("window.__cinemaCmd && window.__cinemaCmd.seekTo($seekSec);")
                                    }
                                    isSeeking = false
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = CinemaColors.YtRed,
                                    activeTrackColor = CinemaColors.YtRed,
                                    inactiveTrackColor = Color(0x40FFFFFF)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }

    // ---------- ADAPTIVE LAYOUT (Tablet Split vs Mobile Portrait vs Fullscreen/PiP) ----------
    val showSideBySideTablet = isTablet && !isLandscape && !isInPipMode
    val showFullScreenOnly = isLandscape || isInPipMode

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack)
    ) {
        if (showSideBySideTablet) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(top = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.64f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                        .padding(start = 18.dp, end = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    nativeProPlayerBox(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(18.dp))
                    )

                    WatchInfoSection(
                        displayTitle = displayTitle,
                        displayChannel = displayChannel,
                        displayChannelId = displayChannelId,
                        displayAvatar = displayAvatar,
                        details = details,
                        isLiked = isLiked,
                        isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                        qualityLabel = qualityKeyToLabel(currentQualityKey),
                        speedLabel = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                        onOpenDescription = { tabletTab = TabletWatchTab.DETAILS },
                        onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                        onToggleSubscribe = {
                            if (displayChannelId.isNotBlank()) {
                                onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                            }
                        },
                        onToggleLike = { onToggleLike(video.id) },
                        onSave = { showPlaylistDialog = true },
                        onShare = { shareCurrentVideo() },
                        onOpenPlayerSettings = { showPlayerSettings = true }
                    )
                }

                Surface(
                    color = CinemaColors.SurfaceDark,
                    shape = RoundedCornerShape(topStart = 20.dp),
                    border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                    modifier = Modifier
                        .weight(0.36f)
                        .fillMaxHeight()
                        .padding(end = 12.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                TabletWatchTab.UP_NEXT to "Up next",
                                TabletWatchTab.COMMENTS to "Comments",
                                TabletWatchTab.DETAILS to "Details"
                            ).forEach { (tab, label) ->
                                val active = tabletTab == tab
                                Surface(
                                    color = if (active) Color.White else Color(0x1AFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.weight(1f).clickable { tabletTab = tab }
                                ) {
                                    Text(
                                        text = label,
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 8.dp)
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = CinemaColors.DividerSubtle)
                        Box(modifier = Modifier.weight(1f)) {
                            when (tabletTab) {
                                TabletWatchTab.UP_NEXT -> UpNextCompactList(relatedVideos, onOpenVideo)
                                TabletWatchTab.COMMENTS -> CommentsListBody(comments, !commentsLoaded && details?.commentsContinuation != null)
                                TabletWatchTab.DETAILS -> DescriptionBody(details)
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (!showFullScreenOnly) Modifier.statusBarsPadding() else Modifier)
            ) {
                nativeProPlayerBox(
                    if (showFullScreenOnly) {
                        Modifier.fillMaxSize()
                    } else {
                        Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    }
                )

                if (!showFullScreenOnly) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .navigationBarsPadding(),
                        contentPadding = PaddingValues(bottom = 28.dp)
                    ) {
                        item(key = "watch_info") {
                            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                                WatchInfoSection(
                                    displayTitle = displayTitle,
                                    displayChannel = displayChannel,
                                    displayChannelId = displayChannelId,
                                    displayAvatar = displayAvatar,
                                    details = details,
                                    isLiked = isLiked,
                                    isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                                    qualityLabel = qualityKeyToLabel(currentQualityKey),
                                    speedLabel = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                    onOpenDescription = { showDescriptionSheet = true },
                                    onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                                    onToggleSubscribe = {
                                        if (displayChannelId.isNotBlank()) {
                                            onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                                        }
                                    },
                                    onToggleLike = { onToggleLike(video.id) },
                                    onSave = { showPlaylistDialog = true },
                                    onShare = { shareCurrentVideo() },
                                    onOpenPlayerSettings = { showPlayerSettings = true }
                                )
                            }
                        }

                        item(key = "comments_preview") {
                            Surface(
                                color = CinemaColors.SurfaceDark,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp)
                                    .clickable { showCommentsSheet = true }
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (comments.isNotEmpty()) "Comments (${comments.size}+)" else "Comments",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text("View all", color = CinemaColors.TextSecondary, fontSize = 12.sp)
                                    }
                                    val top = comments.firstOrNull()
                                    if (top != null) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            ChannelAvatar(url = top.avatarUrl, name = top.author, size = 26.dp)
                                            Text(
                                                text = top.text,
                                                color = CinemaColors.TextPrimary,
                                                fontSize = 12.5.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = if (!commentsLoaded && details?.commentsContinuation != null) "Loading comments..." else "Tap to read comments",
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 12.5.sp
                                        )
                                    }
                                }
                            }
                        }

                        item(key = "up_next_header") {
                            Text(
                                text = "Up next",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 10.dp)
                            )
                        }

                        if (relatedVideos.isEmpty()) {
                            item(key = "up_next_spinner") {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
                                }
                            }
                        } else {
                            items(relatedVideos, key = { "rel_${it.id}" }) { rel ->
                                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                    CinemaVideoCard(item = rel, showAvatar = true, onClick = { onOpenVideo(rel) })
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---------- NATIVE PLAYER SETTINGS SHEET (Quality / Speed / Captions / Fit) ----------
        if (showPlayerSettings) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlayerSettings = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(20.dp)
                        .widthIn(max = 400.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Player Settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp).clip(CircleShape).clickable { showPlayerSettings = false }.padding(3.dp)
                            )
                        }

                        // Quality
                        Text("Quality", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        val qOptions = remember(availableQualities) {
                            val defaults = listOf("auto", "hd1080", "hd720", "large", "medium", "small")
                            if (availableQualities.isEmpty()) defaults
                            else (listOf("auto") + availableQualities.filterNot { it == "auto" || it == "default" }).distinct()
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(qOptions) { qKey ->
                                val active = currentQualityKey == qKey || (qKey == "auto" && currentQualityKey == "default")
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        currentQualityKey = qKey
                                        runJs("window.__cinemaCmd && window.__cinemaCmd.setQuality('$qKey');")
                                        showPlayerSettings = false
                                    }
                                ) {
                                    Text(
                                        text = qualityKeyToLabel(qKey),
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CinemaColors.DividerSubtle)

                        // Speed
                        Text("Playback Speed", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)) { sp ->
                                val active = playbackSpeed == sp
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        playbackSpeed = sp
                                        runJs("window.__cinemaCmd && window.__cinemaCmd.setSpeed($sp);")
                                    }
                                ) {
                                    Text(
                                        text = if (sp == 1f) "Normal" else "${sp}x",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CinemaColors.DividerSubtle)

                        // Captions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Captions (CC)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(false to "Off", true to "On").forEach { (en, label) ->
                                    val active = ccEnabled == en
                                    Surface(
                                        color = if (active) Color.White else Color(0x1EFFFFFF),
                                        shape = RoundedCornerShape(999.dp),
                                        modifier = Modifier.clickable {
                                            ccEnabled = en
                                            runJs("window.__cinemaCmd && window.__cinemaCmd.toggleCaptions($en);")
                                        }
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (active) Color.Black else Color.White,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider(color = CinemaColors.DividerSubtle)

                        // Video Fit
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Rounded.AspectRatio, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Text("Video Fit", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(false to "Fit", true to "Zoom Fill").forEach { (zoom, label) ->
                                    val active = isZoomFill == zoom
                                    Surface(
                                        color = if (active) Color.White else Color(0x1EFFFFFF),
                                        shape = RoundedCornerShape(999.dp),
                                        modifier = Modifier.clickable {
                                            isZoomFill = zoom
                                            runJs("window.__cinemaCmd && window.__cinemaCmd.setZoom($zoom);")
                                        }
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (active) Color.Black else Color.White,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showCommentsSheet) {
            WatchSheetOverlay(title = "Comments", onDismiss = { showCommentsSheet = false }) {
                CommentsListBody(comments, !commentsLoaded && details?.commentsContinuation != null)
            }
        }

        if (showDescriptionSheet) {
            WatchSheetOverlay(title = "Description", onDismiss = { showDescriptionSheet = false }) {
                DescriptionBody(details)
            }
        }

        if (showPlaylistDialog) {
            val localPlaylists = playlists.filterNot { it.isRemote }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlaylistDialog = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(24.dp)
                        .widthIn(max = 320.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Save to Playlist", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        val richVideo = video.copy(
                            title = displayTitle,
                            channelName = displayChannel,
                            channelId = displayChannelId,
                            channelAvatar = displayAvatar
                        )
                        localPlaylists.forEach { pl ->
                            val saved = pl.videos.any { it.id == video.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x14FFFFFF))
                                    .clickable { onToggleVideoInPlaylist(pl.id, richVideo) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(pl.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                if (saved) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerGlassIcon(
    icon: ImageVector,
    contentDescription: String,
    size: Dp = 38.dp,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Surface(
        color = Color(0x99121216),
        shape = CircleShape,
        border = BorderStroke(1.dp, Color(0x28FFFFFF)),
        modifier = Modifier
            .size(size)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = contentDescription, tint = tint, modifier = Modifier.size(size * 0.54f))
        }
    }
}

@Composable
private fun PlayerMiniPill(text: String, onClick: () -> Unit) {
    Surface(
        color = Color(0x99121216),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, Color(0x28FFFFFF)),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.5.dp)
        )
    }
}

@Composable
private fun WatchInfoSection(
    displayTitle: String,
    displayChannel: String,
    displayChannelId: String,
    displayAvatar: String,
    details: VideoDetails?,
    isLiked: Boolean,
    isSubscribed: Boolean,
    qualityLabel: String,
    speedLabel: String,
    onOpenDescription: () -> Unit,
    onOpenChannel: () -> Unit,
    onToggleSubscribe: () -> Unit,
    onToggleLike: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onOpenPlayerSettings: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenDescription),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = displayTitle,
                color = Color.White,
                fontSize = 17.5.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 23.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val metaLine = listOfNotNull(
                details?.viewCount?.takeIf { it.isNotBlank() },
                details?.publishDate?.takeIf { it.isNotBlank() },
                "more"
            ).joinToString(" · ")
            Text(text = metaLine, color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onOpenChannel)
            ) {
                ChannelAvatar(url = displayAvatar, name = displayChannel, size = 40.dp)
                Column {
                    Text(
                        text = displayChannel.ifBlank { "Channel" },
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    details?.subscriberCount?.takeIf { it.isNotBlank() }?.let {
                        Text(it, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                    }
                }
            }

            if (displayChannelId.isNotBlank()) {
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onToggleSubscribe)
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                WatchActionPill(
                    icon = if (isLiked) Icons.Rounded.ThumbUp else Icons.Rounded.ThumbUpOffAlt,
                    label = details?.likeCount?.takeIf { it.isNotBlank() } ?: "Like",
                    active = isLiked,
                    onClick = onToggleLike
                )
            }
            item { WatchActionPill(icon = Icons.Rounded.BookmarkAdd, label = "Save", onClick = onSave) }
            item { WatchActionPill(icon = Icons.Rounded.Share, label = "Share", onClick = onShare) }
            item { WatchActionPill(icon = Icons.Rounded.HighQuality, label = qualityLabel, onClick = onOpenPlayerSettings) }
            item { WatchActionPill(icon = Icons.Rounded.Speed, label = speedLabel, onClick = onOpenPlayerSettings) }
        }
    }
}

@Composable
private fun WatchActionPill(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) Color.White else CinemaColors.SurfaceElevated,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, if (active) Color.White else CinemaColors.DividerSubtle),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(17.dp))
            Text(label, color = if (active) Color.Black else Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun WatchSheetOverlay(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            color = CinemaColors.GlassStrong,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.68f)
                .navigationBarsPadding()
                .clickable(enabled = false) {}
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp).clip(CircleShape).clickable(onClick = onDismiss).padding(4.dp)
                    )
                }
                HorizontalDivider(color = CinemaColors.DividerSubtle)
                Box(modifier = Modifier.weight(1f)) { content() }
            }
        }
    }
}

@Composable
private fun DescriptionBody(details: VideoDetails?) {
    val desc = details?.description ?: ""
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!details?.title.isNullOrBlank()) {
            Text(details!!.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        val meta = listOfNotNull(
            details?.viewCount?.takeIf { it.isNotBlank() },
            details?.publishDate?.takeIf { it.isNotBlank() }
        ).joinToString(" · ")
        if (meta.isNotBlank()) {
            Text(meta, color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }
        if (desc.isNotBlank()) {
            Text(desc, color = CinemaColors.TextPrimary, fontSize = 13.5.sp, lineHeight = 20.sp)
        } else {
            Text("No description available.", color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CommentsListBody(comments: List<CommentItem>, loading: Boolean) {
    when {
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        comments.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No comments available", color = CinemaColors.TextSecondary, fontSize = 14.sp)
        }
        else -> LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(comments) { c ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ChannelAvatar(url = c.avatarUrl, name = c.author, size = 32.dp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(c.author, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (c.publishedTime.isNotBlank()) {
                                Text(c.publishedTime, color = CinemaColors.TextSecondary, fontSize = 11.sp)
                            }
                        }
                        Text(c.text, color = CinemaColors.TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
                        if (c.likeCount.isNotBlank()) {
                            Text("👍 ${c.likeCount}", color = CinemaColors.TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpNextCompactList(related: List<VideoItem>, onSelect: (VideoItem) -> Unit) {
    if (related.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(related, key = { "tn_${it.id}" }) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelect(item) }
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(126.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(CinemaColors.SurfaceElevated)
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (item.duration.isNotBlank()) {
                        Text(
                            text = item.duration,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .background(Color(0xC2000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 1.5.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(item.title, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.channelName, color = CinemaColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

private fun qualityKeyToLabel(key: String): String = when (key.lowercase()) {
    "highres" -> "4K"
    "hd2160" -> "2160p"
    "hd1440" -> "1440p"
    "hd1080" -> "1080p"
    "hd720" -> "720p"
    "large" -> "480p"
    "medium" -> "360p"
    "small" -> "240p"
    "tiny" -> "144p"
    else -> "Auto"
}

private fun formatPlayerTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
