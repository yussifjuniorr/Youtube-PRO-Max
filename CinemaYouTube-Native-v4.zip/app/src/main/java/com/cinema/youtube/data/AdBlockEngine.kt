package com.cinema.youtube.data

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlockEngine {

    private val BLOCKED_HOSTS = setOf(
        "googleads.g.doubleclick.net",
        "doubleclick.net",
        "ad.doubleclick.net",
        "static.doubleclick.net",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "www.googleadservices.com",
        "googleadservices.com",
        "www.google-analytics.com",
        "adservice.google.com",
        "ads.youtube.com"
    )

    private val BLOCKED_PATH_MARKERS = listOf(
        "/pagead/",
        "/api/stats/ads",
        "/ptracking",
        "/get_midroll_info",
        "/pcs/activeview",
        "/youtubei/v1/log_event",
        "doubleclick.net",
        "googlesyndication.com"
    )

    fun isAdRequest(uri: Uri?): Boolean {
        if (uri == null) return false
        val host = uri.host?.lowercase() ?: return false
        if (host.endsWith("googlevideo.com") || host.endsWith("ytimg.com") || host.endsWith("ggpht.com")) {
            return false
        }
        if (BLOCKED_HOSTS.any { host == it || host.endsWith(".$it") }) {
            return true
        }
        val full = uri.toString().lowercase()
        return BLOCKED_PATH_MARKERS.any { full.contains(it) }
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /**
     * Turns m.youtube.com/watch?v=... into a 100% pure, ad-free, chrome-free video surface
     * controlled entirely by our Native Compose Pro Player via window.__cinemaCmd & CinemaBridge.
     * NOTE: Contains ZERO dollar signs so Kotlin raw string interpolation cannot be triggered.
     */
    const val PURE_VIDEO_ENGINE_JS: String = """
(function() {
  if (window.__cinemaEngineV4) return;
  window.__cinemaEngineV4 = true;
  window.__cinemaUserPaused = false;
  window.__cinemaAutoplayTries = 0;

  // 1. Surgical JSON Ad Stripper
  function stripAds(obj) {
    if (!obj || typeof obj !== 'object') return obj;
    try {
      delete obj.adPlacements;
      delete obj.playerAds;
      delete obj.adSlots;
      delete obj.adBreakHeartbeatParams;
      if (obj.auxiliaryUi && obj.auxiliaryUi.messageRenderers) {
        delete obj.auxiliaryUi.messageRenderers.bkaEnforcementMessageViewModel;
      }
    } catch (e) {}
    return obj;
  }

  try {
    if (window.ytInitialPlayerResponse) stripAds(window.ytInitialPlayerResponse);
  } catch (e) {}

  try {
    var origFetch = window.fetch;
    window.fetch = async function() {
      var args = arguments;
      var resp = await origFetch.apply(this, args);
      try {
        var url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
        if (url.indexOf('/youtubei/v1/player') !== -1) {
          var clone = resp.clone();
          var data = await clone.json();
          stripAds(data);
          return new Response(JSON.stringify(data), {
            status: resp.status,
            statusText: resp.statusText,
            headers: resp.headers
          });
        }
      } catch (e) {}
      return resp;
    };
  } catch (e) {}

  try {
    var origParse = JSON.parse;
    JSON.parse = function(text, reviver) {
      var res = origParse.call(this, text, reviver);
      if (res && typeof res === 'object' && (res.adPlacements || res.playerAds || res.adSlots)) {
        stripAds(res);
      }
      return res;
    };
  } catch (e) {}

  // 2. Pure Video Surface CSS — Hides 100% of YouTube Website & Web Player Chrome, Keeps ONLY <video> & Captions
  function injectPureSurfaceCss() {
    if (document.getElementById('cinema-pure-v4-css')) return;
    var style = document.createElement('style');
    style.id = 'cinema-pure-v4-css';
    style.textContent =
      'html, body {' +
      '  background: #000000 !important;' +
      '  margin: 0 !important;' +
      '  padding: 0 !important;' +
      '  overflow: hidden !important;' +
      '  width: 100vw !important;' +
      '  height: 100vh !important;' +
      '}' +
      'ytm-mobile-topbar-renderer, .mobile-topbar-header, #header-bar,' +
      'ytm-watch-metadata, ytm-single-column-watch-next-results-renderer,' +
      'ytm-item-section-renderer, ytm-pivot-bar-renderer, ytm-mealbar-promo-renderer,' +
      'ytm-upsell-dialog-renderer, tp-yt-paper-dialog, ytm-companion-slot,' +
      'ytm-promoted-sparkles-web-renderer, .ytm-autonav-bar, .open-app-button,' +
      '#player-control-overlay, .player-controls-content, .player-controls-background,' +
      '.player-controls-background-container, ytm-custom-control, .ytm-bottom-sheet,' +
      '.ytp-chrome-top, .ytp-chrome-bottom, .ytp-gradient-top, .ytp-gradient-bottom,' +
      '.ytp-cued-thumbnail-overlay, .ytp-large-play-button, .ytp-spinner,' +
      '.ytp-bezel, .ytp-bezel-text-wrapper, .ytp-pause-overlay, .ytp-watermark,' +
      '.ytp-paid-content-overlay, .ytp-ad-overlay-container, .ytp-ad-text-overlay,' +
      '.ytp-ad-module, .ytp-ce-element, .ytp-cards-teaser, .ytp-suggested-action,' +
      '.ytp-error, .ytp-title, .ytp-youtube-button, .ytp-show-tiles {' +
      '  display: none !important;' +
      '  opacity: 0 !important;' +
      '  visibility: hidden !important;' +
      '  pointer-events: none !important;' +
      '}' +
      '#player-container-id, .player-container, #player, #movie_player {' +
      '  position: fixed !important;' +
      '  top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;' +
      '  width: 100vw !important; height: 100vh !important; max-height: 100vh !important;' +
      '  margin: 0 !important; padding: 0 !important;' +
      '  background: #000000 !important;' +
      '  z-index: 2147483000 !important;' +
      '  pointer-events: none !important;' +
      '}' +
      '.html5-video-container {' +
      '  position: fixed !important;' +
      '  top: 0 !important; left: 0 !important;' +
      '  width: 100vw !important; height: 100vh !important;' +
      '}' +
      'video.html5-main-video, video {' +
      '  position: fixed !important;' +
      '  top: 0 !important; left: 0 !important;' +
      '  width: 100vw !important; height: 100vh !important;' +
      '  max-width: 100vw !important; max-height: 100vh !important;' +
      '  margin: 0 !important; transform: none !important;' +
      '  object-fit: contain !important;' +
      '  background: #000000 !important;' +
      '}' +
      'body.cinema-zoom video.html5-main-video, body.cinema-zoom video {' +
      '  object-fit: cover !important;' +
      '}' +
      '.ytp-caption-window-container {' +
      '  z-index: 2147483500 !important;' +
      '  bottom: 12px !important;' +
      '  pointer-events: none !important;' +
      '}';
    (document.head || document.documentElement).appendChild(style);
  }
  injectPureSurfaceCss();

  function getMp() {
    return document.getElementById('movie_player') || document.querySelector('.html5-video-player');
  }
  function getVid() {
    return document.querySelector('video.html5-main-video') || document.querySelector('video');
  }

  // 3. Native-to-JS Command Interface (Called directly from Native Compose Player)
  window.__cinemaCmd = {
    play: function() {
      window.__cinemaUserPaused = false;
      var mp = getMp();
      var v = getVid();
      try { if (v) { v.muted = false; v.volume = 1.0; } } catch (e) {}
      try { if (mp && typeof mp.unMute === 'function') mp.unMute(); } catch (e) {}
      try { if (mp && typeof mp.playVideo === 'function') mp.playVideo(); } catch (e) {}
      try { if (v) { var p = v.play(); if (p && p.catch) p.catch(function(){}); } } catch (e) {}
    },
    pause: function() {
      window.__cinemaUserPaused = true;
      var mp = getMp();
      var v = getVid();
      try { if (mp && typeof mp.pauseVideo === 'function') mp.pauseVideo(); } catch (e) {}
      try { if (v) v.pause(); } catch (e) {}
    },
    togglePlay: function() {
      var v = getVid();
      if (!v || v.paused || v.ended) {
        window.__cinemaCmd.play();
      } else {
        window.__cinemaCmd.pause();
      }
    },
    seekTo: function(sec) {
      var target = Math.max(0, Number(sec) || 0);
      var mp = getMp();
      var v = getVid();
      try {
        if (v && isFinite(v.duration) && v.duration > 0) {
          target = Math.min(target, v.duration);
        }
      } catch (e) {}
      try { if (mp && typeof mp.seekTo === 'function') mp.seekTo(target, true); } catch (e) {}
      try { if (v) v.currentTime = target; } catch (e) {}
    },
    seekBy: function(deltaSec) {
      var v = getVid();
      var cur = v ? (v.currentTime || 0) : 0;
      window.__cinemaCmd.seekTo(cur + (Number(deltaSec) || 0));
    },
    setSpeed: function(rate) {
      var r = Number(rate) || 1.0;
      var mp = getMp();
      var v = getVid();
      try { if (mp && typeof mp.setPlaybackRate === 'function') mp.setPlaybackRate(r); } catch (e) {}
      try { if (v) v.playbackRate = r; } catch (e) {}
    },
    setQuality: function(level) {
      var mp = getMp();
      if (!mp) return;
      try {
        if (level === 'auto' || level === 'default') {
          if (typeof mp.setPlaybackQualityRange === 'function') mp.setPlaybackQualityRange('tiny', 'highres');
          if (typeof mp.setPlaybackQuality === 'function') mp.setPlaybackQuality('default');
        } else {
          if (typeof mp.setPlaybackQualityRange === 'function') mp.setPlaybackQualityRange(level, level);
          if (typeof mp.setPlaybackQuality === 'function') mp.setPlaybackQuality(level);
        }
      } catch (e) {}
    },
    toggleCaptions: function(enable) {
      var mp = getMp();
      try {
        if (enable) {
          if (mp && typeof mp.loadModule === 'function') mp.loadModule('captions');
          if (mp && typeof mp.getOption === 'function' && typeof mp.setOption === 'function') {
            var tracks = mp.getOption('captions', 'tracklist') || [];
            if (tracks.length > 0) {
              mp.setOption('captions', 'track', tracks[0]);
            }
          }
          window.__cinemaCcWanted = true;
        } else {
          if (mp && typeof mp.setOption === 'function') mp.setOption('captions', 'track', {});
          if (mp && typeof mp.unloadModule === 'function') mp.unloadModule('captions');
          window.__cinemaCcWanted = false;
        }
      } catch (e) {}
    },
    setZoom: function(fill) {
      try {
        if (document.body) {
          if (fill) document.body.classList.add('cinema-zoom');
          else document.body.classList.remove('cinema-zoom');
        }
      } catch (e) {}
    }
  };

  function inferQualityLabel(mp, v) {
    try {
      if (mp && typeof mp.getPlaybackQuality === 'function') {
        var q = mp.getPlaybackQuality();
        if (q && q !== 'unknown' && q !== 'auto') return q;
      }
    } catch (e) {}
    if (v && v.videoHeight) {
      var h = v.videoHeight;
      if (h >= 1400) return 'hd1440';
      if (h >= 1000) return 'hd1080';
      if (h >= 700) return 'hd720';
      if (h >= 460) return 'large';
      if (h >= 340) return 'medium';
      return 'small';
    }
    return 'auto';
  }

  // 4. Live State Telemetry Loop + Ad Failsafe + Auto-Consent + Autoplay Enforcer
  var wasMutedByAd = false;
  var endedSent = false;

  setInterval(function() {
    injectPureSurfaceCss();

    // Auto-dismiss consent / open-in-app dialogs if they ever appear
    try {
      var consentBtn = document.querySelector('form[action*="consent"] button, button[aria-label*="Accept all"]');
      if (consentBtn) consentBtn.click();
    } catch (e) {}

    var mp = getMp();
    var v = getVid();
    if (!v) return;

    // Ad failsafe
    var isAd = !!(mp && (mp.classList.contains('ad-showing') || mp.classList.contains('ad-interrupting')));
    if (isAd) {
      if (!v.muted) { v.muted = true; wasMutedByAd = true; }
      try {
        var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button');
        if (skip) skip.click();
        if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
      } catch (e) {}
    } else if (wasMutedByAd) {
      v.muted = false;
      wasMutedByAd = false;
    }

    // Smooth autoplay on first load (never fights user Pause)
    if (!isAd && !window.__cinemaUserPaused && v.paused && !v.ended && window.__cinemaAutoplayTries < 12) {
      window.__cinemaAutoplayTries++;
      try { v.muted = false; } catch (e) {}
      try { if (mp && typeof mp.playVideo === 'function') mp.playVideo(); } catch (e) {}
      try { var p = v.play(); if (p && p.catch) p.catch(function(){}); } catch (e) {}
    }

    // Compute buffered ms
    var bufMs = 0;
    try {
      if (v.buffered && v.buffered.length > 0) {
        bufMs = Math.floor(v.buffered.end(v.buffered.length - 1) * 1000);
      }
    } catch (e) {}

    // Available quality levels
    var levels = [];
    try {
      if (mp && typeof mp.getAvailableQualityLevels === 'function') {
        levels = mp.getAvailableQualityLevels() || [];
      }
    } catch (e) {}

    // Captions availability
    var ccAvail = false;
    var ccOn = !!window.__cinemaCcWanted;
    try {
      if (mp && typeof mp.getOption === 'function') {
        var tl = mp.getOption('captions', 'tracklist');
        if (tl && tl.length > 0) ccAvail = true;
        var curTrack = mp.getOption('captions', 'track');
        if (curTrack && curTrack.languageCode) ccOn = true;
      }
    } catch (e) {}

    var durMs = (isFinite(v.duration) && v.duration > 0) ? Math.floor(v.duration * 1000) : 0;
    var posMs = (isFinite(v.currentTime) && v.currentTime >= 0) ? Math.floor(v.currentTime * 1000) : 0;
    var ready = (!isAd && v.readyState >= 2 && v.videoWidth > 0 && durMs > 0);
    var playing = (ready && !v.paused && !v.ended);
    var buffering = (isAd || !ready || (v.readyState < 3 && !v.paused));

    if (window.CinemaBridge) {
      var payload = JSON.stringify({
        playing: playing,
        buffering: buffering,
        ready: ready,
        posMs: posMs,
        durMs: durMs,
        bufMs: bufMs,
        quality: inferQualityLabel(mp, v),
        qualities: levels,
        ccAvailable: ccAvail,
        ccEnabled: ccOn,
        speed: v.playbackRate || 1.0,
        ended: !!(ready && v.ended)
      });
      try { window.CinemaBridge.onState(payload); } catch (e) {}

      if (ready && v.ended && !endedSent) {
        endedSent = true;
        try { window.CinemaBridge.onVideoEnded(); } catch (e) {}
      } else if (!v.ended) {
        endedSent = false;
      }
    }
  }, 250);
})();
"""
}
