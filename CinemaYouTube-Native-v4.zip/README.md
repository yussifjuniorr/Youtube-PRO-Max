# Cinema YouTube Native (v4.0 Final)

100% Native Jetpack Compose UI + Native Cinema Pro Video Player Controls backed by an invisible, ad-stripped YouTube HTML5 video surface:
- **Zero Website Chrome:** YouTube's web page and web buttons are completely hidden and covered by a crisp video thumbnail until the real video stream starts playing.
- **100% Native Pro Player UI:** Big crisp Play/Pause button, ±10s buttons, double-tap ±10s seek with animation, hold-for-2x speed, left/right vertical swipe for brightness & volume, scrubbable YouTube-red seekbar with live time, Quality picker (1080p/720p/480p/360p/Auto), Speed (0.5x–2x), Captions (CC), Fit/Zoom Fill, Fullscreen without reloading, and Picture-in-Picture (PiP).
- **100% Ad-Free & Full Video Compatibility:** Strips ads at network, JSON, and playback layers while playing official music videos, sports highlights, and age-verified videos reliably.
- **Direct Google Account Sign-In:** Syncs your real Home feed, Subscriptions, Playlists, and History via SAPISIDHASH.
- **True Adaptive Mobile & Tablet UI:** Clean docked Scaffold + Spotlight card on Mobile (`< 600dp`) and Apple TV+ floating glass nav + widescreen Hero + split-screen Watch on Tablet (`>= 600dp`).
