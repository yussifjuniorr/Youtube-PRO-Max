package com.cinema.youtube.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.GoogleSession
import com.cinema.youtube.model.HistoryEntry
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay

enum class TopTab { HOME, SUBSCRIPTIONS, PLAYLISTS, HISTORY }

// ---------- Shared Avatar ----------
@Composable
fun ChannelAvatar(url: String, name: String, size: Dp) {
    if (url.isNotBlank()) {
        AsyncImage(
            model = url,
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x22FFFFFF))
                .border(1.dp, Color(0x28FFFFFF), CircleShape)
        )
    } else {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x26FFFFFF))
                .border(1.dp, Color(0x28FFFFFF), CircleShape)
        ) {
            Text(
                text = name.trim().firstOrNull()?.uppercase() ?: "Y",
                color = Color.White,
                fontSize = (size.value * 0.44f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun AccountAvatarButton(
    session: GoogleSession?,
    size: Dp = 34.dp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size)
            .clickable(onClick = onClick)
    ) {
        if (session != null && session.isValid) {
            ChannelAvatar(
                url = session.avatarUrl,
                name = session.displayName.ifBlank { "G" },
                size = size
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(CinemaColors.AccentGreen)
                    .border(1.5.dp, CinemaColors.BarDark, CircleShape)
            )
        } else {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color(0x1FFFFFFF))
                    .border(1.dp, CinemaColors.GlassStroke, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Person,
                    contentDescription = "Account",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.54f)
                )
            }
        }
    }
}

// ---------- MOBILE DOCKED TOP BAR (Zero Overlap!) ----------
@Composable
fun MobileTopBar(
    session: GoogleSession?,
    isSearching: Boolean,
    searchText: String,
    recentSearches: List<String>,
    hl: String,
    onLogoClick: () -> Unit,
    onSearchModeChange: (Boolean) -> Unit,
    onSearchTextChange: (String) -> Unit,
    onSubmitSearch: (String) -> Unit,
    onClearRecentSearches: () -> Unit,
    onOpenAccount: () -> Unit
) {
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(isSearching, searchText) {
        if (!isSearching || searchText.isBlank()) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(140)
        suggestions = InnerTubeClient.fetchSuggestions(searchText, hl)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CinemaColors.BarDark)
            .statusBarsPadding()
    ) {
        if (isSearching) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable {
                            onSearchTextChange("")
                            onSearchModeChange(false)
                        }
                        .padding(7.dp)
                )
                SearchInputField(
                    searchText = searchText,
                    onSearchTextChange = onSearchTextChange,
                    onSubmit = { onSubmitSearch(searchText) },
                    onClose = {
                        if (searchText.isNotEmpty()) onSearchTextChange("")
                        else onSearchModeChange(false)
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    modifier = Modifier.clickable(onClick = onLogoClick)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .width(30.dp)
                            .height(21.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(CinemaColors.YtRed)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "Cinema",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.2.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable { onSearchModeChange(true) }
                            .padding(7.dp)
                    )
                    AccountAvatarButton(session = session, size = 34.dp, onClick = onOpenAccount)
                }
            }
        }

        HorizontalDivider(color = CinemaColors.DividerSubtle, thickness = 0.5.dp)

        if (isSearching) {
            val showItems = if (searchText.isBlank()) recentSearches.take(7) else suggestions
            if (showItems.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CinemaColors.SurfaceDark)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    if (searchText.isBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Recent searches", color = CinemaColors.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Clear", color = CinemaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onClearRecentSearches))
                        }
                    }
                    showItems.forEach { s ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSubmitSearch(s) }
                                .padding(horizontal = 10.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = if (searchText.isBlank()) Icons.Rounded.History else Icons.Rounded.Search,
                                contentDescription = null,
                                tint = CinemaColors.TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(s, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                HorizontalDivider(color = CinemaColors.DividerSubtle, thickness = 0.5.dp)
            }
        }
    }
}

// ---------- MOBILE DOCKED BOTTOM NAVIGATION BAR (Zero Overlap!) ----------
@Composable
fun MobileDockedBottomNav(
    activeTab: TopTab,
    onTabSelected: (TopTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CinemaColors.BarDark)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(color = CinemaColors.DividerSubtle, thickness = 0.5.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MobileBottomTabItem(Icons.Rounded.Home, "Home", activeTab == TopTab.HOME, Modifier.weight(1f)) {
                onTabSelected(TopTab.HOME)
            }
            MobileBottomTabItem(Icons.Rounded.Subscriptions, "Subs", activeTab == TopTab.SUBSCRIPTIONS, Modifier.weight(1f)) {
                onTabSelected(TopTab.SUBSCRIPTIONS)
            }
            MobileBottomTabItem(Icons.Rounded.VideoLibrary, "Playlists", activeTab == TopTab.PLAYLISTS, Modifier.weight(1f)) {
                onTabSelected(TopTab.PLAYLISTS)
            }
            MobileBottomTabItem(Icons.Rounded.History, "History", activeTab == TopTab.HISTORY, Modifier.weight(1f)) {
                onTabSelected(TopTab.HISTORY)
            }
        }
    }
}

@Composable
private fun MobileBottomTabItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 5.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (active) Color(0x24FFFFFF) else Color.Transparent)
                .padding(horizontal = 16.dp, vertical = 3.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) Color.White else CinemaColors.TextSecondary,
                modifier = Modifier.size(21.dp)
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            color = if (active) Color.White else CinemaColors.TextSecondary,
            fontSize = 10.5.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

// ---------- TABLET FLOATING CINEMA PILL BAR (Exact Apple TV / Chrome Extension Look) ----------
@Composable
fun TabletFloatingTopNav(
    session: GoogleSession?,
    activeTab: TopTab,
    isSearching: Boolean,
    searchText: String,
    recentSearches: List<String>,
    hl: String,
    onTabSelected: (TopTab) -> Unit,
    onSearchModeChange: (Boolean) -> Unit,
    onSearchTextChange: (String) -> Unit,
    onSubmitSearch: (String) -> Unit,
    onClearRecentSearches: () -> Unit,
    onOpenAccount: () -> Unit
) {
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(isSearching, searchText) {
        if (!isSearching || searchText.isBlank()) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(140)
        suggestions = InnerTubeClient.fetchSuggestions(searchText, hl)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(top = 12.dp, start = 16.dp, end = 16.dp)
    ) {
        Surface(
            color = CinemaColors.GlassFill,
            shape = RoundedCornerShape(999.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            shadowElevation = 14.dp
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(if (activeTab == TopTab.HOME && !isSearching) Color(0x26FFFFFF) else Color.Transparent)
                        .clickable {
                            onSearchModeChange(false)
                            onTabSelected(TopTab.HOME)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .width(32.dp)
                            .height(22.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(CinemaColors.YtRed)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = "Home", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }

                if (isSearching) {
                    SearchInputField(
                        searchText = searchText,
                        onSearchTextChange = onSearchTextChange,
                        onSubmit = { onSubmitSearch(searchText) },
                        onClose = {
                            onSearchTextChange("")
                            onSearchModeChange(false)
                        },
                        modifier = Modifier.widthIn(min = 260.dp, max = 400.dp)
                    )
                } else {
                    NavPillItem("Subscriptions", activeTab == TopTab.SUBSCRIPTIONS) { onTabSelected(TopTab.SUBSCRIPTIONS) }
                    NavPillItem("Playlists", activeTab == TopTab.PLAYLISTS) { onTabSelected(TopTab.PLAYLISTS) }
                    NavPillItem("History", activeTab == TopTab.HISTORY) { onTabSelected(TopTab.HISTORY) }

                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .clickable { onSearchModeChange(true) }
                            .padding(8.dp)
                    )
                    Spacer(Modifier.width(2.dp))
                    AccountAvatarButton(session = session, size = 34.dp, onClick = onOpenAccount)
                }
            }
        }

        if (isSearching) {
            val showItems = if (searchText.isBlank()) recentSearches.take(7) else suggestions
            if (showItems.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    shadowElevation = 14.dp,
                    modifier = Modifier.fillMaxWidth().widthIn(max = 520.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (searchText.isBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Recent searches", color = CinemaColors.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("Clear", color = CinemaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onClearRecentSearches))
                            }
                        }
                        showItems.forEach { s ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSubmitSearch(s) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Icon(
                                    imageVector = if (searchText.isBlank()) Icons.Rounded.History else Icons.Rounded.Search,
                                    contentDescription = null,
                                    tint = CinemaColors.TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(s, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchInputField(
    searchText: String,
    onSearchTextChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
        BasicTextField(
            value = searchText,
            onValueChange = onSearchTextChange,
            singleLine = true,
            modifier = Modifier.weight(1f),
            textStyle = TextStyle(color = Color.White, fontSize = 14.5.sp),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
            decorationBox = { inner ->
                Box(
                    contentAlignment = Alignment.CenterStart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color(0x18FFFFFF))
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                ) {
                    if (searchText.isEmpty()) {
                        Text("Search YouTube...", color = CinemaColors.TextSecondary, fontSize = 14.sp)
                    }
                    inner()
                }
            }
        )
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "Go",
            tint = Color.White,
            modifier = Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onSubmit).padding(7.dp)
        )
        Icon(
            imageVector = Icons.Rounded.Close,
            contentDescription = "Clear",
            tint = CinemaColors.TextSecondary,
            modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onClose).padding(7.dp)
        )
    }
}

@Composable
private fun NavPillItem(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (active) CinemaColors.PillActiveBg else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (active) CinemaColors.PillActiveText else Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

// ---------- HOME SCREEN (Distinct Mobile Feed Design vs Tablet Cinema Design) ----------
@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    isTablet: Boolean,
    heroVideos: List<VideoItem>,
    shelves: List<HomeShelf>,
    continueWatching: List<VideoItem>,
    isLoading: Boolean,
    onRefresh: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    if (isLoading && heroVideos.isEmpty() && shelves.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                Text("Loading Cinema YouTube...", color = CinemaColors.TextSecondary, fontSize = 14.sp)
            }
        }
        return
    }

    if (!isLoading && heroVideos.isEmpty() && shelves.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تعذّر تحميل الصفحة الرئيسية", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onRefresh)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة المحاولة", color = Color.Black, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        return
    }

    if (isTablet) {
        // TABLET: Apple TV+ Widescreen Edge-to-Edge Hero + Horizontal Cinema Shelves
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
            contentPadding = PaddingValues(bottom = 48.dp)
        ) {
            if (heroVideos.isNotEmpty()) {
                item(key = "tablet_hero") {
                    TabletHeroCarousel(
                        videos = heroVideos,
                        onPlayVideo = onPlayVideo,
                        onOpenChannel = onOpenChannel
                    )
                }
            } else {
                item { Spacer(Modifier.height(92.dp)) }
            }

            if (continueWatching.isNotEmpty()) {
                item(key = "tablet_cw") {
                    CinemaShelf("Continue watching", continueWatching, onPlayVideo)
                }
            }

            items(shelves, key = { "ts_${it.title}" }) { shelf ->
                CinemaShelf(shelf.title, shelf.videos, onPlayVideo)
            }
        }
    } else {
        // MOBILE: Ultra-Clean Native Mobile Experience!
        // Category Chips -> Clean Rounded Spotlight Card -> Continue Watching -> Crisp Full-Width Vertical Feed
        var selectedShelfIndex by remember(shelves) { mutableIntStateOf(0) }
        val activeShelf = shelves.getOrNull(selectedShelfIndex)
        val feedVideos = activeShelf?.videos ?: emptyList()

        LazyColumn(
            modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
            contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Category Filter Chips
            if (shelves.size > 1) {
                item(key = "mobile_chips") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(shelves.indices.toList()) { idx ->
                            val active = idx == selectedShelfIndex
                            Surface(
                                color = if (active) Color.White else CinemaColors.SurfaceElevated,
                                shape = RoundedCornerShape(999.dp),
                                border = BorderStroke(1.dp, if (active) Color.White else CinemaColors.DividerSubtle),
                                modifier = Modifier.clickable { selectedShelfIndex = idx }
                            ) {
                                Text(
                                    text = shelves[idx].title,
                                    color = if (active) Color.Black else Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Rounded Apple TV+ Mobile Spotlight Card (Thumbnail 100% clean, text cleanly inside dark card footer!)
            if (selectedShelfIndex == 0 && heroVideos.isNotEmpty()) {
                item(key = "mobile_spotlight") {
                    MobileSpotlightCarousel(
                        videos = heroVideos,
                        onPlayVideo = onPlayVideo,
                        onOpenChannel = onOpenChannel
                    )
                }
            }

            // Continue Watching Horizontal Strip (only when user has paused videos)
            if (selectedShelfIndex == 0 && continueWatching.isNotEmpty()) {
                item(key = "mobile_cw") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Continue watching",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(continueWatching, key = { "mcw_${it.id}" }) { item ->
                                CinemaVideoCard(item = item, width = 224.dp, showAvatar = false, onClick = { onPlayVideo(item) })
                            }
                        }
                    }
                }
            }

            // Clean Full-Width Mobile Video Cards (Zero text clipping, crisp thumbnails, buttery scroll!)
            items(feedVideos, key = { "mf_${selectedShelfIndex}_${it.id}" }) { item ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    CinemaVideoCard(item = item, showAvatar = true, onClick = { onPlayVideo(item) })
                }
            }
        }
    }
}

@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MobileSpotlightCarousel(
    videos: List<VideoItem>,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { videos.size })

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = 16.dp),
            pageSpacing = 12.dp,
            modifier = Modifier.fillMaxWidth()
        ) { page ->
            val item = videos[page]
            var useFallback by remember(item.id) { mutableStateOf(false) }

            Surface(
                color = CinemaColors.SurfaceDark,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPlayVideo(item) }
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Clean 16:9 Thumbnail (Zero text clutter over the artwork!)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .background(CinemaColors.SurfaceElevated)
                    ) {
                        AsyncImage(
                            model = if (useFallback) item.thumbnailUrl else item.heroThumbnailUrl,
                            contentDescription = item.title,
                            contentScale = ContentScale.Crop,
                            onError = { useFallback = true },
                            modifier = Modifier.fillMaxSize()
                        )
                        if (item.duration.isNotBlank()) {
                            Text(
                                text = item.duration,
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                                    .background(Color(0xCC000000), RoundedCornerShape(7.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Clean Dark Cinema Footer with Title, Channel, and Play Button
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = item.title,
                            color = Color.White,
                            fontSize = 16.5.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 22.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        if (item.channelId.isNotBlank()) onOpenChannel(item.channelId)
                                    }
                            ) {
                                ChannelAvatar(url = item.channelAvatar, name = item.channelName, size = 30.dp)
                                Column {
                                    if (item.channelName.isNotBlank()) {
                                        Text(
                                            text = item.channelName,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (item.meta.isNotBlank()) {
                                        Text(
                                            text = item.meta,
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 11.5.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.width(8.dp))

                            Surface(
                                color = Color.White,
                                shape = RoundedCornerShape(999.dp),
                                modifier = Modifier.clickable { onPlayVideo(item) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 15.dp, vertical = 8.dp)
                                ) {
                                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(3.dp))
                                    Text("Play", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (videos.size > 1) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(videos.size) { i ->
                    val active = i == pagerState.currentPage
                    Box(
                        modifier = Modifier
                            .height(5.dp)
                            .width(if (active) 18.dp else 5.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (active) Color.White else Color(0x44FFFFFF))
                    )
                }
            }
        }
    }
}

@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TabletHeroCarousel(
    videos: List<VideoItem>,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { videos.size })
    val screenHeightDp = LocalConfiguration.current.screenHeightDp
    val heroHeight = (screenHeightDp * 0.58f).dp.coerceIn(400.dp, 520.dp)

    Box(modifier = Modifier.fillMaxWidth().height(heroHeight)) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val item = videos[page]
            var useFallback by remember(item.id) { mutableStateOf(false) }

            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = if (useFallback) item.thumbnailUrl else item.heroThumbnailUrl,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    onError = { useFallback = true },
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color(0x88060608),
                                0.30f to Color(0x22060608),
                                0.62f to Color(0xB8060608),
                                1.0f to CinemaColors.BgBlack
                            )
                        )
                    )
                )
                Box(
                    modifier = Modifier.fillMaxSize().background(
                        Brush.horizontalGradient(
                            colorStops = arrayOf(
                                0.0f to Color(0xD8060608),
                                0.50f to Color(0x55060608),
                                1.0f to Color.Transparent
                            )
                        )
                    )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .widthIn(max = 580.dp)
                        .padding(start = 32.dp, end = 32.dp, bottom = 34.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (item.channelName.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.clickable {
                                if (item.channelId.isNotBlank()) onOpenChannel(item.channelId)
                            }
                        ) {
                            ChannelAvatar(url = item.channelAvatar, name = item.channelName, size = 34.dp)
                            Text(item.channelName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Text(
                        text = item.title,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 34.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (item.duration.isNotBlank()) {
                            Text(
                                text = item.duration,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        if (item.meta.isNotBlank()) {
                            Text(item.meta, color = CinemaColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { onPlayVideo(item) }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Play", color = Color.Black, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (item.channelId.isNotBlank()) {
                            Surface(
                                color = CinemaColors.GlassFill,
                                shape = RoundedCornerShape(999.dp),
                                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                                modifier = Modifier.clickable { onOpenChannel(item.channelId) }
                            ) {
                                Text(
                                    text = "View channel",
                                    color = Color.White,
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (videos.size > 1) {
            Surface(
                color = CinemaColors.GlassFill,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 28.dp, bottom = 26.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    repeat(videos.size) { i ->
                        val active = i == pagerState.currentPage
                        Box(
                            modifier = Modifier
                                .height(5.5.dp)
                                .width(if (active) 18.dp else 5.5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(if (active) Color.White else Color(0x55FFFFFF))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CinemaShelf(
    title: String,
    videos: List<VideoItem>,
    onPlayVideo: (VideoItem) -> Unit
) {
    Column(modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 28.dp, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(videos, key = { "${title}_${it.id}" }) { item ->
                CinemaVideoCard(item = item, width = 276.dp, showAvatar = false, onClick = { onPlayVideo(item) })
            }
        }
    }
}

@Composable
fun CinemaVideoCard(
    item: VideoItem,
    width: Dp? = null,
    showAvatar: Boolean = true,
    onClick: () -> Unit
) {
    val cardMod = if (width != null) Modifier.width(width) else Modifier.fillMaxWidth()
    Column(modifier = cardMod.clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp))
                .background(CinemaColors.SurfaceDark)
                .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(14.dp))
        ) {
            AsyncImage(
                model = item.thumbnailUrl,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (item.duration.isNotBlank()) {
                Text(
                    text = item.duration,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 8.dp, bottom = if (item.progressPercent > 0) 14.dp else 8.dp)
                        .background(Color(0xC8000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            if (item.progressPercent > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                        .height(3.5.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0x4DFFFFFF))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((item.progressPercent / 100f).coerceIn(0f, 1f))
                            .background(CinemaColors.YtRed)
                    )
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            if (showAvatar && item.channelName.isNotBlank()) {
                ChannelAvatar(url = item.channelAvatar, name = item.channelName, size = 34.dp)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    color = Color.White,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 19.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val subLine = listOf(item.channelName, item.meta).filter { it.isNotBlank() }.joinToString(" · ")
                if (subLine.isNotBlank()) {
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = subLine,
                        color = CinemaColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun SubscriptionsScreen(
    isTablet: Boolean,
    subscriptions: List<SubscribedChannel>,
    subVideos: List<VideoItem>,
    onOpenChannel: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val topPad = if (isTablet) 88.dp else 14.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = topPad, bottom = 32.dp, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("Subscriptions", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        if (subscriptions.isEmpty() && subVideos.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyStateCard(
                    title = "No subscribed channels yet",
                    subtitle = "Sign in with Google from your profile icon to sync your YouTube subscriptions, or tap Subscribe on any channel."
                )
            }
        } else {
            if (subscriptions.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(subscriptions, key = { it.id }) { ch ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(72.dp).clickable { onOpenChannel(ch.id) }
                            ) {
                                ChannelAvatar(url = ch.avatarUrl, name = ch.name, size = 54.dp)
                                Spacer(Modifier.height(6.dp))
                                Text(ch.name, color = Color.White, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            items(subVideos, key = { "sub_${it.id}" }) { vid ->
                CinemaVideoCard(item = vid, showAvatar = true, onClick = { onPlayVideo(vid) })
            }
        }
    }
}

@Composable
fun PlaylistsScreen(
    isTablet: Boolean,
    playlists: List<UserPlaylist>,
    remotePlaylistVideos: Map<String, List<VideoItem>>,
    loadingRemotePlaylistId: String?,
    onLoadRemotePlaylist: (String) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    val selected = playlists.firstOrNull { it.id == selectedPlaylistId }
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val topPad = if (isTablet) 88.dp else 14.dp

    LaunchedEffect(selected?.id) {
        if (selected != null && selected.isRemote && !remotePlaylistVideos.containsKey(selected.id)) {
            onLoadRemotePlaylist(selected.id)
        }
    }

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = topPad, bottom = 32.dp, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (selected != null) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp).clip(CircleShape).clickable { selectedPlaylistId = null }.padding(4.dp)
                    )
                    Text(selected.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }

            val displayVideos = if (selected.isRemote) remotePlaylistVideos[selected.id] ?: emptyList() else selected.videos

            if (loadingRemotePlaylistId == selected.id) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                    }
                }
            } else if (displayVideos.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyStateCard("Playlist is empty", "Open any video and tap Save to add it to your playlists.")
                }
            } else {
                items(displayVideos, key = { "${selected.id}_${it.id}" }) { vid ->
                    CinemaVideoCard(item = vid, showAvatar = true, onClick = { onPlayVideo(vid) })
                }
            }
        } else {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Playlists", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier.clickable { showCreateDialog = true }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("New", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            items(playlists, key = { it.id }) { pl ->
                Surface(
                    color = CinemaColors.SurfaceDark,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                    modifier = Modifier.fillMaxWidth().clickable { selectedPlaylistId = pl.id }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(96.dp)
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x1AFFFFFF)),
                                contentAlignment = Alignment.Center
                            ) {
                                val thumb = pl.thumbnailUrl.ifBlank { pl.videos.firstOrNull()?.thumbnailUrl ?: "" }
                                if (thumb.isNotBlank()) {
                                    AsyncImage(model = thumb, contentDescription = pl.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                } else {
                                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = CinemaColors.TextSecondary)
                                }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(pl.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val sub = if (pl.isRemote) pl.videoCountText.ifBlank { "YouTube Account" } else "${pl.videos.size} videos"
                                Text(sub, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                            }
                        }
                        if (!pl.isRemote && pl.id != "watch_later" && pl.id != "favorites") {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Delete",
                                tint = CinemaColors.TextSecondary,
                                modifier = Modifier.size(28.dp).clip(CircleShape).clickable { onDeletePlaylist(pl.id) }.padding(4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = Color(0xFF1C1C20),
            title = { Text("New Playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Playlist name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) onCreatePlaylist(newName)
                    newName = ""
                    showCreateDialog = false
                }) { Text("Create", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel", color = CinemaColors.TextSecondary) }
            }
        )
    }
}

@Composable
fun HistoryScreen(
    isTablet: Boolean,
    history: List<HistoryEntry>,
    onPlayVideo: (VideoItem) -> Unit,
    onClearHistory: () -> Unit
) {
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val topPad = if (isTablet) 88.dp else 14.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = topPad, bottom = 32.dp, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("History", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) {
                    Text(
                        text = "Clear local",
                        color = Color(0xFFFF6B6B),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable(onClick = onClearHistory)
                    )
                }
            }
        }
        if (history.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyStateCard("No watch history yet", "Videos you watch will appear here with automatic resume progress.")
            }
        } else {
            items(history, key = { "hist_${it.video.id}_${it.watchedAt}" }) { entry ->
                CinemaVideoCard(item = entry.video.copy(progressPercent = entry.progressPercent), showAvatar = true, onClick = { onPlayVideo(entry.video) })
            }
        }
    }
}

@Composable
fun SearchResultsScreen(
    isTablet: Boolean,
    query: String,
    results: List<VideoItem>,
    isLoading: Boolean,
    onPlayVideo: (VideoItem) -> Unit
) {
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val topPad = if (isTablet) 88.dp else 14.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = topPad, bottom = 32.dp, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("Results for \"$query\"", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        if (isLoading) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                }
            }
        } else if (results.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyStateCard("No results found", "Try a different search query.")
            }
        } else {
            items(results, key = { "sr_${it.id}" }) { item ->
                CinemaVideoCard(item = item, showAvatar = true, onClick = { onPlayVideo(item) })
            }
        }
    }
}

@Composable
fun ChannelScreen(
    isTablet: Boolean,
    channel: ChannelInfo?,
    isLoading: Boolean,
    isSubscribed: Boolean,
    onBack: () -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    if (isLoading && channel == null) {
        Box(modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
        }
        return
    }
    if (channel == null) {
        Box(modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack), contentAlignment = Alignment.Center) {
            Text("Channel unavailable", color = CinemaColors.TextSecondary)
        }
        return
    }

    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 24.dp else 16.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Box(modifier = Modifier.fillMaxWidth().height(if (isTablet) 230.dp else 180.dp).background(CinemaColors.SurfaceDark)) {
                if (channel.bannerUrl.isNotBlank()) {
                    AsyncImage(model = channel.bannerUrl, contentDescription = channel.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), CinemaColors.BgBlack))))
                Surface(
                    color = CinemaColors.GlassFill,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier.statusBarsPadding().padding(14.dp).size(40.dp).clickable(onClick = onBack)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = hPad),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                    ChannelAvatar(url = channel.avatarUrl, name = channel.name, size = if (isTablet) 60.dp else 50.dp)
                    Column {
                        Text(channel.name, color = Color.White, fontSize = if (isTablet) 21.sp else 18.sp, fontWeight = FontWeight.Bold)
                        if (channel.subscriberCount.isNotBlank()) {
                            Text(channel.subscriberCount, color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
                        }
                    }
                }
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable { onToggleSubscribe(SubscribedChannel(channel.id, channel.name, channel.avatarUrl)) }
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }

        items(channel.videos, key = { "ch_${it.id}" }) { vid ->
            Box(modifier = Modifier.padding(horizontal = if (isTablet) 14.dp else hPad)) {
                CinemaVideoCard(item = vid, showAvatar = false, onClick = { onPlayVideo(vid) })
            }
        }
    }
}

@Composable
private fun EmptyStateCard(title: String, subtitle: String) {
    Surface(
        color = CinemaColors.SurfaceDark,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Color.White, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = CinemaColors.TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
        }
    }
}
