package com.cinema.youtube.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Login
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.AppPrefs
import com.cinema.youtube.model.GoogleSession
import kotlinx.coroutines.launch

@Composable
fun AccountSheetDialog(
    session: GoogleSession?,
    prefs: AppPrefs,
    onStartGoogleSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onSyncNow: () -> Unit,
    onUpdatePrefs: (AppPrefs) -> Unit,
    onDismiss: () -> Unit
) {
    val isAr = prefs.languageCode == "ar"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xFF141418),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .fillMaxWidth()
                .widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "الحساب والإعدادات" else "Account & Settings",
                        color = Color.White,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = Color(0x1FFFFFFF),
                        shape = CircleShape,
                        modifier = Modifier
                            .size(34.dp)
                            .clickable(onClick = onDismiss)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Account Card
                Surface(
                    color = CinemaColors.SurfaceElevated,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (session != null && session.isValid) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                ChannelAvatar(
                                    url = session.avatarUrl,
                                    name = session.displayName.ifBlank { "G" },
                                    size = 50.dp
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = session.displayName.ifBlank { "Google Account" },
                                            color = Color.White,
                                            fontSize = 15.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Icon(
                                            Icons.Rounded.CheckCircle,
                                            contentDescription = null,
                                            tint = CinemaColors.AccentGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    if (session.email.isNotBlank()) {
                                        Text(
                                            text = session.email,
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 12.5.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = if (isAr) "متصل بحساب YouTube الخاص بك" else "Connected to YouTube",
                                        color = CinemaColors.AccentGreen,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = Color(0x24FFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            onSyncNow()
                                            onDismiss()
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Rounded.Sync, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "تحديث" else "Sync",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Surface(
                                    color = Color(0x28FF3B30),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable(onClick = onSignOut)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = Color(0xFFFF6B6B), modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "خروج" else "Sign Out",
                                            color = Color(0xFFFF6B6B),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color(0x24FFFFFF))
                                ) {
                                    Icon(Icons.Rounded.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                }
                                Column {
                                    Text(
                                        text = if (isAr) "سجّل دخولك بحساب Google" else "Sign in with Google",
                                        color = Color.White,
                                        fontSize = 15.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isAr) "لمزامنة الاشتراكات، القوائم، السجل، وفيديوهاتك المقترحة"
                                        else "Sync Subscriptions, Playlists, History & For You feed",
                                        color = CinemaColors.TextSecondary,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }

                            Button(
                                onClick = onStartGoogleSignIn,
                                shape = RoundedCornerShape(999.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Rounded.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = if (isAr) "تسجيل الدخول بحساب Google" else "Sign in with Google",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = CinemaColors.DividerSubtle)

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.Tune, contentDescription = null, tint = CinemaColors.TextSecondary, modifier = Modifier.size(18.dp))
                    Text(
                        text = if (isAr) "إعدادات التطبيق" else "App Settings",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isAr) "الدولة / المحتوى" else "Content Region", color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("EG" to "Egypt", "SA" to "Saudi", "US" to "Global").forEach { (code, label) ->
                            OptionChip(
                                label = label,
                                active = prefs.regionCode == code,
                                onClick = { onUpdatePrefs(prefs.copy(regionCode = code)) }
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isAr) "اللغة" else "Language", color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("ar" to "العربية", "en" to "English").forEach { (code, label) ->
                            OptionChip(
                                label = label,
                                active = prefs.languageCode == code,
                                onClick = { onUpdatePrefs(prefs.copy(languageCode = code)) }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isAr) "صورة داخل صورة تلقائياً (PiP)" else "Auto Picture-in-Picture",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isAr) "تصغير الفيديو عند الخروج من التطبيق" else "Keep playing in floating window when leaving app",
                            color = CinemaColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = prefs.autoPip,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(autoPip = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Color.White
                        )
                    )
                }

                Text(
                    text = "Cinema YouTube Native v3.0 · Ad-Free Engine",
                    color = CinemaColors.TextSecondary,
                    fontSize = 11.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun OptionChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (active) Color.White else Color(0x1EFFFFFF),
        shape = RoundedCornerShape(999.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            color = if (active) Color.Black else Color.White,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp)
        )
    }
}

/**
 * Full-Screen Direct Google Sign-In using Firefox Android User-Agent (avoids "; wv)" block)
 * and captures real YouTube SAPISID cookies to authenticate the entire native app.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GoogleWebSignInScreen(
    isAr: Boolean,
    onSignedIn: (GoogleSession) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val userAgents = remember {
        listOf(
            "Firefox" to "Mozilla/5.0 (Android 14; Mobile; rv:133.0) Gecko/133.0 Firefox/133.0",
            "Safari" to "Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1",
            "Desktop" to "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0"
        )
    }
    var uaIndex by remember { mutableIntStateOf(0) }
    var isLoadingPage by remember { mutableStateOf(true) }
    var capturingProfile by remember { mutableStateOf(false) }

    val loginUrl =
        "https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fm.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Dm%26next%3Dhttps%253A%252F%252Fm.youtube.com%252F"

    val webView = remember(context) {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(android.graphics.Color.parseColor("#0B0B0F"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.userAgentString = userAgents[0].second
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        }
    }

    fun tryCaptureSession() {
        if (capturingProfile) return
        val cm = CookieManager.getInstance()
        val ytCookies = listOf(
            cm.getCookie("https://www.youtube.com") ?: "",
            cm.getCookie("https://m.youtube.com") ?: ""
        ).firstOrNull { InnerTubeClient.extractSapisidFromCookies(it).isNotBlank() } ?: return

        val sapisid = InnerTubeClient.extractSapisidFromCookies(ytCookies)
        if (sapisid.isBlank()) return

        capturingProfile = true
        cm.flush()
        scope.launch {
            val base = GoogleSession(cookieHeader = ytCookies, sapisid = sapisid)
            val (name, email, avatar) = InnerTubeClient.fetchAccountProfile(base)
            onSignedIn(
                base.copy(
                    displayName = name,
                    email = email,
                    avatarUrl = avatar
                )
            )
        }
    }

    DisposableEffect(webView) {
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                isLoadingPage = newProgress < 90
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("intent://") || url.startsWith("vnd.youtube")) return true
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                isLoadingPage = false
                if (url != null && url.contains("youtube.com")) {
                    tryCaptureSession()
                }
            }
        }
        webView.loadUrl(loginUrl)
        onDispose {
            webView.stopLoading()
            webView.destroy()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BarDark)
            .statusBarsPadding()
    ) {
        // Clean Sign-In Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Color(0x1EFFFFFF),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(36.dp)
                        .clickable(onClick = onDismiss)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(19.dp))
                    }
                }
                Text(
                    text = if (isAr) "تسجيل الدخول بحساب Google" else "Sign in with Google",
                    color = Color.White,
                    fontSize = 15.5.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Browser Mode Switcher Pill (in case Google asks to switch browser profile)
            Surface(
                color = Color(0x1FFFFFFF),
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                modifier = Modifier.clickable {
                    uaIndex = (uaIndex + 1) % userAgents.size
                    webView.settings.userAgentString = userAgents[uaIndex].second
                    webView.loadUrl(loginUrl)
                }
            ) {
                Text(
                    text = "Mode: ${userAgents[uaIndex].first}",
                    color = Color.White,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                )
            }
        }

        if (isLoadingPage || capturingProfile) {
            LinearProgressIndicator(
                color = Color.White,
                trackColor = Color(0x22FFFFFF),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
            )
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { (webView.parent as? ViewGroup)?.removeView(webView); webView },
                modifier = Modifier.fillMaxSize()
            )

            if (capturingProfile) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xCC060608)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                        Text(
                            text = if (isAr) "تم تسجيل الدخول! جاري مزامنة حسابك..." else "Signed in! Syncing your YouTube account...",
                            color = Color.White,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
