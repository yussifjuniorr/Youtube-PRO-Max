package com.cinema.youtube.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration

object CinemaColors {
    val BgBlack = Color(0xFF060608)
    val BarDark = Color(0xFF0B0B0F)
    val SurfaceDark = Color(0xFF141418)
    val SurfaceElevated = Color(0xFF1C1C22)
    val GlassFill = Color(0xE01A1A20)
    val GlassStrong = Color(0xF5141418)
    val GlassStroke = Color(0x24FFFFFF)
    val DividerSubtle = Color(0x16FFFFFF)
    val TextPrimary = Color(0xFFF5F5F7)
    val TextSecondary = Color(0xA6EBEBF5)
    val YtRed = Color(0xFFFF0033)
    val PillActiveBg = Color(0xF5FFFFFF)
    val PillActiveText = Color(0xFF000000)
    val AccentGreen = Color(0xFF34C759)
}

private val CinemaDarkScheme = darkColorScheme(
    primary = CinemaColors.TextPrimary,
    onPrimary = Color.Black,
    secondary = CinemaColors.YtRed,
    background = CinemaColors.BgBlack,
    surface = CinemaColors.SurfaceDark,
    onBackground = CinemaColors.TextPrimary,
    onSurface = CinemaColors.TextPrimary
)

@Composable
fun rememberIsTablet(): Boolean {
    val config = LocalConfiguration.current
    return config.screenWidthDp >= 600
}

@Composable
fun CinemaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CinemaDarkScheme,
        content = content
    )
}
