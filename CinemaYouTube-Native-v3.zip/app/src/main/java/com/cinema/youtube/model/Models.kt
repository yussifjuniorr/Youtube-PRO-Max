package com.cinema.youtube.model

data class VideoItem(
    val id: String,
    val title: String,
    val channelName: String,
    val channelId: String = "",
    val channelAvatar: String = "",
    val duration: String = "",
    val meta: String = "",
    val progressPercent: Int = 0,
    val thumbnailUrl: String = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
    val heroThumbnailUrl: String = "https://i.ytimg.com/vi/$id/maxresdefault.jpg"
)

data class HomeShelf(
    val title: String,
    val videos: List<VideoItem>
)

data class ChannelInfo(
    val id: String,
    val name: String,
    val avatarUrl: String,
    val bannerUrl: String,
    val subscriberCount: String,
    val description: String,
    val videos: List<VideoItem>
)

data class VideoDetails(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String,
    val channelAvatar: String,
    val viewCount: String,
    val publishDate: String,
    val description: String,
    val likeCount: String,
    val subscriberCount: String,
    val relatedVideos: List<VideoItem>,
    val commentsContinuation: String?
)

data class CommentItem(
    val author: String,
    val avatarUrl: String,
    val text: String,
    val publishedTime: String,
    val likeCount: String
)

data class SubscribedChannel(
    val id: String,
    val name: String,
    val avatarUrl: String
)

data class UserPlaylist(
    val id: String,
    val name: String,
    val videos: List<VideoItem>,
    val isRemote: Boolean = false,
    val thumbnailUrl: String = "",
    val videoCountText: String = ""
)

data class HistoryEntry(
    val video: VideoItem,
    val positionMs: Long,
    val durationMs: Long,
    val watchedAt: Long
) {
    val progressPercent: Int
        get() = if (durationMs > 1000L) {
            ((positionMs * 100L) / durationMs).toInt().coerceIn(0, 100)
        } else video.progressPercent
}

data class GoogleSession(
    val cookieHeader: String,
    val sapisid: String,
    val displayName: String = "",
    val email: String = "",
    val avatarUrl: String = ""
) {
    val isValid: Boolean
        get() = cookieHeader.isNotBlank() && sapisid.isNotBlank()
}

data class AppPrefs(
    val regionCode: String = "EG",
    val languageCode: String = "ar",
    val autoPip: Boolean = true
)
