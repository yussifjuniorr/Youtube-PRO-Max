package com.cinema.youtube.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.rounded.ThumbUpOffAlt
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.cinema.youtube.data.AdBlockEngine
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.GoogleSession
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem

private enum class TabletWatchTab { UP_NEXT, COMMENTS, DETAILS }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WatchScreen(
    video: VideoItem,
    initialPositionSec: Long,
    gl: String,
    hl: String,
    session: GoogleSession?,
    isTablet: Boolean,
    isLandscape: Boolean,
    isInPipMode: Boolean,
    isLiked: Boolean,
    isSubscribed: (String) -> Boolean,
    playlists: List<UserPlaylist>,
    onToggleLike: (String) -> Unit,
    onSetLandscape: (Boolean) -> Unit,
    onEnterPip: () -> Unit,
    onBack: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onToggleVideoInPlaylist: (String, VideoItem) -> Unit,
    onSaveProgress: (VideoItem, Long, Long) -> Unit
) {
    val context = LocalContext.current

    var details by remember(video.id) { mutableStateOf<VideoDetails?>(null) }
    var comments by remember(video.id) { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsLoaded by remember(video.id) { mutableStateOf(false) }

    var playerReady by remember(video.id) { mutableStateOf(false) }
    var reloadNonce by remember(video.id) { mutableIntStateOf(0) }

    var showCommentsSheet by remember(video.id) { mutableStateOf(false) }
    var showDescriptionSheet by remember(video.id) { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var tabletTab by remember { mutableStateOf(TabletWatchTab.UP_NEXT) }

    val latestVideo by rememberUpdatedState(video)
    val latestDetails by rememberUpdatedState(details)
    val latestOnSaveProgress by rememberUpdatedState(onSaveProgress)
    val latestOnOpenVideo by rememberUpdatedState(onOpenVideo)
    val latestOnSetLandscape by rememberUpdatedState(onSetLandscape)

    // Persistent FrameLayout + Hardware-Accelerated WebView (survives Portrait <-> Landscape without reloading!)
    val playerContainer = remember(context) {
        FrameLayout(context).apply {
            setBackgroundColor(AndroidColor.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }

    val webView = remember(context) {
        WebView(context).apply {
            setBackgroundColor(AndroidColor.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36"

            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            addJavascriptInterface(
                object {
                    @JavascriptInterface
                    fun onProgress(posMs: Long, durMs: Long) {
                        post {
                            val d = latestDetails
                            val v = latestVideo
                            val enriched = v.copy(
                                title = d?.title?.ifBlank { v.title } ?: v.title,
                                channelName = d?.channelName?.ifBlank { v.channelName } ?: v.channelName,
                                channelId = d?.channelId?.ifBlank { v.channelId } ?: v.channelId,
                                channelAvatar = d?.channelAvatar?.ifBlank { v.channelAvatar } ?: v.channelAvatar
                            )
                            latestOnSaveProgress(enriched, posMs, durMs)
                        }
                    }

                    @JavascriptInterface
                    fun onVideoEnded() {
                        post {
                            val next = latestDetails?.relatedVideos?.firstOrNull()
                            if (next != null) {
                                latestOnOpenVideo(next)
                            }
                        }
                    }
                },
                "CinemaBridge"
            )
        }
    }

    // Attach WebView + Handle HTML5 Fullscreen CustomView & Ad Blocking cleanly
    DisposableEffect(webView, playerContainer) {
        var customFullscreenView: View? = null
        var customViewCallback: WebChromeClient.CustomViewCallback? = null

        if (webView.parent == null) {
            playerContainer.addView(webView)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                if (customFullscreenView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customFullscreenView = view
                customViewCallback = callback
                view.setBackgroundColor(AndroidColor.BLACK)
                playerContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                latestOnSetLandscape(true)
            }

            override fun onHideCustomView() {
                customFullscreenView?.let { playerContainer.removeView(it) }
                customFullscreenView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                latestOnSetLandscape(false)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                if (AdBlockEngine.isAdRequest(request?.url)) {
                    return AdBlockEngine.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: ""
                if (scheme != "http" && scheme != "https") return true

                val host = uri.host?.lowercase() ?: ""
                if (host.contains("youtube.com") || host == "youtu.be") {
                    val targetId = uri.getQueryParameter("v")
                        ?: if (host == "youtu.be") uri.lastPathSegment else null
                    if (!targetId.isNullOrBlank() && targetId.length == 11 && targetId != latestVideo.id) {
                        latestOnOpenVideo(VideoItem(id = targetId, title = "Loading...", channelName = ""))
                        return true
                    }
                    return false
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                view?.evaluateJavascript(AdBlockEngine.PLAYER_ISOLATION_AND_ADBLOCK_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(AdBlockEngine.PLAYER_ISOLATION_AND_ADBLOCK_JS, null)
                playerReady = true
            }
        }

        onDispose {
            customFullscreenView?.let { playerContainer.removeView(it) }
            customViewCallback?.onCustomViewHidden()
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.onPause()
            playerContainer.removeAllViews()
            webView.destroy()
        }
    }

    // Load video into Ad-Free YouTube HTML5 Engine whenever video.id or reloadNonce changes
    LaunchedEffect(video.id, reloadNonce) {
        playerReady = false
        val startParam = if (initialPositionSec > 5L) "&t=${initialPositionSec}s" else ""
        val watchUrl = "https://m.youtube.com/watch?v=${video.id}$startParam"
        webView.loadUrl(watchUrl)
    }

    // Fetch Native Metadata, Related Videos & Comments in parallel
    LaunchedEffect(video.id) {
        details = InnerTubeClient.fetchWatchDetails(video.id, gl, hl, session)
        val token = details?.commentsContinuation
        if (!token.isNullOrBlank()) {
            comments = InnerTubeClient.fetchComments(token, gl, hl)
            commentsLoaded = true
        }
    }

    val displayTitle = details?.title?.ifBlank { video.title } ?: video.title
    val displayChannel = details?.channelName?.ifBlank { video.channelName } ?: video.channelName
    val displayChannelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId
    val displayAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
    val relatedVideos = details?.relatedVideos ?: emptyList()

    fun shareCurrentVideo() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, displayTitle)
            putExtra(Intent.EXTRA_TEXT, "$displayTitle\nhttps://youtu.be/${video.id}")
        }
        runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share video")) }
    }

    // Single persistent PlayerBox that NEVER unmounts during rotation or PiP!
    val showSideBySideTablet = isTablet && !isLandscape && !isInPipMode
    val showFullScreenOnly = isLandscape || isInPipMode

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack)
    ) {
        if (showSideBySideTablet) {
            // TABLET SPLIT CINEMA LAYOUT (Player + Video Info on Left | Tabs Panel on Right)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                WatchTopStrip(
                    title = displayTitle,
                    isLandscape = false,
                    onBack = onBack,
                    onReload = { reloadNonce++ },
                    onPip = onEnterPip,
                    onToggleFullscreen = { onSetLandscape(true) }
                )

                Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    // Left 65%: 16:9 Player + Title + Channel + Actions
                    Column(
                        modifier = Modifier
                            .weight(0.64f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(start = 18.dp, end = 12.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color.Black)
                        ) {
                            AndroidView(
                                factory = {
                                    (playerContainer.parent as? ViewGroup)?.removeView(playerContainer)
                                    playerContainer
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                            if (!playerReady) {
                                CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp, modifier = Modifier.align(Alignment.Center).size(36.dp))
                            }
                        }

                        WatchInfoSection(
                            displayTitle = displayTitle,
                            displayChannel = displayChannel,
                            displayChannelId = displayChannelId,
                            displayAvatar = displayAvatar,
                            details = details,
                            isLiked = isLiked,
                            isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                            onOpenDescription = { tabletTab = TabletWatchTab.DETAILS },
                            onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                            onToggleSubscribe = {
                                if (displayChannelId.isNotBlank()) {
                                    onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                                }
                            },
                            onToggleLike = { onToggleLike(video.id) },
                            onSave = { showPlaylistDialog = true },
                            onShare = { shareCurrentVideo() }
                        )
                    }

                    // Right 36%: Sleek Cinema Panel (Up Next / Comments / Details)
                    Surface(
                        color = CinemaColors.SurfaceDark,
                        shape = RoundedCornerShape(topStart = 20.dp),
                        border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                        modifier = Modifier
                            .weight(0.36f)
                            .fillMaxHeight()
                            .padding(end = 12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    TabletWatchTab.UP_NEXT to "Up next",
                                    TabletWatchTab.COMMENTS to "Comments",
                                    TabletWatchTab.DETAILS to "Details"
                                ).forEach { (tab, label) ->
                                    val active = tabletTab == tab
                                    Surface(
                                        color = if (active) Color.White else Color(0x1AFFFFFF),
                                        shape = RoundedCornerShape(999.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { tabletTab = tab }
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (active) Color.Black else Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 8.dp)
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = CinemaColors.DividerSubtle)
                            Box(modifier = Modifier.weight(1f)) {
                                when (tabletTab) {
                                    TabletWatchTab.UP_NEXT -> UpNextCompactList(relatedVideos, onOpenVideo)
                                    TabletWatchTab.COMMENTS -> CommentsListBody(comments, !commentsLoaded && details?.commentsContinuation != null)
                                    TabletWatchTab.DETAILS -> DescriptionBody(details)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // MOBILE PORTRAIT OR FULLSCREEN LANDSCAPE / PiP
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (!showFullScreenOnly) Modifier.statusBarsPadding() else Modifier)
            ) {
                if (!showFullScreenOnly) {
                    WatchTopStrip(
                        title = displayChannel.ifBlank { "Cinema Player" },
                        isLandscape = false,
                        onBack = onBack,
                        onReload = { reloadNonce++ },
                        onPip = onEnterPip,
                        onToggleFullscreen = { onSetLandscape(true) }
                    )
                }

                // Persistent Player Viewport (Never unmounts when toggling Fullscreen!)
                Box(
                    modifier = if (showFullScreenOnly) {
                        Modifier.fillMaxSize().background(Color.Black)
                    } else {
                        Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)
                    }
                ) {
                    AndroidView(
                        factory = {
                            (playerContainer.parent as? ViewGroup)?.removeView(playerContainer)
                            playerContainer
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    if (!playerReady && !isInPipMode) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.align(Alignment.Center).size(36.dp)
                        )
                    }

                    // Minimal Exit-Fullscreen Button in Landscape (discreet top-start corner)
                    if (isLandscape && !isInPipMode) {
                        Surface(
                            color = Color(0x88000000),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, Color(0x28FFFFFF)),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .size(38.dp)
                                .clickable { onSetLandscape(false) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.FullscreenExit, contentDescription = "Exit Fullscreen", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }

                // Mobile Portrait Below-Video Native Feed
                if (!showFullScreenOnly) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .navigationBarsPadding(),
                        contentPadding = PaddingValues(bottom = 28.dp)
                    ) {
                        item(key = "watch_info") {
                            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                                WatchInfoSection(
                                    displayTitle = displayTitle,
                                    displayChannel = displayChannel,
                                    displayChannelId = displayChannelId,
                                    displayAvatar = displayAvatar,
                                    details = details,
                                    isLiked = isLiked,
                                    isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                                    onOpenDescription = { showDescriptionSheet = true },
                                    onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                                    onToggleSubscribe = {
                                        if (displayChannelId.isNotBlank()) {
                                            onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                                        }
                                    },
                                    onToggleLike = { onToggleLike(video.id) },
                                    onSave = { showPlaylistDialog = true },
                                    onShare = { shareCurrentVideo() }
                                )
                            }
                        }

                        // Comments Preview Card
                        item(key = "comments_preview") {
                            Surface(
                                color = CinemaColors.SurfaceDark,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp)
                                    .clickable { showCommentsSheet = true }
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (comments.isNotEmpty()) "Comments (${comments.size}+)" else "Comments",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text("View all", color = CinemaColors.TextSecondary, fontSize = 12.sp)
                                    }
                                    val top = comments.firstOrNull()
                                    if (top != null) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            ChannelAvatar(url = top.avatarUrl, name = top.author, size = 26.dp)
                                            Text(
                                                text = top.text,
                                                color = CinemaColors.TextPrimary,
                                                fontSize = 12.5.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = if (!commentsLoaded && details?.commentsContinuation != null) "Loading comments..." else "Tap to read comments",
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 12.5.sp
                                        )
                                    }
                                }
                            }
                        }

                        item(key = "up_next_header") {
                            Text(
                                text = "Up next",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 10.dp)
                            )
                        }

                        if (relatedVideos.isEmpty()) {
                            item(key = "up_next_spinner") {
                                Box(
                                    modifier = Modifier.fillMaxWidth().height(100.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
                                }
                            }
                        } else {
                            items(relatedVideos, key = { "rel_${it.id}" }) { rel ->
                                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                    CinemaVideoCard(item = rel, showAvatar = true, onClick = { onOpenVideo(rel) })
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Sheets (Comments / Description / Playlists)
        if (showCommentsSheet) {
            WatchSheetOverlay(title = "Comments", onDismiss = { showCommentsSheet = false }) {
                CommentsListBody(comments, !commentsLoaded && details?.commentsContinuation != null)
            }
        }

        if (showDescriptionSheet) {
            WatchSheetOverlay(title = "Description", onDismiss = { showDescriptionSheet = false }) {
                DescriptionBody(details)
            }
        }

        if (showPlaylistDialog) {
            val localPlaylists = playlists.filterNot { it.isRemote }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlaylistDialog = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(24.dp)
                        .widthIn(max = 320.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Save to Playlist", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        val richVideo = video.copy(
                            title = displayTitle,
                            channelName = displayChannel,
                            channelId = displayChannelId,
                            channelAvatar = displayAvatar
                        )
                        localPlaylists.forEach { pl ->
                            val saved = pl.videos.any { it.id == video.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x14FFFFFF))
                                    .clickable { onToggleVideoInPlaylist(pl.id, richVideo) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(pl.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                if (saved) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WatchTopStrip(
    title: String,
    isLandscape: Boolean,
    onBack: () -> Unit,
    onReload: () -> Unit,
    onPip: () -> Unit,
    onToggleFullscreen: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CinemaColors.BarDark)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBack)
                    .padding(6.dp)
            )
            Text(
                text = title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = "Reload",
                tint = CinemaColors.TextSecondary,
                modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onReload).padding(7.dp)
            )
            Icon(
                imageVector = Icons.Rounded.PictureInPictureAlt,
                contentDescription = "PiP",
                tint = Color.White,
                modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onPip).padding(7.dp)
            )
            Icon(
                imageVector = if (isLandscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                contentDescription = "Fullscreen",
                tint = Color.White,
                modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onToggleFullscreen).padding(6.dp)
            )
        }
    }
}

@Composable
private fun WatchInfoSection(
    displayTitle: String,
    displayChannel: String,
    displayChannelId: String,
    displayAvatar: String,
    details: VideoDetails?,
    isLiked: Boolean,
    isSubscribed: Boolean,
    onOpenDescription: () -> Unit,
    onOpenChannel: () -> Unit,
    onToggleSubscribe: () -> Unit,
    onToggleLike: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenDescription),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = displayTitle,
                color = Color.White,
                fontSize = 17.5.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 23.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val metaLine = listOfNotNull(
                details?.viewCount?.takeIf { it.isNotBlank() },
                details?.publishDate?.takeIf { it.isNotBlank() },
                "more"
            ).joinToString(" · ")
            Text(text = metaLine, color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onOpenChannel)
            ) {
                ChannelAvatar(url = displayAvatar, name = displayChannel, size = 40.dp)
                Column {
                    Text(
                        text = displayChannel.ifBlank { "Channel" },
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    details?.subscriberCount?.takeIf { it.isNotBlank() }?.let {
                        Text(it, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                    }
                }
            }

            if (displayChannelId.isNotBlank()) {
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onToggleSubscribe)
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                WatchActionPill(
                    icon = if (isLiked) Icons.Rounded.ThumbUp else Icons.Rounded.ThumbUpOffAlt,
                    label = details?.likeCount?.takeIf { it.isNotBlank() } ?: "Like",
                    active = isLiked,
                    onClick = onToggleLike
                )
            }
            item {
                WatchActionPill(icon = Icons.Rounded.BookmarkAdd, label = "Save", onClick = onSave)
            }
            item {
                WatchActionPill(icon = Icons.Rounded.Share, label = "Share", onClick = onShare)
            }
        }
    }
}

@Composable
private fun WatchActionPill(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) Color.White else CinemaColors.SurfaceElevated,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, if (active) Color.White else CinemaColors.DividerSubtle),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(17.dp))
            Text(label, color = if (active) Color.Black else Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun WatchSheetOverlay(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            color = CinemaColors.GlassStrong,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.68f)
                .navigationBarsPadding()
                .clickable(enabled = false) {}
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp).clip(CircleShape).clickable(onClick = onDismiss).padding(4.dp)
                    )
                }
                HorizontalDivider(color = CinemaColors.DividerSubtle)
                Box(modifier = Modifier.weight(1f)) { content() }
            }
        }
    }
}

@Composable
private fun DescriptionBody(details: VideoDetails?) {
    val desc = details?.description ?: ""
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!details?.title.isNullOrBlank()) {
            Text(details!!.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        val meta = listOfNotNull(
            details?.viewCount?.takeIf { it.isNotBlank() },
            details?.publishDate?.takeIf { it.isNotBlank() }
        ).joinToString(" · ")
        if (meta.isNotBlank()) {
            Text(meta, color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }
        if (desc.isNotBlank()) {
            Text(desc, color = CinemaColors.TextPrimary, fontSize = 13.5.sp, lineHeight = 20.sp)
        } else {
            Text("No description available.", color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CommentsListBody(comments: List<CommentItem>, loading: Boolean) {
    when {
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        comments.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No comments available", color = CinemaColors.TextSecondary, fontSize = 14.sp)
        }
        else -> LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(comments) { c ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ChannelAvatar(url = c.avatarUrl, name = c.author, size = 32.dp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(c.author, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (c.publishedTime.isNotBlank()) {
                                Text(c.publishedTime, color = CinemaColors.TextSecondary, fontSize = 11.sp)
                            }
                        }
                        Text(c.text, color = CinemaColors.TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
                        if (c.likeCount.isNotBlank()) {
                            Text("👍 ${c.likeCount}", color = CinemaColors.TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpNextCompactList(related: List<VideoItem>, onSelect: (VideoItem) -> Unit) {
    if (related.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(related, key = { "tn_${it.id}" }) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelect(item) }
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(126.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(CinemaColors.SurfaceElevated)
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (item.duration.isNotBlank()) {
                        Text(
                            text = item.duration,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .background(Color(0xC2000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 1.5.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(item.title, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.channelName, color = CinemaColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
