package com.cinema.youtube

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.webkit.CookieManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.data.LocalStore
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.HistoryEntry
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoItem
import com.cinema.youtube.ui.AccountSheetDialog
import com.cinema.youtube.ui.ChannelScreen
import com.cinema.youtube.ui.CinemaColors
import com.cinema.youtube.ui.CinemaTheme
import com.cinema.youtube.ui.GoogleWebSignInScreen
import com.cinema.youtube.ui.HistoryScreen
import com.cinema.youtube.ui.HomeScreen
import com.cinema.youtube.ui.MobileDockedBottomNav
import com.cinema.youtube.ui.MobileTopBar
import com.cinema.youtube.ui.PlaylistsScreen
import com.cinema.youtube.ui.SearchResultsScreen
import com.cinema.youtube.ui.SubscriptionsScreen
import com.cinema.youtube.ui.TabletFloatingTopNav
import com.cinema.youtube.ui.TopTab
import com.cinema.youtube.ui.WatchScreen
import com.cinema.youtube.ui.rememberIsTablet
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var store: LocalStore
    private var isInPipState by mutableStateOf(false)
    private var isWatchingNow = false
    private var autoPipEnabled = true

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipState = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isWatchingNow && autoPipEnabled) {
            enterCinemaPip()
        }
    }

    private fun enterCinemaPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runCatching {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.parseColor("#0B0B0F"))
        )
        store = LocalStore(applicationContext)

        setContent {
            CinemaTheme {
                val scope = rememberCoroutineScope()
                val isTablet = rememberIsTablet()
                val config = LocalConfiguration.current
                val isPhysicalLandscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE

                var appPrefs by remember { mutableStateOf(store.getAppPrefs()) }
                var googleSession by remember { mutableStateOf(store.getGoogleSession()) }

                var localSubscriptions by remember { mutableStateOf(store.getSubscriptions()) }
                var remoteSubscriptions by remember { mutableStateOf<List<SubscribedChannel>>(emptyList()) }
                var localPlaylists by remember { mutableStateOf(store.getPlaylists()) }
                var remotePlaylists by remember { mutableStateOf<List<UserPlaylist>>(emptyList()) }
                var remotePlaylistVideos by remember { mutableStateOf<Map<String, List<VideoItem>>>(emptyMap()) }
                var loadingRemotePlaylistId by remember { mutableStateOf<String?>(null) }

                var localHistory by remember { mutableStateOf(store.getHistory()) }
                var remoteHistory by remember { mutableStateOf<List<HistoryEntry>>(emptyList()) }
                var likedIds by remember { mutableStateOf(store.getLikedIds()) }
                var recentSearches by remember { mutableStateOf(store.getRecentSearches()) }

                var activeTab by remember { mutableStateOf(TopTab.HOME) }
                var isSearching by remember { mutableStateOf(false) }
                var searchText by remember { mutableStateOf("") }
                var activeSearchQuery by remember { mutableStateOf<String?>(null) }
                var searchResults by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var searchLoading by remember { mutableStateOf(false) }

                var heroVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var homeShelves by remember { mutableStateOf<List<HomeShelf>>(emptyList()) }
                var subFeedVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var homeLoading by remember { mutableStateOf(true) }
                var syncNonce by remember { mutableIntStateOf(0) }

                var activeChannelId by remember { mutableStateOf<String?>(null) }
                var activeChannelInfo by remember { mutableStateOf<ChannelInfo?>(null) }
                var channelLoading by remember { mutableStateOf(false) }

                var watchingVideo by remember { mutableStateOf<VideoItem?>(null) }
                var manualLandscape by remember { mutableStateOf(false) }
                var showAccountDialog by remember { mutableStateOf(false) }
                var showGoogleSignInScreen by remember { mutableStateOf(false) }

                val effectiveLandscape = watchingVideo != null && (manualLandscape || isPhysicalLandscape)

                LaunchedEffect(watchingVideo, appPrefs.autoPip) {
                    isWatchingNow = watchingVideo != null
                    autoPipEnabled = appPrefs.autoPip
                }

                fun setImmersive(enabled: Boolean) {
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    if (enabled) {
                        controller.systemBarsBehavior =
                            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        controller.hide(WindowInsetsCompat.Type.systemBars())
                    } else {
                        controller.show(WindowInsetsCompat.Type.systemBars())
                    }
                }

                LaunchedEffect(effectiveLandscape, isInPipState) {
                    setImmersive(effectiveLandscape && !isInPipState)
                }

                fun updateLandscape(landscape: Boolean) {
                    manualLandscape = landscape
                    requestedOrientation = if (landscape) {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }
                }

                // Load Home + Real Account Sync
                LaunchedEffect(appPrefs.regionCode, appPrefs.languageCode, googleSession?.sapisid, syncNonce) {
                    homeLoading = true
                    val sess = googleSession?.takeIf { it.isValid }
                    val (hero, shelves) = InnerTubeClient.fetchHomeShelves(
                        gl = appPrefs.regionCode,
                        hl = appPrefs.languageCode,
                        subscriptions = localSubscriptions,
                        session = sess
                    )
                    heroVideos = hero
                    homeShelves = shelves
                    homeLoading = false

                    if (sess != null) {
                        launch {
                            val (rSubs, rSubVids) = InnerTubeClient.fetchAuthSubscriptions(sess, appPrefs.regionCode, appPrefs.languageCode)
                            remoteSubscriptions = rSubs
                            if (rSubVids.isNotEmpty()) subFeedVideos = rSubVids
                        }
                        launch {
                            remotePlaylists = InnerTubeClient.fetchAuthPlaylists(sess, appPrefs.regionCode, appPrefs.languageCode)
                        }
                        launch {
                            val histVids = InnerTubeClient.fetchAuthHistory(sess, appPrefs.regionCode, appPrefs.languageCode)
                            val now = System.currentTimeMillis()
                            remoteHistory = histVids.mapIndexed { idx, v -> HistoryEntry(v, 0L, 0L, now - idx * 1000L) }
                        }
                    } else {
                        remoteSubscriptions = emptyList()
                        remotePlaylists = emptyList()
                        remoteHistory = emptyList()
                        subFeedVideos = InnerTubeClient.fetchSubscriptionFeed(localSubscriptions)
                    }
                }

                LaunchedEffect(localSubscriptions, googleSession) {
                    if (googleSession == null || !googleSession!!.isValid) {
                        subFeedVideos = InnerTubeClient.fetchSubscriptionFeed(localSubscriptions)
                    }
                }

                LaunchedEffect(activeChannelId) {
                    val cid = activeChannelId ?: return@LaunchedEffect
                    channelLoading = true
                    activeChannelInfo = null
                    activeChannelInfo = InnerTubeClient.fetchChannel(cid, appPrefs.regionCode, appPrefs.languageCode, googleSession)
                    channelLoading = false
                }

                BackHandler(
                    enabled = showGoogleSignInScreen ||
                        watchingVideo != null ||
                        activeChannelId != null ||
                        activeSearchQuery != null ||
                        isSearching ||
                        activeTab != TopTab.HOME
                ) {
                    when {
                        showGoogleSignInScreen -> showGoogleSignInScreen = false
                        watchingVideo != null && manualLandscape -> updateLandscape(false)
                        watchingVideo != null -> {
                            updateLandscape(false)
                            watchingVideo = null
                        }
                        activeChannelId != null -> activeChannelId = null
                        isSearching -> {
                            isSearching = false
                            searchText = ""
                        }
                        activeSearchQuery != null -> {
                            activeSearchQuery = null
                            searchResults = emptyList()
                        }
                        activeTab != TopTab.HOME -> activeTab = TopTab.HOME
                    }
                }

                val mergedSubscriptions = remember(remoteSubscriptions, localSubscriptions) {
                    (remoteSubscriptions + localSubscriptions).distinctBy { it.id }
                }
                val mergedPlaylists = remember(remotePlaylists, localPlaylists) {
                    remotePlaylists + localPlaylists
                }
                val mergedHistory = remember(localHistory, remoteHistory) {
                    (localHistory + remoteHistory).distinctBy { it.video.id }
                }
                val continueWatching = remember(mergedHistory) {
                    mergedHistory
                        .filter { it.progressPercent in 3..94 }
                        .map { it.video.copy(progressPercent = it.progressPercent) }
                        .take(12)
                }

                fun submitSearch(q: String) {
                    val cleaned = q.trim()
                    if (cleaned.isNotEmpty()) {
                        isSearching = false
                        activeSearchQuery = cleaned
                        recentSearches = store.addRecentSearch(cleaned)
                        scope.launch {
                            searchLoading = true
                            searchResults = InnerTubeClient.searchVideos(
                                cleaned,
                                appPrefs.regionCode,
                                appPrefs.languageCode,
                                googleSession
                            )
                            searchLoading = false
                        }
                    }
                }

                val currentWatch = watchingVideo
                val currentChannel = activeChannelId

                Box(modifier = Modifier.fillMaxSize().background(CinemaColors.BgBlack)) {
                    when {
                        showGoogleSignInScreen -> {
                            GoogleWebSignInScreen(
                                isAr = appPrefs.languageCode == "ar",
                                onSignedIn = { newSession ->
                                    store.saveGoogleSession(newSession)
                                    googleSession = newSession
                                    showGoogleSignInScreen = false
                                    syncNonce++
                                },
                                onDismiss = { showGoogleSignInScreen = false }
                            )
                        }

                        currentWatch != null -> {
                            WatchScreen(
                                video = currentWatch,
                                initialPositionSec = store.getSavedPositionSec(currentWatch.id),
                                gl = appPrefs.regionCode,
                                hl = appPrefs.languageCode,
                                session = googleSession,
                                isTablet = isTablet,
                                isLandscape = effectiveLandscape,
                                isInPipMode = isInPipState,
                                isLiked = likedIds.contains(currentWatch.id),
                                isSubscribed = { cid -> mergedSubscriptions.any { it.id == cid } },
                                playlists = mergedPlaylists,
                                onToggleLike = { vidId ->
                                    val nowLiked = !likedIds.contains(vidId)
                                    likedIds = store.toggleLikedId(vidId)
                                    scope.launch { InnerTubeClient.syncLikeVideo(vidId, nowLiked, googleSession) }
                                },
                                onSetLandscape = { updateLandscape(it) },
                                onEnterPip = { enterCinemaPip() },
                                onBack = {
                                    updateLandscape(false)
                                    watchingVideo = null
                                },
                                onOpenVideo = { nextVid -> watchingVideo = nextVid },
                                onOpenChannel = { cid ->
                                    updateLandscape(false)
                                    watchingVideo = null
                                    activeChannelId = cid
                                },
                                onToggleSubscribe = { ch ->
                                    val willSub = mergedSubscriptions.none { it.id == ch.id }
                                    localSubscriptions = store.toggleSubscription(ch)
                                    scope.launch { InnerTubeClient.syncSubscribeChannel(ch.id, willSub, googleSession) }
                                },
                                onToggleVideoInPlaylist = { plId, v ->
                                    localPlaylists = store.toggleVideoInPlaylist(plId, v)
                                },
                                onSaveProgress = { v, pos, dur ->
                                    localHistory = store.saveHistoryEntry(v, pos, dur)
                                }
                            )
                        }

                        currentChannel != null -> {
                            ChannelScreen(
                                isTablet = isTablet,
                                channel = activeChannelInfo,
                                isLoading = channelLoading,
                                isSubscribed = mergedSubscriptions.any { it.id == currentChannel },
                                onBack = { activeChannelId = null },
                                onToggleSubscribe = { ch ->
                                    val willSub = mergedSubscriptions.none { it.id == ch.id }
                                    localSubscriptions = store.toggleSubscription(ch)
                                    scope.launch { InnerTubeClient.syncSubscribeChannel(ch.id, willSub, googleSession) }
                                },
                                onPlayVideo = { vid -> watchingVideo = vid }
                            )
                        }

                        else -> {
                            // Main Browse Experience: Docked Scaffold on Mobile (ZERO Overlap) vs Floating Cinema Chrome on Tablet
                            Scaffold(
                                containerColor = CinemaColors.BgBlack,
                                topBar = {
                                    if (!isTablet) {
                                        MobileTopBar(
                                            session = googleSession,
                                            isSearching = isSearching,
                                            searchText = searchText,
                                            recentSearches = recentSearches,
                                            hl = appPrefs.languageCode,
                                            onLogoClick = {
                                                activeSearchQuery = null
                                                activeTab = TopTab.HOME
                                            },
                                            onSearchModeChange = { isSearching = it },
                                            onSearchTextChange = { searchText = it },
                                            onSubmitSearch = { submitSearch(it) },
                                            onClearRecentSearches = {
                                                store.clearRecentSearches()
                                                recentSearches = emptyList()
                                            },
                                            onOpenAccount = { showAccountDialog = true }
                                        )
                                    }
                                },
                                bottomBar = {
                                    if (!isTablet) {
                                        MobileDockedBottomNav(
                                            activeTab = activeTab,
                                            onTabSelected = { tab ->
                                                isSearching = false
                                                activeSearchQuery = null
                                                activeTab = tab
                                            }
                                        )
                                    }
                                }
                            ) { innerPadding ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(innerPadding)
                                ) {
                                    if (activeSearchQuery != null) {
                                        SearchResultsScreen(
                                            isTablet = isTablet,
                                            query = activeSearchQuery ?: "",
                                            results = searchResults,
                                            isLoading = searchLoading,
                                            onPlayVideo = { vid -> watchingVideo = vid }
                                        )
                                    } else {
                                        when (activeTab) {
                                            TopTab.HOME -> HomeScreen(
                                                isTablet = isTablet,
                                                heroVideos = heroVideos,
                                                shelves = homeShelves,
                                                continueWatching = continueWatching,
                                                isLoading = homeLoading,
                                                onRefresh = { syncNonce++ },
                                                onPlayVideo = { vid -> watchingVideo = vid },
                                                onOpenChannel = { cid -> activeChannelId = cid }
                                            )

                                            TopTab.SUBSCRIPTIONS -> SubscriptionsScreen(
                                                isTablet = isTablet,
                                                subscriptions = mergedSubscriptions,
                                                subVideos = subFeedVideos,
                                                onOpenChannel = { cid -> activeChannelId = cid },
                                                onPlayVideo = { vid -> watchingVideo = vid }
                                            )

                                            TopTab.PLAYLISTS -> PlaylistsScreen(
                                                isTablet = isTablet,
                                                playlists = mergedPlaylists,
                                                remotePlaylistVideos = remotePlaylistVideos,
                                                loadingRemotePlaylistId = loadingRemotePlaylistId,
                                                onLoadRemotePlaylist = { plId ->
                                                    scope.launch {
                                                        loadingRemotePlaylistId = plId
                                                        val vids = InnerTubeClient.fetchRemotePlaylistVideos(
                                                            plId, googleSession, appPrefs.regionCode, appPrefs.languageCode
                                                        )
                                                        remotePlaylistVideos = remotePlaylistVideos + (plId to vids)
                                                        loadingRemotePlaylistId = null
                                                    }
                                                },
                                                onCreatePlaylist = { name -> localPlaylists = store.createPlaylist(name) },
                                                onDeletePlaylist = { id -> localPlaylists = store.deletePlaylist(id) },
                                                onPlayVideo = { vid -> watchingVideo = vid }
                                            )

                                            TopTab.HISTORY -> HistoryScreen(
                                                isTablet = isTablet,
                                                history = mergedHistory,
                                                onPlayVideo = { vid -> watchingVideo = vid },
                                                onClearHistory = {
                                                    store.clearHistory()
                                                    localHistory = emptyList()
                                                }
                                            )
                                        }
                                    }

                                    // Floating Glass Top Pill Nav on Tablet/Wide Screens ONLY
                                    if (isTablet) {
                                        TabletFloatingTopNav(
                                            session = googleSession,
                                            activeTab = activeTab,
                                            isSearching = isSearching,
                                            searchText = searchText,
                                            recentSearches = recentSearches,
                                            hl = appPrefs.languageCode,
                                            onTabSelected = { tab ->
                                                activeSearchQuery = null
                                                activeTab = tab
                                            },
                                            onSearchModeChange = { isSearching = it },
                                            onSearchTextChange = { searchText = it },
                                            onSubmitSearch = { submitSearch(it) },
                                            onClearRecentSearches = {
                                                store.clearRecentSearches()
                                                recentSearches = emptyList()
                                            },
                                            onOpenAccount = { showAccountDialog = true }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (showAccountDialog) {
                        AccountSheetDialog(
                            session = googleSession,
                            prefs = appPrefs,
                            onStartGoogleSignIn = {
                                showAccountDialog = false
                                showGoogleSignInScreen = true
                            },
                            onSignOut = {
                                runCatching {
                                    CookieManager.getInstance().removeAllCookies(null)
                                    CookieManager.getInstance().flush()
                                }
                                store.saveGoogleSession(null)
                                googleSession = null
                                remoteSubscriptions = emptyList()
                                remotePlaylists = emptyList()
                                remotePlaylistVideos = emptyMap()
                                remoteHistory = emptyList()
                                syncNonce++
                            },
                            onSyncNow = { syncNonce++ },
                            onUpdatePrefs = { updated ->
                                appPrefs = updated
                                store.saveAppPrefs(updated)
                            },
                            onDismiss = { showAccountDialog = false }
                        )
                    }
                }
            }
        }
    }
}
