package com.cinema.youtube.data

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlockEngine {

    private val BLOCKED_HOSTS = setOf(
        "googleads.g.doubleclick.net",
        "doubleclick.net",
        "ad.doubleclick.net",
        "static.doubleclick.net",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "www.googleadservices.com",
        "googleadservices.com",
        "www.google-analytics.com",
        "adservice.google.com",
        "ads.youtube.com"
    )

    private val BLOCKED_PATH_MARKERS = listOf(
        "/pagead/",
        "/api/stats/ads",
        "/ptracking",
        "/get_midroll_info",
        "/pcs/activeview",
        "/youtubei/v1/log_event",
        "doubleclick.net",
        "googlesyndication.com"
    )

    fun isAdRequest(uri: Uri?): Boolean {
        if (uri == null) return false
        val host = uri.host?.lowercase() ?: return false
        // NEVER block video/image/player CDN endpoints
        if (host.endsWith("googlevideo.com") || host.endsWith("ytimg.com") || host.endsWith("ggpht.com")) {
            return false
        }
        if (BLOCKED_HOSTS.any { host == it || host.endsWith(".$it") }) {
            return true
        }
        val full = uri.toString().lowercase()
        return BLOCKED_PATH_MARKERS.any { full.contains(it) }
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /**
     * Injected into m.youtube.com/watch?v=... to:
     * 1. Strip adPlacements / playerAds / adSlots from ytInitialPlayerResponse & fetch/XHR
     * 2. Isolate ONLY #movie_player edge-to-edge inside our native 16:9 / Fullscreen viewport
     * 3. Auto-skip/mute failsafe if an inline ad ever appears
     * 4. Report playback progress + video end back to CinemaBridge (Kotlin)
     */
    const val PLAYER_ISOLATION_AND_ADBLOCK_JS: String = """
(function() {
  if (window.__cinemaPlayerHooked) return;
  window.__cinemaPlayerHooked = true;

  // 1. Surgical JSON Ad Stripper
  function stripAds(obj) {
    if (!obj || typeof obj !== 'object') return obj;
    try {
      delete obj.adPlacements;
      delete obj.playerAds;
      delete obj.adSlots;
      delete obj.adBreakHeartbeatParams;
      if (obj.auxiliaryUi && obj.auxiliaryUi.messageRenderers) {
        delete obj.auxiliaryUi.messageRenderers.bkaEnforcementMessageViewModel;
      }
    } catch (e) {}
    return obj;
  }

  // Clean existing ytInitialPlayerResponse
  try {
    if (window.ytInitialPlayerResponse) {
      stripAds(window.ytInitialPlayerResponse);
    }
  } catch (e) {}

  // Hook fetch() to strip ads from /youtubei/v1/player responses
  try {
    const origFetch = window.fetch;
    window.fetch = async function(...args) {
      const resp = await origFetch.apply(this, args);
      try {
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
        if (url.includes('/youtubei/v1/player')) {
          const clone = resp.clone();
          const data = await clone.json();
          stripAds(data);
          return new Response(JSON.stringify(data), {
            status: resp.status,
            statusText: resp.statusText,
            headers: resp.headers
          });
        }
      } catch (e) {}
      return resp;
    };
  } catch (e) {}

  // Hook JSON.parse for inline player payloads
  try {
    const origParse = JSON.parse;
    JSON.parse = function(text, reviver) {
      const res = origParse.call(this, text, reviver);
      if (res && typeof res === 'object' && (res.adPlacements || res.playerAds || res.adSlots)) {
        stripAds(res);
      }
      return res;
    };
  } catch (e) {}

  // 2. Inject Clean Player-Only Isolation CSS
  function injectPlayerCss() {
    if (document.getElementById('cinema-player-iso-css')) return;
    const style = document.createElement('style');
    style.id = 'cinema-player-iso-css';
    style.textContent = `
      html, body {
        background: #000000 !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: hidden !important;
        width: 100vw !important;
        height: 100vh !important;
      }
      ytm-mobile-topbar-renderer,
      .mobile-topbar-header,
      #header-bar,
      ytm-watch-metadata,
      ytm-single-column-watch-next-results-renderer,
      ytm-item-section-renderer,
      ytm-pivot-bar-renderer,
      ytm-mealbar-promo-renderer,
      ytm-upsell-dialog-renderer,
      tp-yt-paper-dialog,
      ytm-companion-slot,
      ytm-promoted-sparkles-web-renderer,
      .ytm-autonav-bar,
      .open-app-button,
      .ytp-ad-overlay-container,
      .ytp-ad-text-overlay,
      .ytp-pause-overlay,
      .ytp-watermark,
      a.ytp-title-link,
      .ytp-chrome-top .ytp-watch-later-button,
      .ytp-chrome-top .ytp-share-button {
        display: none !important;
        visibility: hidden !important;
        pointer-events: none !important;
      }
      #player-container-id,
      .player-container,
      #player,
      #movie_player {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        max-height: 100vh !important;
        margin: 0 !important;
        padding: 0 !important;
        z-index: 2147483640 !important;
        background: #000000 !important;
      }
      .player-size,
      .html5-video-container,
      video.html5-main-video {
        width: 100vw !important;
        height: 100vh !important;
        top: 0 !important;
        left: 0 !important;
        object-fit: contain !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }
  injectPlayerCss();

  // 3. Ad-skip failsafe + autoplay ensure + progress bridge
  let lastReportedSec = -1;
  let wasMutedByAd = false;
  let endedReported = false;

  setInterval(function() {
    injectPlayerCss();

    // Dismiss any YouTube consent / open-app popups silently
    try {
      const dismissBtns = document.querySelectorAll(
        'ytm-mealbar-promo-renderer button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button[aria-label*="Skip"]'
      );
      dismissBtns.forEach(b => { try { b.click(); } catch(e) {} });
    } catch (e) {}

    const player = document.querySelector('#movie_player');
    const video = document.querySelector('video.html5-main-video') || document.querySelector('video');
    if (!video) return;

    const isAd = player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'));
    if (isAd) {
      if (!video.muted) {
        video.muted = true;
        wasMutedByAd = true;
      }
      if (isFinite(video.duration) && video.duration > 0) {
        video.currentTime = video.duration;
      }
      return;
    } else if (wasMutedByAd) {
      video.muted = false;
      wasMutedByAd = false;
    }

    // Report progress every ~3 seconds to native Kotlin
    if (window.CinemaBridge && isFinite(video.duration) && video.duration > 1) {
      const cur = Math.floor(video.currentTime || 0);
      const dur = Math.floor(video.duration || 0);
      if (Math.abs(cur - lastReportedSec) >= 3) {
        lastReportedSec = cur;
        try { window.CinemaBridge.onProgress(cur * 1000, dur * 1000); } catch (e) {}
      }
      if (video.ended && !endedReported) {
        endedReported = true;
        try { window.CinemaBridge.onVideoEnded(); } catch (e) {}
      } else if (!video.ended) {
        endedReported = false;
      }
    }
  }, 400);
})();
"""
}
