package com.cinema.youtube.data

import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.GoogleSession
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object InnerTubeClient {

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private val DUR_REGEX = Regex("^\\d{1,2}(:\\d{2}){1,2}$")

    private const val WEB_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36"
    private const val WEB_VERSION = "2.20250923.01.00"
    private const val YT_ORIGIN = "https://www.youtube.com"

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // ---------- SAPISIDHASH Auth Helper ----------

    fun extractSapisidFromCookies(cookieStr: String): String {
        if (cookieStr.isBlank()) return ""
        val parts = cookieStr.split(";")
        var fallback = ""
        for (raw in parts) {
            val kv = raw.trim().split("=", limit = 2)
            if (kv.size == 2) {
                val k = kv[0].trim()
                val v = kv[1].trim()
                if (k == "__Secure-3PAPISID" && v.isNotBlank()) return v
                if (k == "SAPISID" && v.isNotBlank()) fallback = v
            }
        }
        return fallback
    }

    private fun buildSapisidHash(sapisid: String): String {
        val ts = System.currentTimeMillis() / 1000L
        val raw = "$ts $sapisid $YT_ORIGIN"
        val digest = MessageDigest.getInstance("SHA-1").digest(raw.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "SAPISIDHASH ${ts}_$hex"
    }

    // ---------- Account Profile ----------

    suspend fun fetchAccountProfile(session: GoogleSession): Triple<String, String, String> =
        withContext(Dispatchers.IO) {
            val json = postInnerTube("account/account_menu", webContextBody("US", "en"), session)
                ?: return@withContext Triple("Google Account", "Signed in to YouTube", "")

            val header = deepFindObject(json, "activeAccountHeaderRenderer")
            if (header != null) {
                val name = extractText(header.opt("accountName")).ifBlank { "Google Account" }
                val handle = extractText(header.opt("channelHandle"))
                    .ifBlank { extractText(header.opt("email")) }
                    .ifBlank { "YouTube Account" }
                val avatar = absUrl(
                    header.optJSONObject("accountPhoto")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
                )
                return@withContext Triple(name, handle, avatar)
            }
            Triple("Google Account", "YouTube Account", "")
        }

    // ---------- Home Feed (Authenticated Personalized Feed OR Guest Feed) ----------

    suspend fun fetchHomeShelves(
        gl: String,
        hl: String,
        subscriptions: List<SubscribedChannel>,
        session: GoogleSession? = null
    ): Pair<List<VideoItem>, List<HomeShelf>> = withContext(Dispatchers.IO) {
        coroutineScope {
            val isAuth = session != null && session.isValid

            val subsDeferred = async {
                if (isAuth) fetchAuthSubscriptions(session!!, gl, hl).second
                else fetchSubscriptionFeed(subscriptions)
            }
            val homeDeferred = async { browseVideos("FEwhat_to_watch", gl, hl, session) }
            val trendingDeferred = async { browseVideos("FEtrending", gl, hl, null) }
            val musicDeferred = async { browseVideos("UC-9-kyTW8ZkZNDHQJ6FgpwQ", gl, hl, null) }
            val gamingDeferred = async { browseVideos("UCOpNcN46UbXVtpKMrmU4Abg", gl, hl, null) }

            val subVideos = subsDeferred.await()
            val homeVideos = homeDeferred.await()
            val trendingVideos = trendingDeferred.await()
            val musicVideos = musicDeferred.await()
            val gamingVideos = gamingDeferred.await()

            var forYou = if (homeVideos.size >= 6) homeVideos else trendingVideos
            if (forYou.size < 6) {
                val q = if (gl == "EG" || hl == "ar") "بودكاست مصر" else "trending podcasts documentary"
                forYou = searchVideos(q, gl, hl, session)
            }

            val shelves = mutableListOf<HomeShelf>()
            if (forYou.isNotEmpty()) {
                shelves.add(HomeShelf("For you", forYou.take(24)))
            }
            if (subVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Subscriptions", subVideos.take(20)))
            }
            if (trendingVideos.isNotEmpty() && trendingVideos != forYou) {
                shelves.add(HomeShelf("Trending", trendingVideos.take(18)))
            }
            if (musicVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Music", musicVideos.take(16)))
            }
            if (gamingVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Gaming", gamingVideos.take(16)))
            }

            if (shelves.size < 3) {
                val extraQueries = if (hl == "ar") {
                    listOf("ملخص مباريات" to "Sports", "بودكاست عربي" to "Podcasts")
                } else {
                    listOf("football highlights" to "Sports", "tech reviews" to "Tech")
                }
                val extras = extraQueries.map { (q, title) ->
                    async { title to searchVideos(q, gl, hl, null).take(14) }
                }.awaitAll()
                for ((title, vids) in extras) {
                    if (vids.isNotEmpty()) shelves.add(HomeShelf(title, vids))
                }
            }

            val heroPool = (if (forYou.isNotEmpty()) forYou else subVideos)
                .distinctBy { it.id }
                .take(5)

            Pair(heroPool, shelves)
        }
    }

    // ---------- Authenticated Subscriptions, Playlists, History, Actions ----------

    suspend fun fetchAuthSubscriptions(
        session: GoogleSession,
        gl: String,
        hl: String
    ): Pair<List<SubscribedChannel>, List<VideoItem>> = withContext(Dispatchers.IO) {
        val json = postInnerTube("browse", webContextBody(gl, hl).put("browseId", "FEsubscriptions"), session)
            ?: return@withContext Pair(emptyList(), emptyList())

        val videos = mutableListOf<VideoItem>()
        walkVideos(json, videos)
        val cleanVideos = videos.distinctBy { it.id }

        val channels = linkedMapOf<String, SubscribedChannel>()
        for (v in cleanVideos) {
            if (v.channelId.startsWith("UC") && v.channelName.isNotBlank() && !channels.containsKey(v.channelId)) {
                channels[v.channelId] = SubscribedChannel(v.channelId, v.channelName, v.channelAvatar)
            }
        }
        Pair(channels.values.toList(), cleanVideos)
    }

    suspend fun fetchAuthHistory(
        session: GoogleSession,
        gl: String,
        hl: String
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val json = postInnerTube("browse", webContextBody(gl, hl).put("browseId", "FEhistory"), session)
            ?: return@withContext emptyList()
        val vids = mutableListOf<VideoItem>()
        walkVideos(json, vids)
        vids.distinctBy { it.id }.take(50)
    }

    suspend fun fetchAuthPlaylists(
        session: GoogleSession,
        gl: String,
        hl: String
    ): List<UserPlaylist> = withContext(Dispatchers.IO) {
        val json = postInnerTube("browse", webContextBody(gl, hl).put("browseId", "FEplaylist_aggregation"), session)
            ?: postInnerTube("browse", webContextBody(gl, hl).put("browseId", "FElibrary"), session)

        val result = linkedMapOf<String, UserPlaylist>()
        result["VLWL"] = UserPlaylist(
            id = "VLWL",
            name = "Watch Later (YouTube)",
            videos = emptyList(),
            isRemote = true,
            videoCountText = "YouTube Account"
        )
        result["VLLL"] = UserPlaylist(
            id = "VLLL",
            name = "Liked Videos (YouTube)",
            videos = emptyList(),
            isRemote = true,
            videoCountText = "YouTube Account"
        )

        if (json != null) {
            val renderers = mutableListOf<JSONObject>()
            collectObjectsByKey(json, "gridPlaylistRenderer", renderers)
            collectObjectsByKey(json, "playlistRenderer", renderers)
            collectObjectsByKey(json, "lockupViewModel", renderers)

            for (r in renderers) {
                val plId = r.optString("playlistId").ifBlank {
                    val cid = r.optString("contentId")
                    if (cid.startsWith("PL") || cid.startsWith("VL")) cid else ""
                }
                if (plId.isBlank()) continue
                val normId = if (plId.startsWith("VL")) plId else "VL$plId"
                val title = extractText(r.opt("title")).ifBlank {
                    extractText(r.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")?.opt("title"))
                }
                if (title.isBlank()) continue
                val thumb = absUrl(deepFindThumbUrl(r, "thumbnails"))
                val count = extractText(r.opt("videoCountText")).ifBlank { "YouTube Playlist" }
                result[normId] = UserPlaylist(
                    id = normId,
                    name = title,
                    videos = emptyList(),
                    isRemote = true,
                    thumbnailUrl = thumb,
                    videoCountText = count
                )
            }
        }
        result.values.toList()
    }

    suspend fun fetchRemotePlaylistVideos(
        playlistBrowseId: String,
        session: GoogleSession?,
        gl: String,
        hl: String
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val bid = if (playlistBrowseId.startsWith("VL")) playlistBrowseId else "VL$playlistBrowseId"
        val json = postInnerTube("browse", webContextBody(gl, hl).put("browseId", bid), session)
            ?: return@withContext emptyList()
        val vids = mutableListOf<VideoItem>()
        walkVideos(json, vids)
        vids.distinctBy { it.id }.take(60)
    }

    suspend fun syncLikeVideo(videoId: String, like: Boolean, session: GoogleSession?): Boolean =
        withContext(Dispatchers.IO) {
            if (session == null || !session.isValid) return@withContext false
            val endpoint = if (like) "like/like" else "like/removelike"
            val body = webContextBody("US", "en")
                .put("target", JSONObject().put("videoId", videoId))
            postInnerTube(endpoint, body, session) != null
        }

    suspend fun syncSubscribeChannel(channelId: String, subscribe: Boolean, session: GoogleSession?): Boolean =
        withContext(Dispatchers.IO) {
            if (session == null || !session.isValid || !channelId.startsWith("UC")) return@withContext false
            val endpoint = if (subscribe) "subscription/subscribe" else "subscription/unsubscribe"
            val body = webContextBody("US", "en")
                .put("channelIds", JSONArray().put(channelId))
            postInnerTube(endpoint, body, session) != null
        }

    // ---------- Local Guest Subscriptions RSS ----------

    suspend fun fetchSubscriptionFeed(subscriptions: List<SubscribedChannel>): List<VideoItem> =
        withContext(Dispatchers.IO) {
            if (subscriptions.isEmpty()) return@withContext emptyList()
            coroutineScope {
                subscriptions.take(12).map { ch ->
                    async { fetchChannelRss(ch) }
                }.awaitAll()
                    .flatten()
                    .distinctBy { it.id }
            }
        }

    private fun fetchChannelRss(channel: SubscribedChannel): List<VideoItem> {
        if (!channel.id.startsWith("UC")) return emptyList()
        return try {
            val req = Request.Builder()
                .url("https://www.youtube.com/feeds/videos.xml?channel_id=${channel.id}")
                .header("User-Agent", WEB_UA)
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val xml = resp.body?.string() ?: return emptyList()
                val out = mutableListOf<VideoItem>()
                val entryRegex = Regex("<entry>([\\s\\S]*?)</entry>")
                val vidRegex = Regex("<yt:videoId>([^<]+)</yt:videoId>")
                val titleRegex = Regex("<title>([\\s\\S]*?)</title>")
                val pubRegex = Regex("<published>([^<]+)</published>")
                for (m in entryRegex.findAll(xml)) {
                    val block = m.groupValues[1]
                    val id = vidRegex.find(block)?.groupValues?.get(1)?.trim() ?: continue
                    val rawTitle = titleRegex.find(block)?.groupValues?.get(1)?.trim() ?: continue
                    val pub = pubRegex.find(block)?.groupValues?.get(1)?.take(10) ?: ""
                    out.add(
                        VideoItem(
                            id = id,
                            title = decodeXml(rawTitle),
                            channelName = channel.name,
                            channelId = channel.id,
                            channelAvatar = channel.avatarUrl,
                            meta = pub
                        )
                    )
                }
                out.take(8)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // ---------- Search, Suggestions, Channel, Watch Details & Comments ----------

    suspend fun searchVideos(
        query: String,
        gl: String,
        hl: String,
        session: GoogleSession? = null
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext emptyList()
        val body = webContextBody(gl, hl).put("query", q)
        val json = postInnerTube("search", body, session) ?: return@withContext emptyList()
        val out = mutableListOf<VideoItem>()
        walkVideos(json, out)
        out.distinctBy { it.id }
    }

    suspend fun fetchSuggestions(query: String, hl: String): List<String> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isEmpty()) return@withContext emptyList()
            try {
                val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&oe=utf-8" +
                    "&hl=${URLEncoder.encode(hl, "UTF-8")}&q=${URLEncoder.encode(q, "UTF-8")}"
                val req = Request.Builder().url(url).header("User-Agent", WEB_UA).build()
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    val text = resp.body?.string() ?: return@withContext emptyList()
                    val arr = JSONArray(text)
                    if (arr.length() < 2) return@withContext emptyList()
                    val items = arr.getJSONArray(1)
                    (0 until items.length()).mapNotNull { items.optString(it).takeIf { s -> s.isNotBlank() } }.take(8)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    suspend fun fetchChannel(channelId: String, gl: String, hl: String, session: GoogleSession? = null): ChannelInfo? =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl)
                .put("browseId", channelId)
                .put("params", "EgZ2aWRlb3PyBgQKAjoA")
            val json = postInnerTube("browse", body, session) ?: return@withContext null

            val videos = mutableListOf<VideoItem>()
            walkVideos(json, videos)

            val meta = json.optJSONObject("metadata")?.optJSONObject("channelMetadataRenderer")
            val header = json.optJSONObject("header")

            val name = meta?.optString("title")?.takeIf { it.isNotBlank() }
                ?: extractText(deepFindObject(header, "title"))
                    .ifBlank { videos.firstOrNull()?.channelName ?: "Channel" }

            val avatarUrl = absUrl(
                meta?.optJSONObject("avatar")?.optJSONArray("thumbnails")?.lastThumbUrl()
                    ?: deepFindThumbUrl(header, "avatar")
            )
            val bannerUrl = absUrl(
                deepFindThumbUrl(header, "banner")
                    .ifBlank { deepFindThumbUrl(header, "imageBannerViewModel") }
            )
            val subCount = extractText(deepFindObject(header, "subscriberCountText"))
                .ifBlank { extractSubscriberFromPageHeader(header) }
            val desc = meta?.optString("description") ?: ""

            val normalizedVideos = videos.distinctBy { it.id }.map {
                it.copy(
                    channelName = it.channelName.ifBlank { name },
                    channelId = it.channelId.ifBlank { channelId },
                    channelAvatar = it.channelAvatar.ifBlank { avatarUrl }
                )
            }

            ChannelInfo(
                id = channelId,
                name = name,
                avatarUrl = avatarUrl,
                bannerUrl = bannerUrl,
                subscriberCount = subCount,
                description = desc,
                videos = normalizedVideos
            )
        }

    suspend fun fetchWatchDetails(
        videoId: String,
        gl: String,
        hl: String,
        session: GoogleSession? = null
    ): VideoDetails? = withContext(Dispatchers.IO) {
        val body = webContextBody(gl, hl).put("videoId", videoId)
        val json = postInnerTube("next", body, session) ?: return@withContext null

        val primary = deepFindObject(json, "videoPrimaryInfoRenderer")
        val secondary = deepFindObject(json, "videoSecondaryInfoRenderer")
        val owner = secondary?.optJSONObject("owner")?.optJSONObject("videoOwnerRenderer")

        val title = extractText(primary?.opt("title"))
        val viewCount = extractText(
            primary?.optJSONObject("viewCount")?.optJSONObject("videoViewCountRenderer")?.opt("viewCount")
        ).ifBlank {
            extractText(primary?.optJSONObject("viewCount")?.optJSONObject("videoViewCountRenderer")?.opt("shortViewCount"))
        }
        val publishDate = extractText(primary?.opt("dateText"))
            .ifBlank { extractText(primary?.opt("relativeDateText")) }

        val channelName = extractText(owner?.opt("title"))
        val channelId = owner?.optJSONObject("navigationEndpoint")
            ?.optJSONObject("browseEndpoint")
            ?.optString("browseId") ?: ""
        val channelAvatar = absUrl(
            owner?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
        )
        val subCount = extractText(owner?.opt("subscriberCountText"))

        val description = extractText(secondary?.opt("attributedDescription"))
            .ifBlank { extractText(secondary?.opt("description")) }

        val likeText = findLikeCount(primary)

        val secondaryResults = deepFindObject(json, "secondaryResults")
        val related = mutableListOf<VideoItem>()
        if (secondaryResults != null) {
            walkVideos(secondaryResults, related)
        }

        val commentsToken = findCommentsContinuation(json)

        VideoDetails(
            videoId = videoId,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = channelAvatar,
            viewCount = viewCount,
            publishDate = publishDate,
            description = description,
            likeCount = likeText,
            subscriberCount = subCount,
            relatedVideos = related.distinctBy { it.id }.filterNot { it.id == videoId }.take(25),
            commentsContinuation = commentsToken
        )
    }

    suspend fun fetchComments(continuation: String, gl: String, hl: String): List<CommentItem> =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl).put("continuation", continuation)
            val json = postInnerTube("next", body, null) ?: return@withContext emptyList()
            val out = mutableListOf<CommentItem>()

            val payloads = mutableListOf<JSONObject>()
            collectObjectsByKey(json, "commentEntityPayload", payloads)
            for (p in payloads) {
                val props = p.optJSONObject("properties") ?: continue
                val authorObj = p.optJSONObject("author")
                val toolbar = p.optJSONObject("toolbar")
                val text = props.optJSONObject("content")?.optString("content") ?: continue
                if (text.isBlank()) continue
                out.add(
                    CommentItem(
                        author = authorObj?.optString("displayName")?.ifBlank { "User" } ?: "User",
                        avatarUrl = absUrl(authorObj?.optString("avatarThumbnailUrl") ?: ""),
                        text = text,
                        publishedTime = props.optString("publishedTime"),
                        likeCount = toolbar?.optString("likeCountNotliked") ?: ""
                    )
                )
            }

            if (out.isEmpty()) {
                val renderers = mutableListOf<JSONObject>()
                collectObjectsByKey(json, "commentRenderer", renderers)
                for (r in renderers) {
                    val text = extractText(r.opt("contentText"))
                    if (text.isBlank()) continue
                    out.add(
                        CommentItem(
                            author = extractText(r.opt("authorText")).ifBlank { "User" },
                            avatarUrl = absUrl(
                                r.optJSONObject("authorThumbnail")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
                            ),
                            text = text,
                            publishedTime = extractText(r.opt("publishedTimeText")),
                            likeCount = extractText(r.opt("voteCount"))
                        )
                    )
                }
            }
            out.take(40)
        }

    // ---------- Internal InnerTube Request Builder ----------

    private fun browseVideos(browseId: String, gl: String, hl: String, session: GoogleSession?): List<VideoItem> {
        val body = webContextBody(gl, hl).put("browseId", browseId)
        val json = postInnerTube("browse", body, session) ?: return emptyList()
        val out = mutableListOf<VideoItem>()
        walkVideos(json, out)
        return out.distinctBy { it.id }
    }

    private fun webContextBody(gl: String, hl: String): JSONObject {
        return JSONObject().put(
            "context",
            JSONObject().put(
                "client",
                JSONObject()
                    .put("clientName", "WEB")
                    .put("clientVersion", WEB_VERSION)
                    .put("hl", hl)
                    .put("gl", gl)
                    .put("utcOffsetMinutes", 120)
            )
        )
    }

    private fun postInnerTube(endpoint: String, body: JSONObject, session: GoogleSession?): JSONObject? {
        return try {
            val reqBuilder = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/$endpoint?prettyPrint=false")
                .header("User-Agent", WEB_UA)
                .header("Origin", YT_ORIGIN)
                .header("Referer", "$YT_ORIGIN/")
                .header("X-YouTube-Client-Name", "1")
                .header("X-YouTube-Client-Version", WEB_VERSION)
                .post(body.toString().toRequestBody(JSON_MEDIA))

            if (session != null && session.isValid) {
                reqBuilder
                    .header("Cookie", session.cookieHeader)
                    .header("Authorization", buildSapisidHash(session.sapisid))
                    .header("X-Origin", YT_ORIGIN)
                    .header("X-Goog-AuthUser", "0")
            }

            http.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val str = resp.body?.string() ?: return null
                JSONObject(str)
            }
        } catch (_: Exception) {
            null
        }
    }

    // ---------- Fast Recursive JSON Video Parser ----------

    private fun walkVideos(node: Any?, out: MutableList<VideoItem>, depth: Int = 0) {
        if (node == null || depth > 35 || out.size >= 45) return
        when (node) {
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    walkVideos(node.opt(i), out, depth + 1)
                }
            }
            is JSONObject -> {
                val vr = node.optJSONObject("videoRenderer")
                    ?: node.optJSONObject("gridVideoRenderer")
                    ?: node.optJSONObject("compactVideoRenderer")
                    ?: node.optJSONObject("playlistVideoRenderer")
                if (vr != null) {
                    parseVideoRenderer(vr)?.let { out.add(it) }
                    return
                }
                val lvm = node.optJSONObject("lockupViewModel")
                if (lvm != null) {
                    parseLockupViewModel(lvm)?.let { out.add(it) }
                    return
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    walkVideos(node.opt(keys.next()), out, depth + 1)
                }
            }
        }
    }

    private fun parseVideoRenderer(v: JSONObject): VideoItem? {
        val id = v.optString("videoId")
        if (id.length != 11) return null
        if (v.has("upcomingEventData")) return null
        val nav = v.optJSONObject("navigationEndpoint")
        if (nav != null && nav.has("reelWatchEndpoint")) return null

        val title = extractText(v.opt("title")).trim()
        if (title.isEmpty()) return null

        val owner = v.optJSONObject("ownerText")
            ?: v.optJSONObject("shortBylineText")
            ?: v.optJSONObject("longBylineText")
        val channelName = extractText(owner).trim()
        val channelId = owner?.optJSONArray("runs")?.optJSONObject(0)
            ?.optJSONObject("navigationEndpoint")
            ?.optJSONObject("browseEndpoint")
            ?.optString("browseId") ?: ""

        val avatar = absUrl(
            deepFindThumbUrl(v.optJSONObject("channelThumbnailSupportedRenderers"), "thumbnails")
                .ifBlank { deepFindThumbUrl(v.optJSONObject("channelThumbnail"), "thumbnails") }
        )

        val views = extractText(v.opt("shortViewCountText")).ifBlank { extractText(v.opt("viewCountText")) }
        val pub = extractText(v.opt("publishedTimeText"))
        val meta = listOf(views, pub).filter { it.isNotBlank() }.joinToString(" · ")
        val dur = extractText(v.opt("lengthText"))

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = avatar,
            duration = dur,
            meta = meta
        )
    }

    private fun parseLockupViewModel(l: JSONObject): VideoItem? {
        val id = l.optString("contentId")
        if (id.length != 11) return null
        val ctype = l.optString("contentType")
        if (ctype.isNotBlank() && !ctype.contains("VIDEO", ignoreCase = true)) return null

        val md = l.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel") ?: return null
        val title = extractText(md.opt("title")).trim()
        if (title.isEmpty()) return null

        val rows = deepFindArray(md, "metadataRows")
        val parts = mutableListOf<List<String>>()
        if (rows != null) {
            for (i in 0 until rows.length()) {
                val r = rows.optJSONObject(i) ?: continue
                val mp = r.optJSONArray("metadataParts") ?: continue
                val rowTexts = mutableListOf<String>()
                for (j in 0 until mp.length()) {
                    val t = mp.optJSONObject(j)?.optJSONObject("text")?.optString("content")
                    if (!t.isNullOrBlank()) rowTexts.add(t)
                }
                if (rowTexts.isNotEmpty()) parts.add(rowTexts)
            }
        }

        val channelName = parts.getOrNull(0)?.firstOrNull() ?: ""
        val meta = parts.getOrNull(1)?.joinToString(" · ") ?: ""
        val channelId = deepFindObject(md.opt("image"), "browseEndpoint")?.optString("browseId") ?: ""
        val avatar = absUrl(deepFindArray(md.opt("image"), "sources")?.optJSONObject(0)?.optString("url") ?: "")

        val badges = mutableListOf<JSONObject>()
        collectObjectsByKey(l.opt("contentImage"), "thumbnailBadgeViewModel", badges)
        val dur = badges.mapNotNull { it.optString("text").takeIf { s -> DUR_REGEX.matches(s) } }.firstOrNull() ?: ""

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = avatar,
            duration = dur,
            meta = meta
        )
    }

    private fun extractText(node: Any?): String {
        if (node == null) return ""
        if (node is String) return node
        if (node !is JSONObject) return ""
        node.optString("simpleText").takeIf { it.isNotBlank() }?.let { return it }
        node.optString("content").takeIf { it.isNotBlank() }?.let { return it }
        val runs = node.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        }
        return sb.toString()
    }

    private fun deepFindObject(node: Any?, key: String, depth: Int = 0): JSONObject? {
        if (node == null || depth > 30) return null
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = deepFindObject(node.opt(keys.next()), key, depth + 1)
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = deepFindObject(node.opt(i), key, depth + 1)
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun deepFindArray(node: Any?, key: String, depth: Int = 0): JSONArray? {
        if (node == null || depth > 30) return null
        when (node) {
            is JSONObject -> {
                node.optJSONArray(key)?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = deepFindArray(node.opt(keys.next()), key, depth + 1)
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = deepFindArray(node.opt(i), key, depth + 1)
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun collectObjectsByKey(node: Any?, key: String, out: MutableList<JSONObject>, depth: Int = 0) {
        if (node == null || depth > 35) return
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { out.add(it) }
                val keys = node.keys()
                while (keys.hasNext()) {
                    collectObjectsByKey(node.opt(keys.next()), key, out, depth + 1)
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    collectObjectsByKey(node.opt(i), key, out, depth + 1)
                }
            }
        }
    }

    private fun deepFindThumbUrl(node: Any?, key: String): String {
        val target = if (key == "thumbnails") node else deepFindObject(node, key) ?: return ""
        val thumbs = deepFindArray(target, "thumbnails")
            ?: deepFindArray(target, "sources")
            ?: return ""
        return thumbs.lastThumbUrl()
    }

    private fun JSONArray.lastThumbUrl(): String {
        if (length() == 0) return ""
        return optJSONObject(length() - 1)?.optString("url") ?: ""
    }

    private fun extractSubscriberFromPageHeader(header: JSONObject?): String {
        val rows = deepFindArray(header, "metadataRows") ?: return ""
        for (i in 0 until rows.length()) {
            val mp = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
            for (j in 0 until mp.length()) {
                val txt = mp.optJSONObject(j)?.optJSONObject("text")?.optString("content") ?: ""
                if (txt.contains("sub", ignoreCase = true) || txt.contains("مشترك")) return txt
            }
        }
        return ""
    }

    private fun findLikeCount(primary: JSONObject?): String {
        if (primary == null) return ""
        val likeBtn = deepFindObject(primary, "likeButtonViewModel")
            ?: deepFindObject(primary, "segmentedLikeDislikeButtonViewModel")
        val title = deepFindObject(likeBtn, "buttonViewModel")?.optString("title") ?: ""
        return if (title.isNotBlank() && title != "Like") title else ""
    }

    private fun findCommentsContinuation(json: JSONObject): String? {
        val sections = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "itemSectionRenderer", sections)
        for (s in sections) {
            val id = s.optString("sectionIdentifier")
            val targetId = s.optString("targetId")
            if (id.contains("comment", ignoreCase = true) || targetId.contains("comment", ignoreCase = true)) {
                val token = deepFindObject(s, "continuationCommand")?.optString("token")
                if (!token.isNullOrBlank()) return token
            }
        }
        val ep = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "engagementPanelSectionListRenderer", ep)
        for (panel in ep) {
            if (panel.optString("panelIdentifier").contains("comment", ignoreCase = true)) {
                val token = deepFindObject(panel, "continuationCommand")?.optString("token")
                if (!token.isNullOrBlank()) return token
            }
        }
        return null
    }

    private fun absUrl(u: String): String {
        return when {
            u.isBlank() -> ""
            u.startsWith("//") -> "https:$u"
            else -> u
        }
    }

    private fun decodeXml(s: String): String = s
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
}
