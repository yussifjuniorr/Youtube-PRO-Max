# Cinema YouTube Native (v3.0 Final)

Fast, stable, native Jetpack Compose YouTube experience with:
- **Ad-Free Real YouTube Player Engine**: Isolated hardware-accelerated YouTube HTML5 player with network + JSON response ad stripping (plays 100% of videos including music & sports highlights in full HD with captions, speed, double-tap seek, PiP, and instant rotation without reloading).
- **Direct Google Account Sign-In + SAPISIDHASH Sync**: Captures your YouTube session directly and syncs your real Home feed, Subscriptions, Playlists, and History natively.
- **Redesigned Adaptive Mobile & Tablet UI**:
  - **Mobile (`< 600dp`)**: Clean docked top header & bottom navigation bar (zero overlapping), rounded Apple TV+ Spotlight card with clean footer text, category chips, and crisp full-width video feed.
  - **Tablet (`>= 600dp`)**: Floating Glass Cinema top pill bar, widescreen edge-to-edge Hero Carousel, horizontal Cinema shelves, multi-column grids, and split-screen Watch layout.
