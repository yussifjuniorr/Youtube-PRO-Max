package com.cinema.youtube

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var rootContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private lateinit var combinedBootstrapJs: String

    companion object {
        private const val HOME_URL = "https://www.youtube.com/?app=desktop"
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        // Firefox Mobile UA + stripped X-Requested-With bypasses Google's Android WebView sign-in block
        private const val LOGIN_UA =
            "Mozilla/5.0 (Android 14; Mobile; rv:132.0) Gecko/132.0 Firefox/132.0"

        private val BLOCKED_AD_HOSTS = setOf(
            "doubleclick.net",
            "googleadservices.com",
            "googlesyndication.com",
            "adservice.google.com",
            "adservice.google.com.eg"
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#050505")
        window.navigationBarColor = Color.parseColor("#050505")

        loadCinemaAssets()

        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#050505"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#050505"))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                (3 * resources.displayMetrics.density).toInt(),
                Gravity.TOP
            )
        }

        setupWebView(webView)
        rootContainer.addView(webView)
        rootContainer.addView(progressBar)
        setContentView(rootContainer)

        setupBackHandler()

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(HOME_URL)
        }
    }

    private fun loadCinemaAssets() {
        val styleCss = readAsset("cinema/style.css")
        val mobileCss = readAsset("cinema/mobile_overrides.css")
        val cssBundle = styleCss + "\n\n" + mobileCss
        val quotedCss = JSONObject.quote(cssBundle)

        val shimJs = readAsset("cinema/shim.js")
        val mainJs = readAsset("cinema/main.js")
        val contentJs = readAsset("cinema/content.js")
        val mobileAddonJs = readAsset("cinema/mobile_addon.js")

        combinedBootstrapJs = """
            (() => {
              if (!document.getElementById('cinema-style-css')) {
                const st = document.createElement('style');
                st.id = 'cinema-style-css';
                st.textContent = $quotedCss;
                (document.head || document.documentElement).appendChild(st);
              }
              if (window.__cinemaBootstrapped) return;
              window.__cinemaBootstrapped = true;
              $shimJs
              $mainJs
              $contentJs
              $mobileAddonJs
            })();
        """.trimIndent()
    }

    private fun readAsset(path: String): String {
        return assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(wv: WebView) {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(wv, true)

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            userAgentString = DESKTOP_UA
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        // Critical for Google Sign-In: stop Android WebView from sending X-Requested-With: com.cinema.youtube
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(wv.settings, emptySet())
        }

        wv.addJavascriptInterface(CinemaBridge(), "CinemaAndroid")

        wv.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val uri = request.url ?: return null
                val host = uri.host?.lowercase() ?: return null
                val path = uri.path ?: ""

                // Block ad/telemetry requests for faster page loads (never touch Google Auth)
                if (isBlockedAdRequest(host, path)) {
                    return WebResourceResponse(
                        "text/plain",
                        "utf-8",
                        204,
                        "No Content",
                        emptyMap(),
                        ByteArrayInputStream(ByteArray(0))
                    )
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false
                val host = uri.host?.lowercase() ?: ""
                val path = uri.path ?: ""

                if (scheme == "vnd.youtube" || scheme == "intent") {
                    val fallback = uri.getQueryParameter("browser_fallback_url")
                    if (!fallback.isNullOrBlank()) {
                        view.loadUrl(fallback)
                    }
                    return true
                }

                if (scheme != "http" && scheme != "https") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {}
                    return true
                }

                // Switch User-Agent cleanly between Google Login (Firefox Mobile) and YouTube Desktop
                val isAuthFlow = isGoogleAuthRequest(host, path)
                val targetUa = if (isAuthFlow) LOGIN_UA else DESKTOP_UA

                // Force desktop YouTube if redirected to mobile subdomain (outside auth)
                if (host == "m.youtube.com" && !isAuthFlow) {
                    val desktopUri = uri.buildUpon()
                        .authority("www.youtube.com")
                        .appendQueryParameter("app", "desktop")
                        .build()
                    view.settings.userAgentString = DESKTOP_UA
                    view.loadUrl(desktopUri.toString())
                    return true
                }

                if (isInAppHost(host)) {
                    if (view.settings.userAgentString != targetUa) {
                        view.settings.userAgentString = targetUa
                        view.loadUrl(uri.toString())
                        return true
                    }
                    return false
                }

                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {}
                return true
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                super.onPageCommitVisible(view, url)
                if (shouldInjectCinema(url)) {
                    view.evaluateJavascript(combinedBootstrapJs, null)
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()
                if (shouldInjectCinema(url)) {
                    view.evaluateJavascript(combinedBootstrapJs, null)
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress in 1..99) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                webView.visibility = View.GONE
                progressBar.visibility = View.GONE
                rootContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                )
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                setFullscreen(true)
            }

            override fun onHideCustomView() {
                exitCustomFullscreen()
            }
        }
    }

    private fun isBlockedAdRequest(host: String, path: String): Boolean {
        for (blocked in BLOCKED_AD_HOSTS) {
            if (host == blocked || host.endsWith(".$blocked")) return true
        }
        if ((host == "www.youtube.com" || host == "youtube.com") &&
            (path == "/youtubei/v1/log_event" || path.startsWith("/pagead/") || path.startsWith("/ptracking"))
        ) {
            return true
        }
        return false
    }

    private fun isGoogleAuthRequest(host: String, path: String): Boolean {
        if (host == "accounts.google.com" ||
            host.endsWith(".accounts.google.com") ||
            host == "accounts.youtube.com" ||
            host == "gds.google.com" ||
            host == "consent.google.com" ||
            host == "consent.youtube.com" ||
            host == "myaccount.google.com"
        ) {
            return true
        }
        if ((host == "www.youtube.com" || host == "youtube.com" || host == "m.youtube.com") &&
            (path.startsWith("/signin") || path.startsWith("/ServiceLogin"))
        ) {
            return true
        }
        return false
    }

    private fun isInAppHost(host: String): Boolean {
        return host == "youtube.com" ||
            host.endsWith(".youtube.com") ||
            host == "youtu.be" ||
            host == "google.com" ||
            host.endsWith(".google.com") ||
            host.endsWith(".gstatic.com") ||
            host.endsWith(".googleusercontent.com")
    }

    private fun shouldInjectCinema(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase() ?: return false
        val path = uri.path ?: ""
        if (path.startsWith("/signin") || path.startsWith("/ServiceLogin")) return false
        return host == "www.youtube.com" || host == "youtube.com"
    }

    private fun exitCustomFullscreen() {
        val cv = customView ?: return
        rootContainer.removeView(cv)
        customView = null
        webView.visibility = View.VISIBLE
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        setFullscreen(false)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    private fun setFullscreen(enabled: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (enabled) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    exitCustomFullscreen()
                    return
                }
                webView.evaluateJavascript(
                    "(function(){ return window.__cinemaHandleBack ? window.__cinemaHandleBack() : 'back'; })()"
                ) { result ->
                    if (result != "\"handled\"") {
                        if (webView.canGoBack()) {
                            webView.goBack()
                        } else {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                        }
                    }
                }
            }
        })
    }

    inner class CinemaBridge {
        @JavascriptInterface
        fun fetchSuggestions(query: String, hl: String, callbackId: String) {
            ioExecutor.execute {
                val suggestions = JSONArray()
                try {
                    val encodedQ = URLEncoder.encode(query, "UTF-8")
                    val encodedHl = URLEncoder.encode(hl.ifBlank { "en" }, "UTF-8")
                    val apiUrl =
                        "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&oe=utf-8&hl=$encodedHl&q=$encodedQ"
                    val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 5000
                        readTimeout = 5000
                        setRequestProperty("User-Agent", DESKTOP_UA)
                    }
                    if (conn.responseCode == 200) {
                        val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val parsed = JSONArray(text)
                        if (parsed.length() > 1) {
                            val arr = parsed.getJSONArray(1)
                            for (i in 0 until arr.length()) {
                                suggestions.put(arr.getString(i))
                            }
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                }

                val jsId = JSONObject.quote(callbackId)
                val jsList = suggestions.toString()
                webView.post {
                    webView.evaluateJavascript(
                        "if (window.__cinemaResolveSuggest) window.__cinemaResolveSuggest($jsId, $jsList);",
                        null
                    )
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        ioExecutor.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }
}
