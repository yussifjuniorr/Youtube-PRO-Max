# Cinema YouTube v2 (Android APK)

Updated build with:
- Google Sign-In fix (`X-Requested-With` stripped + Firefox Mobile UA on Google Auth pages)
- Faster mobile GPU performance (lighter blur, ad/telemetry request blocking, single-shot JS injection)
- Fixed touch hover bugs and responsive layout on Search, Subscriptions, Playlists, and History pages
