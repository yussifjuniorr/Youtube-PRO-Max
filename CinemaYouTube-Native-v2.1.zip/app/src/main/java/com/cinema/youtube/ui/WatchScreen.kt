package com.cinema.youtube.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.ClosedCaptionOff
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.rounded.ThumbUpOffAlt
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.SingleSampleMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.CaptionTrack
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.StreamChoice
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay

enum class WatchPanel { NONE, DETAILS, COMMENTS, UP_NEXT }

@OptIn(UnstableApi::class)
@Composable
fun WatchScreen(
    video: VideoItem,
    initialPositionMs: Long,
    gl: String,
    hl: String,
    preferredQuality: Int,
    accessToken: String?,
    isTablet: Boolean,
    isLandscape: Boolean,
    isInPipMode: Boolean,
    isLiked: Boolean,
    isSubscribed: (String) -> Boolean,
    playlists: List<UserPlaylist>,
    onToggleLike: (String) -> Unit,
    onToggleLandscape: () -> Unit,
    onEnterPip: () -> Unit,
    onBack: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onToggleVideoInPlaylist: (String, VideoItem) -> Unit,
    onSaveProgress: (VideoItem, Long, Long) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    val isFullCinema = isLandscape || isTablet

    var streams by remember(video.id) { mutableStateOf<List<StreamChoice>>(emptyList()) }
    var captions by remember(video.id) { mutableStateOf<List<CaptionTrack>>(emptyList()) }
    var selectedCaption by remember(video.id) { mutableStateOf<CaptionTrack?>(null) }
    var currentStreamIndex by remember(video.id) { mutableIntStateOf(0) }
    var loadingStreams by remember(video.id) { mutableStateOf(true) }
    var streamError by remember(video.id) { mutableStateOf<String?>(null) }
    var reloadNonce by remember(video.id) { mutableIntStateOf(0) }

    var details by remember(video.id) { mutableStateOf<VideoDetails?>(null) }
    var comments by remember(video.id) { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsLoaded by remember(video.id) { mutableStateOf(false) }

    var activePanel by remember(video.id) { mutableStateOf(WatchPanel.NONE) }
    var showMobileCommentsSheet by remember(video.id) { mutableStateOf(false) }
    var showMobileDescriptionSheet by remember(video.id) { mutableStateOf(false) }
    var showPlayerSettings by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }

    var showControls by remember(video.id) { mutableStateOf(true) }
    var isZoomFill by remember { mutableStateOf(false) }

    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(true) }
    var positionMs by remember(video.id) { mutableLongStateOf(initialPositionMs) }
    var durationMs by remember(video.id) { mutableLongStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var sliderPos by remember { mutableFloatStateOf(0f) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var isBoost2x by remember { mutableStateOf(false) }
    var restoredInitialSeek by remember(video.id) { mutableStateOf(false) }

    var doubleTapSide by remember { mutableIntStateOf(0) }
    var doubleTapSeconds by remember { mutableIntStateOf(0) }
    var doubleTapNonce by remember { mutableIntStateOf(0) }

    var gestureOverlayType by remember { mutableIntStateOf(0) }
    var gestureOverlayPercent by remember { mutableFloatStateOf(0.5f) }
    var gestureNonce by remember { mutableIntStateOf(0) }

    LaunchedEffect(doubleTapNonce) {
        if (doubleTapNonce > 0) {
            delay(800)
            doubleTapSide = 0
            doubleTapSeconds = 0
        }
    }

    LaunchedEffect(gestureNonce) {
        if (gestureNonce > 0) {
            delay(750)
            gestureOverlayType = 0
        }
    }

    val exoPlayer = remember(context) {
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        ExoPlayer.Builder(context)
            .setAudioAttributes(audioAttrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply {
                playWhenReady = true
            }
    }

    fun playChoice(choice: StreamChoice, seekMs: Long, captionTrack: CaptionTrack? = selectedCaption) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(16_000)
            .apply {
                if (choice.userAgent.isNotBlank()) {
                    setUserAgent(choice.userAgent)
                }
            }

        val baseSource = when {
            choice.isHls -> {
                HlsMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
            choice.isDash -> {
                DashMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
            !choice.audioUrl.isNullOrBlank() -> {
                val vidSrc = ProgressiveMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
                val audSrc = ProgressiveMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.audioUrl))
                MergingMediaSource(vidSrc, audSrc)
            }
            else -> {
                ProgressiveMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
        }

        val finalSource = if (captionTrack != null && captionTrack.url.startsWith("http")) {
            val subConfig = MediaItem.SubtitleConfiguration.Builder(Uri.parse(captionTrack.url))
                .setMimeType(MimeTypes.TEXT_VTT)
                .setLanguage(captionTrack.languageCode)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            val subSource = SingleSampleMediaSource.Factory(httpFactory)
                .createMediaSource(subConfig, C.TIME_UNSET)
            MergingMediaSource(baseSource, subSource)
        } else {
            baseSource
        }

        exoPlayer.setMediaSource(finalSource)
        exoPlayer.prepare()
        if (seekMs > 2_000L) {
            exoPlayer.seekTo(seekMs)
        }
        exoPlayer.playbackParameters = PlaybackParameters(if (isBoost2x) 2f else playbackSpeed)
        exoPlayer.playWhenReady = true
    }

    DisposableEffect(exoPlayer, streams, currentStreamIndex, selectedCaption) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_READY && exoPlayer.duration > 0) {
                    durationMs = exoPlayer.duration
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val resumePos = exoPlayer.currentPosition.coerceAtLeast(positionMs)
                if (selectedCaption != null && currentStreamIndex in streams.indices) {
                    selectedCaption = null
                    playChoice(streams[currentStreamIndex], resumePos, null)
                    return
                }
                val nextIdx = currentStreamIndex + 1
                if (nextIdx < streams.size) {
                    currentStreamIndex = nextIdx
                    playChoice(streams[nextIdx], resumePos, null)
                } else {
                    isBuffering = false
                    streamError = "تعذّر تشغيل الفيديو (${error.errorCodeName}). اضغط إعادة المحاولة."
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    DisposableEffect(video.id) {
        onDispose {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (pos > 0L || dur > 0L) {
                onSaveProgress(
                    video.copy(
                        title = details?.title?.ifBlank { video.title } ?: video.title,
                        channelName = details?.channelName?.ifBlank { video.channelName } ?: video.channelName,
                        channelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId,
                        channelAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
                    ),
                    pos,
                    dur
                )
            }
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(video.id, reloadNonce) {
        loadingStreams = true
        streamError = null
        isBuffering = true
        exoPlayer.stop()

        val resolved = InnerTubeClient.resolveStreams(video.id, accessToken)
        loadingStreams = false
        captions = resolved.captions
        if (resolved.choices.isEmpty()) {
            isBuffering = false
            streamError = resolved.errorMessage ?: "لم يتم العثور على رابط تشغيل لهذا الفيديو"
        } else {
            streams = resolved.choices
            val preferredIdx = resolved.choices.indexOfFirst { !it.isHls && it.height == preferredQuality }
                .takeIf { it >= 0 }
                ?: resolved.choices.indexOfFirst { it.isHls || it.height == 720 }
                    .takeIf { it >= 0 }
                ?: 0
            currentStreamIndex = preferredIdx
            val seekTarget = if (!restoredInitialSeek) {
                restoredInitialSeek = true
                initialPositionMs
            } else positionMs
            playChoice(resolved.choices[preferredIdx], seekTarget, null)
        }
    }

    LaunchedEffect(video.id) {
        details = InnerTubeClient.fetchWatchDetails(video.id, gl, hl)
        val token = details?.commentsContinuation
        if (!token.isNullOrBlank()) {
            comments = InnerTubeClient.fetchComments(token, gl, hl)
            commentsLoaded = true
        }
    }

    LaunchedEffect(video.id, exoPlayer) {
        var tick = 0
        while (true) {
            delay(500)
            if (!isSeeking) {
                positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                if (exoPlayer.duration > 0) {
                    durationMs = exoPlayer.duration
                    sliderPos = (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                }
            }
            tick++
            if (tick % 14 == 0 && durationMs > 0L && isPlaying) {
                onSaveProgress(video, positionMs, durationMs)
            }
        }
    }

    LaunchedEffect(showControls, isPlaying, activePanel, isSeeking, showPlayerSettings) {
        if (showControls && isPlaying && activePanel == WatchPanel.NONE && !isSeeking && !showPlayerSettings) {
            delay(3200)
            showControls = false
        }
    }

    val displayTitle = details?.title?.ifBlank { video.title } ?: video.title
    val displayChannel = details?.channelName?.ifBlank { video.channelName } ?: video.channelName
    val displayChannelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId
    val displayAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
    val relatedVideos = details?.relatedVideos ?: emptyList()
    val activeQualityLabel = streams.getOrNull(currentStreamIndex)?.label ?: "HD"

    fun shareCurrentVideo() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, displayTitle)
            putExtra(Intent.EXTRA_TEXT, "$displayTitle\nhttps://youtu.be/${video.id}")
        }
        runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share video")) }
    }

    val playerBoxContent: @Composable (Modifier) -> Unit = { boxModifier ->
        Box(
            modifier = boxModifier
                .background(Color.Black)
                .pointerInput(video.id, isInPipMode) {
                    if (isInPipMode) return@pointerInput
                    detectTapGestures(
                        onPress = {
                            tryAwaitRelease()
                            if (isBoost2x) {
                                isBoost2x = false
                                exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
                            }
                        },
                        onLongPress = {
                            if (isPlaying) {
                                isBoost2x = true
                                exoPlayer.playbackParameters = PlaybackParameters(2f)
                            }
                        },
                        onTap = {
                            if (activePanel != WatchPanel.NONE) {
                                activePanel = WatchPanel.NONE
                            } else {
                                showControls = !showControls
                            }
                        },
                        onDoubleTap = { offset ->
                            val isRight = offset.x >= size.width / 2f
                            val deltaMs = if (isRight) 10_000L else -10_000L
                            val target = (exoPlayer.currentPosition + deltaMs).coerceIn(
                                0L,
                                if (durationMs > 0L) durationMs else Long.MAX_VALUE
                            )
                            exoPlayer.seekTo(target)
                            positionMs = target
                            val side = if (isRight) 1 else -1
                            doubleTapSeconds = if (doubleTapSide == side) doubleTapSeconds + 10 else 10
                            doubleTapSide = side
                            doubleTapNonce++
                        }
                    )
                }
                .pointerInput(video.id, isInPipMode) {
                    if (isInPipMode) return@pointerInput
                    var dragMode = 0
                    var accumDelta = 0f
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            accumDelta = 0f
                            dragMode = when {
                                offset.x < size.width * 0.42f -> 1
                                offset.x > size.width * 0.58f -> 2
                                else -> 0
                            }
                        },
                        onVerticalDrag = { _, dragAmount ->
                            if (dragMode == 1 && activity != null) {
                                val lp = activity.window.attributes
                                val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                val next = (cur - dragAmount / (size.height.coerceAtLeast(300) * 1.1f)).coerceIn(0.05f, 1f)
                                lp.screenBrightness = next
                                activity.window.attributes = lp
                                gestureOverlayType = 1
                                gestureOverlayPercent = next
                                gestureNonce++
                            } else if (dragMode == 2 && audioManager != null) {
                                accumDelta -= dragAmount
                                val stepPx = (size.height.coerceAtLeast(300) / 16f)
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                var curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                if (kotlin.math.abs(accumDelta) >= stepPx) {
                                    val steps = (accumDelta / stepPx).toInt()
                                    accumDelta -= steps * stepPx
                                    curVol = (curVol + steps).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, curVol, 0)
                                }
                                gestureOverlayType = 2
                                gestureOverlayPercent = curVol.toFloat() / maxVol.toFloat()
                                gestureNonce++
                            }
                        }
                    )
                }
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = if (isZoomFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                        keepScreenOn = true
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { pv ->
                    if (pv.player !== exoPlayer) pv.player = exoPlayer
                    val desired = if (isZoomFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                    if (pv.resizeMode != desired) pv.resizeMode = desired
                }
            )

            if (isInPipMode) return@Box

            AnimatedVisibility(
                visible = isBoost2x,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 14.dp)
            ) {
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text("2x", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Rounded.FastForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }

            AnimatedVisibility(
                visible = doubleTapSide != 0,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(if (doubleTapSide < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 32.dp)
            ) {
                Surface(
                    color = Color(0xB3000000),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = if (doubleTapSide < 0) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "${doubleTapSeconds}s",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = gestureOverlayType != 0,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Surface(
                    color = Color(0xCC121216),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Icon(
                            imageVector = if (gestureOverlayType == 1) Icons.Rounded.Brightness6 else Icons.Rounded.VolumeUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Box(
                            modifier = Modifier
                                .width(110.dp)
                                .height(5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(Color(0x40FFFFFF))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(gestureOverlayPercent.coerceIn(0f, 1f))
                                    .background(Color.White)
                            )
                        }
                        Text(
                            text = "${(gestureOverlayPercent * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            if (loadingStreams || (isBuffering && streamError == null)) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 3.dp,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(40.dp)
                )
            }

            if (streamError != null) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(16.dp)
                        .widthIn(max = 320.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = streamError ?: "",
                            color = CinemaColors.TextPrimary,
                            fontSize = 13.sp,
                            maxLines = 3
                        )
                        Button(
                            onClick = { reloadNonce++ },
                            shape = RoundedCornerShape(999.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إعادة المحاولة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = (showControls || activePanel != WatchPanel.NONE) && streamError == null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isFullCinema) 110.dp else 70.dp)
                            .align(Alignment.TopCenter)
                            .background(Brush.verticalGradient(listOf(Color(0xB8000000), Color.Transparent)))
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isFullCinema) 130.dp else 84.dp)
                            .align(Alignment.BottomCenter)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (isFullCinema) Modifier.statusBarsPadding() else Modifier)
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .align(Alignment.TopCenter),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            GlassCircleButton(
                                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                size = if (isFullCinema) 42.dp else 36.dp,
                                onClick = {
                                    if (isLandscape) onToggleLandscape() else onBack()
                                }
                            )

                            if (isFullCinema) {
                                Surface(
                                    color = CinemaColors.GlassFill,
                                    shape = RoundedCornerShape(999.dp),
                                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                                    modifier = Modifier
                                        .height(44.dp)
                                        .widthIn(max = 380.dp)
                                        .clickable {
                                            if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId)
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(start = 5.dp, end = 14.dp)
                                    ) {
                                        ChannelAvatar(url = displayAvatar, name = displayChannel, size = 32.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = displayTitle,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (displayChannel.isNotBlank()) {
                                                Text(
                                                    text = displayChannel,
                                                    color = CinemaColors.TextSecondary,
                                                    fontSize = 11.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isFullCinema) {
                                WatchPanelPill(
                                    icon = Icons.Rounded.Info,
                                    label = "Details",
                                    active = activePanel == WatchPanel.DETAILS,
                                    onClick = { activePanel = if (activePanel == WatchPanel.DETAILS) WatchPanel.NONE else WatchPanel.DETAILS }
                                )
                                WatchPanelPill(
                                    icon = Icons.Rounded.ChatBubbleOutline,
                                    label = "Comments",
                                    active = activePanel == WatchPanel.COMMENTS,
                                    onClick = { activePanel = if (activePanel == WatchPanel.COMMENTS) WatchPanel.NONE else WatchPanel.COMMENTS }
                                )
                                WatchPanelPill(
                                    icon = Icons.Rounded.QueueMusic,
                                    label = "Up next",
                                    active = activePanel == WatchPanel.UP_NEXT,
                                    onClick = { activePanel = if (activePanel == WatchPanel.UP_NEXT) WatchPanel.NONE else WatchPanel.UP_NEXT }
                                )
                            }

                            if (captions.isNotEmpty()) {
                                GlassCircleButton(
                                    icon = if (selectedCaption != null) Icons.Rounded.ClosedCaption else Icons.Rounded.ClosedCaptionOff,
                                    contentDescription = "Captions",
                                    size = if (isFullCinema) 40.dp else 34.dp,
                                    tint = if (selectedCaption != null) CinemaColors.YtRed else Color.White,
                                    onClick = {
                                        val nextCap = if (selectedCaption == null) {
                                            captions.firstOrNull { it.languageCode.startsWith(hl) } ?: captions.first()
                                        } else null
                                        selectedCaption = nextCap
                                        if (currentStreamIndex in streams.indices) {
                                            playChoice(streams[currentStreamIndex], exoPlayer.currentPosition, nextCap)
                                        }
                                    }
                                )
                            }

                            GlassCircleButton(
                                icon = Icons.Rounded.PictureInPictureAlt,
                                contentDescription = "Picture in Picture",
                                size = if (isFullCinema) 40.dp else 34.dp,
                                onClick = onEnterPip
                            )

                            GlassCircleButton(
                                icon = Icons.Rounded.Settings,
                                contentDescription = "Player Settings",
                                size = if (isFullCinema) 40.dp else 34.dp,
                                onClick = { showPlayerSettings = true }
                            )
                        }
                    }

                    if (activePanel == WatchPanel.NONE && !loadingStreams && !isBuffering) {
                        Row(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.spacedBy(if (isFullCinema) 28.dp else 22.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlassCircleButton(
                                icon = Icons.Rounded.Replay10,
                                contentDescription = "-10s",
                                size = if (isFullCinema) 48.dp else 42.dp,
                                onClick = {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L))
                                }
                            )
                            Surface(
                                color = Color(0xF0FFFFFF),
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(if (isFullCinema) 62.dp else 54.dp)
                                    .clickable {
                                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.Black,
                                        modifier = Modifier.size(if (isFullCinema) 34.dp else 30.dp)
                                    )
                                }
                            }
                            GlassCircleButton(
                                icon = Icons.Rounded.Forward10,
                                contentDescription = "+10s",
                                size = if (isFullCinema) 48.dp else 42.dp,
                                onClick = {
                                    val target = exoPlayer.currentPosition + 10_000L
                                    exoPlayer.seekTo(if (durationMs > 0) target.coerceAtMost(durationMs) else target)
                                }
                            )
                            if (isFullCinema && relatedVideos.isNotEmpty()) {
                                GlassCircleButton(
                                    icon = Icons.Rounded.SkipNext,
                                    contentDescription = "Next Video",
                                    size = 44.dp,
                                    onClick = { onOpenVideo(relatedVideos.first()) }
                                )
                            }
                        }
                    }

                    if (activePanel == WatchPanel.NONE) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = if (isFullCinema) 18.dp else 10.dp, vertical = if (isFullCinema) 12.dp else 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${formatTime(positionMs)} / ${formatTime(durationMs)}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (isFullCinema) {
                                        SmallGlassChip(
                                            text = if (isZoomFill) "Fill" else "Fit",
                                            onClick = { isZoomFill = !isZoomFill }
                                        )
                                    }
                                    SmallGlassChip(
                                        text = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                        onClick = { showPlayerSettings = true }
                                    )
                                    SmallGlassChip(
                                        text = activeQualityLabel,
                                        onClick = { showPlayerSettings = true }
                                    )
                                    Icon(
                                        imageVector = if (isLandscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                        contentDescription = "Fullscreen",
                                        tint = Color.White,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .clickable(onClick = onToggleLandscape)
                                            .padding(5.dp)
                                    )
                                }
                            }

                            Slider(
                                value = sliderPos,
                                onValueChange = { v ->
                                    isSeeking = true
                                    sliderPos = v
                                    if (durationMs > 0L) positionMs = (v * durationMs).toLong()
                                },
                                onValueChangeFinished = {
                                    if (durationMs > 0L) {
                                        val seekTo = (sliderPos * durationMs).toLong()
                                        exoPlayer.seekTo(seekTo)
                                        positionMs = seekTo
                                    }
                                    isSeeking = false
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = CinemaColors.YtRed,
                                    activeTrackColor = CinemaColors.YtRed,
                                    inactiveTrackColor = Color(0x4DFFFFFF)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(28.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack)
    ) {
        if (isInPipMode || isFullCinema) {
            playerBoxContent(Modifier.fillMaxSize())

            if (!isInPipMode) {
                AnimatedVisibility(
                    visible = activePanel != WatchPanel.NONE,
                    enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                    exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .statusBarsPadding()
                        .padding(top = 64.dp, end = 12.dp, bottom = 12.dp, start = 12.dp)
                        .widthIn(max = 420.dp)
                        .fillMaxWidth(if (isLandscape) 0.44f else 0.50f)
                        .fillMaxHeight()
                ) {
                    Surface(
                        color = CinemaColors.GlassStrong,
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = when (activePanel) {
                                        WatchPanel.DETAILS -> "Details"
                                        WatchPanel.COMMENTS -> "Comments"
                                        WatchPanel.UP_NEXT -> "Up next"
                                        WatchPanel.NONE -> ""
                                    },
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Close",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .clickable { activePanel = WatchPanel.NONE }
                                        .padding(4.dp)
                                )
                            }

                            when (activePanel) {
                                WatchPanel.DETAILS -> {
                                    DetailsContentBody(
                                        displayTitle = displayTitle,
                                        displayChannel = displayChannel,
                                        displayChannelId = displayChannelId,
                                        displayAvatar = displayAvatar,
                                        details = details,
                                        isLiked = isLiked,
                                        isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                                        onToggleLike = { onToggleLike(video.id) },
                                        onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                                        onToggleSubscribe = {
                                            if (displayChannelId.isNotBlank()) {
                                                onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                                            }
                                        },
                                        onSaveToPlaylist = { showPlaylistDialog = true },
                                        onShare = { shareCurrentVideo() }
                                    )
                                }

                                WatchPanel.COMMENTS -> {
                                    CommentsListBody(
                                        comments = comments,
                                        loading = !commentsLoaded && details?.commentsContinuation != null
                                    )
                                }

                                WatchPanel.UP_NEXT -> {
                                    UpNextListBody(
                                        related = relatedVideos,
                                        onSelect = {
                                            activePanel = WatchPanel.NONE
                                            onOpenVideo(it)
                                        }
                                    )
                                }

                                WatchPanel.NONE -> {}
                            }
                        }
                    }
                }
            }
        } else {
            // MOBILE PORTRAIT: Pinned 16:9 Pro Video Player + YouTube-Style Scrollable Feed Below
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(CinemaColors.BgBlack)
                    .statusBarsPadding()
            ) {
                playerBoxContent(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(bottom = 32.dp)
                ) {
                    item(key = "header_info") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showMobileDescriptionSheet = true }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = displayTitle,
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 23.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            val metaLine = listOfNotNull(
                                details?.viewCount?.takeIf { it.isNotBlank() },
                                details?.publishDate?.takeIf { it.isNotBlank() },
                                "...more"
                            ).joinToString(" · ")
                            Text(
                                text = metaLine,
                                color = CinemaColors.TextSecondary,
                                fontSize = 12.5.sp
                            )
                        }
                    }

                    item(key = "channel_row") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId)
                                    }
                            ) {
                                ChannelAvatar(url = displayAvatar, name = displayChannel, size = 40.dp)
                                Column {
                                    Text(
                                        text = displayChannel.ifBlank { "Channel" },
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    details?.subscriberCount?.takeIf { it.isNotBlank() }?.let {
                                        Text(it, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                                    }
                                }
                            }

                            if (displayChannelId.isNotBlank()) {
                                val subbed = isSubscribed(displayChannelId)
                                Surface(
                                    color = if (subbed) Color(0x26FFFFFF) else Color.White,
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                                    }
                                ) {
                                    Text(
                                        text = if (subbed) "Subscribed" else "Subscribe",
                                        color = if (subbed) Color.White else Color.Black,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                                    )
                                }
                            }
                        }
                    }

                    item(key = "actions_strip") {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                ActionGlassPill(
                                    icon = if (isLiked) Icons.Rounded.ThumbUp else Icons.Rounded.ThumbUpOffAlt,
                                    label = details?.likeCount?.takeIf { it.isNotBlank() } ?: "Like",
                                    active = isLiked,
                                    onClick = { onToggleLike(video.id) }
                                )
                            }
                            item {
                                ActionGlassPill(
                                    icon = Icons.Rounded.BookmarkAdd,
                                    label = "Save",
                                    onClick = { showPlaylistDialog = true }
                                )
                            }
                            item {
                                ActionGlassPill(
                                    icon = Icons.Rounded.Share,
                                    label = "Share",
                                    onClick = { shareCurrentVideo() }
                                )
                            }
                            item {
                                ActionGlassPill(
                                    icon = Icons.Rounded.HighQuality,
                                    label = activeQualityLabel,
                                    onClick = { showPlayerSettings = true }
                                )
                            }
                            item {
                                ActionGlassPill(
                                    icon = Icons.Rounded.Speed,
                                    label = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                    onClick = { showPlayerSettings = true }
                                )
                            }
                            if (captions.isNotEmpty()) {
                                item {
                                    ActionGlassPill(
                                        icon = Icons.Rounded.ClosedCaption,
                                        label = selectedCaption?.languageCode?.uppercase() ?: "CC",
                                        active = selectedCaption != null,
                                        onClick = { showPlayerSettings = true }
                                    )
                                }
                            }
                        }
                    }

                    item(key = "comments_preview") {
                        Surface(
                            color = CinemaColors.SurfaceDark,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                .clickable { showMobileCommentsSheet = true }
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (comments.isNotEmpty()) "Comments (${comments.size}+)" else "Comments",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text("View all", color = CinemaColors.TextSecondary, fontSize = 12.sp)
                                }
                                val topComment = comments.firstOrNull()
                                if (topComment != null) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        ChannelAvatar(url = topComment.avatarUrl, name = topComment.author, size = 26.dp)
                                        Text(
                                            text = topComment.text,
                                            color = CinemaColors.TextPrimary,
                                            fontSize = 12.5.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                } else {
                                    Text(
                                        text = if (!commentsLoaded && details?.commentsContinuation != null) "Loading comments..." else "Tap to view comments",
                                        color = CinemaColors.TextSecondary,
                                        fontSize = 12.5.sp
                                    )
                                }
                            }
                        }
                    }

                    item(key = "up_next_title") {
                        Text(
                            text = "Up next",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 10.dp)
                        )
                    }

                    if (relatedVideos.isEmpty()) {
                        item(key = "up_next_loading") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
                            }
                        }
                    } else {
                        items(relatedVideos, key = { "rel_${it.id}" }) { rel ->
                            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                CinemaVideoCard(
                                    item = rel,
                                    showAvatar = true,
                                    onClick = { onOpenVideo(rel) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showMobileCommentsSheet) {
            BottomSheetOverlay(
                title = "Comments",
                onDismiss = { showMobileCommentsSheet = false }
            ) {
                CommentsListBody(
                    comments = comments,
                    loading = !commentsLoaded && details?.commentsContinuation != null
                )
            }
        }

        if (showMobileDescriptionSheet) {
            BottomSheetOverlay(
                title = "Description",
                onDismiss = { showMobileDescriptionSheet = false }
            ) {
                DetailsContentBody(
                    displayTitle = displayTitle,
                    displayChannel = displayChannel,
                    displayChannelId = displayChannelId,
                    displayAvatar = displayAvatar,
                    details = details,
                    isLiked = isLiked,
                    isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                    onToggleLike = { onToggleLike(video.id) },
                    onOpenChannel = {
                        showMobileDescriptionSheet = false
                        if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId)
                    },
                    onToggleSubscribe = {
                        if (displayChannelId.isNotBlank()) {
                            onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                        }
                    },
                    onSaveToPlaylist = {
                        showMobileDescriptionSheet = false
                        showPlaylistDialog = true
                    },
                    onShare = { shareCurrentVideo() }
                )
            }
        }

        if (showPlayerSettings) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlayerSettings = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(20.dp)
                        .widthIn(max = 400.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Player Settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .clickable { showPlayerSettings = false }
                                    .padding(3.dp)
                            )
                        }

                        Text("Quality", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(streams.indices.toList()) { idx ->
                                val ch = streams[idx]
                                val active = idx == currentStreamIndex
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        currentStreamIndex = idx
                                        playChoice(ch, exoPlayer.currentPosition, selectedCaption)
                                        showPlayerSettings = false
                                    }
                                ) {
                                    Text(
                                        text = "${ch.label} · ${ch.clientTag}",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = Color(0x1AFFFFFF))

                        Text("Playback Speed", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
                            items(speeds) { sp ->
                                val active = playbackSpeed == sp
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        playbackSpeed = sp
                                        exoPlayer.playbackParameters = PlaybackParameters(sp)
                                    }
                                ) {
                                    Text(
                                        text = "${if (sp == 1f) "Normal" else "${sp}x"}",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = Color(0x1AFFFFFF))

                        Text("Captions (Subtitles)", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                val active = selectedCaption == null
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        selectedCaption = null
                                        if (currentStreamIndex in streams.indices) {
                                            playChoice(streams[currentStreamIndex], exoPlayer.currentPosition, null)
                                        }
                                    }
                                ) {
                                    Text(
                                        text = "Off",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                            items(captions) { cap ->
                                val active = selectedCaption?.languageCode == cap.languageCode
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        selectedCaption = cap
                                        if (currentStreamIndex in streams.indices) {
                                            playChoice(streams[currentStreamIndex], exoPlayer.currentPosition, cap)
                                        }
                                        showPlayerSettings = false
                                    }
                                ) {
                                    Text(
                                        text = cap.label,
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = Color(0x1AFFFFFF))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Rounded.AspectRatio, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Text("Video Fit", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(false to "Fit", true to "Zoom Fill").forEach { (zoom, label) ->
                                    val active = isZoomFill == zoom
                                    Surface(
                                        color = if (active) Color.White else Color(0x1EFFFFFF),
                                        shape = RoundedCornerShape(999.dp),
                                        modifier = Modifier.clickable { isZoomFill = zoom }
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (active) Color.Black else Color.White,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showPlaylistDialog) {
            val localPlaylists = playlists.filterNot { it.isRemote }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlaylistDialog = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(24.dp)
                        .widthIn(max = 320.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Save to Playlist", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        val richVideo = video.copy(
                            title = displayTitle,
                            channelName = displayChannel,
                            channelId = displayChannelId,
                            channelAvatar = displayAvatar
                        )
                        localPlaylists.forEach { pl ->
                            val saved = pl.videos.any { it.id == video.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x14FFFFFF))
                                    .clickable { onToggleVideoInPlaylist(pl.id, richVideo) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(pl.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                if (saved) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomSheetOverlay(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            color = CinemaColors.GlassStrong,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.68f)
                .navigationBarsPadding()
                .clickable(enabled = false) {}
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onDismiss)
                            .padding(4.dp)
                    )
                }
                HorizontalDivider(color = Color(0x1AFFFFFF))
                Box(modifier = Modifier.weight(1f)) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun DetailsContentBody(
    displayTitle: String,
    displayChannel: String,
    displayChannelId: String,
    displayAvatar: String,
    details: VideoDetails?,
    isLiked: Boolean,
    isSubscribed: Boolean,
    onToggleLike: () -> Unit,
    onOpenChannel: () -> Unit,
    onToggleSubscribe: () -> Unit,
    onSaveToPlaylist: () -> Unit,
    onShare: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(displayTitle, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, lineHeight = 23.sp)
        val metaText = listOfNotNull(
            details?.viewCount?.takeIf { it.isNotBlank() },
            details?.publishDate?.takeIf { it.isNotBlank() }
        ).joinToString(" · ")
        if (metaText.isNotBlank()) {
            Text(metaText, color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onOpenChannel)
            ) {
                ChannelAvatar(url = displayAvatar, name = displayChannel, size = 40.dp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(displayChannel, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    details?.subscriberCount?.takeIf { it.isNotBlank() }?.let {
                        Text(it, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                    }
                }
            }
            if (displayChannelId.isNotBlank()) {
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onToggleSubscribe)
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionGlassPill(
                icon = if (isLiked) Icons.Rounded.ThumbUp else Icons.Rounded.ThumbUpOffAlt,
                label = details?.likeCount?.takeIf { it.isNotBlank() } ?: "Like",
                active = isLiked,
                onClick = onToggleLike
            )
            ActionGlassPill(icon = Icons.Rounded.BookmarkAdd, label = "Save", onClick = onSaveToPlaylist)
            ActionGlassPill(icon = Icons.Rounded.Share, label = "Share", onClick = onShare)
        }

        val desc = details?.description ?: ""
        if (desc.isNotBlank()) {
            Surface(
                color = Color(0x14FFFFFF),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = desc,
                    color = CinemaColors.TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}

@Composable
private fun CommentsListBody(
    comments: List<CommentItem>,
    loading: Boolean
) {
    when {
        loading -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
            }
        }
        comments.isEmpty() -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No comments available", color = CinemaColors.TextSecondary, fontSize = 14.sp)
            }
        }
        else -> {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(comments) { c ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ChannelAvatar(url = c.avatarUrl, name = c.author, size = 32.dp)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(c.author, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                if (c.publishedTime.isNotBlank()) {
                                    Text(c.publishedTime, color = CinemaColors.TextSecondary, fontSize = 11.sp)
                                }
                            }
                            Text(c.text, color = CinemaColors.TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
                            if (c.likeCount.isNotBlank()) {
                                Text("👍 ${c.likeCount}", color = CinemaColors.TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpNextListBody(
    related: List<VideoItem>,
    onSelect: (VideoItem) -> Unit
) {
    if (related.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(related, key = { it.id }) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelect(item) }
                    .padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(136.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CinemaColors.SurfaceDark)
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (item.duration.isNotBlank()) {
                        Text(
                            text = item.duration,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .background(Color(0xC2000000), RoundedCornerShape(5.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(item.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.channelName, color = CinemaColors.TextSecondary, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (item.meta.isNotBlank()) {
                        Text(item.meta, color = CinemaColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionGlassPill(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) Color.White else Color(0x1EFFFFFF),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, if (active) Color.White else CinemaColors.GlassStroke),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(17.dp))
            Text(label, color = if (active) Color.Black else Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SmallGlassChip(text: String, onClick: () -> Unit) {
    Surface(
        color = CinemaColors.GlassFill,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun GlassCircleButton(
    icon: ImageVector,
    contentDescription: String,
    size: Dp = 42.dp,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Surface(
        color = CinemaColors.GlassFill,
        shape = CircleShape,
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier
            .size(size)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = contentDescription, tint = tint, modifier = Modifier.size(size * 0.52f))
        }
    }
}

@Composable
private fun WatchPanelPill(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) CinemaColors.PillActiveBg else CinemaColors.GlassFill,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier
            .height(40.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 13.dp)
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, color = if (active) Color.Black else Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
