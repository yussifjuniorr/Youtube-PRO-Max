package com.cinema.youtube.data

import com.cinema.youtube.model.DeviceAuthSession
import com.cinema.youtube.model.GoogleAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GoogleAuthManager {

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private const val TV_UA_COBALT = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version"
    private const val TV_UA_TIZEN =
        "Mozilla/5.0 (SMART-TV; LINUX; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) 85.0.4183.93/6.0 TV Safari/537.36"
    private const val TV_VERSION = "7.20250923.13.00"

    private const val YT_DEVICE_CODE_URL = "https://www.youtube.com/o/oauth2/device/code"
    private const val YT_TOKEN_URL = "https://www.youtube.com/o/oauth2/token"
    private const val GOOGLE_DEVICE_CODE_URL = "https://oauth2.googleapis.com/device/code"
    private const val GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
    private const val OAUTH_SCOPE =
        "http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content"

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    @Volatile
    private var cachedCreds: Pair<String, String>? = null

    sealed class PollResult {
        data class Success(val account: GoogleAccount) : PollResult()
        data class Pending(val slowDown: Boolean = false) : PollResult()
        data class Failed(val message: String) : PollResult()
    }

    private fun fetchTvOAuthCredentials(): Pair<String, String>? {
        cachedCreds?.let { return it }
        val userAgents = listOf(TV_UA_COBALT, TV_UA_TIZEN)

        for (ua in userAgents) {
            try {
                val tvReq = Request.Builder()
                    .url("https://www.youtube.com/tv")
                    .header("User-Agent", ua)
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .build()
                val html = http.newCall(tvReq).execute().use { resp ->
                    if (!resp.isSuccessful) "" else (resp.body?.string() ?: "")
                }
                if (html.isBlank()) continue

                parseClientCredsFromJs(html)?.let {
                    cachedCreds = it
                    return it
                }

                val candidatePaths = linkedSetOf<String>()
                val scriptPatterns = listOf(
                    Regex("id=\"base-js\"[^>]*src=\"([^\"]+)\""),
                    Regex("src=\"(/s/tv/html5/[^\"]+\\.js)\""),
                    Regex("\"jsUrl\"\\s*:\\s*\"([^\"]+)\""),
                    Regex("src=\"([^\"]*tv[^\"]*\\.js)\"")
                )
                for (rx in scriptPatterns) {
                    rx.findAll(html).forEach { m ->
                        candidatePaths.add(m.groupValues[1].replace("\\/", "/"))
                    }
                }

                for (jsPath in candidatePaths.take(4)) {
                    val fullJsUrl = when {
                        jsPath.startsWith("http") -> jsPath
                        jsPath.startsWith("//") -> "https:$jsPath"
                        else -> "https://www.youtube.com$jsPath"
                    }
                    val jsReq = Request.Builder()
                        .url(fullJsUrl)
                        .header("User-Agent", ua)
                        .build()
                    val js = http.newCall(jsReq).execute().use { resp ->
                        if (!resp.isSuccessful) "" else (resp.body?.string() ?: "")
                    }
                    if (js.isNotBlank()) {
                        parseClientCredsFromJs(js)?.let {
                            cachedCreds = it
                            return it
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun parseClientCredsFromJs(js: String): Pair<String, String>? {
        val p1 = Regex("clientId\\s*:\\s*[\"']([0-9]{10,15}-[a-zA-Z0-9_-]{20,50}\\.apps\\.googleusercontent\\.com)[\"'][^}]{0,400}?clientSecret\\s*:\\s*[\"']([^\"']{12,60})[\"']")
        p1.find(js)?.let {
            return Pair(it.groupValues[1], it.groupValues[2])
        }
        val p2 = Regex("clientSecret\\s*:\\s*[\"']([^\"']{12,60})[\"'][^}]{0,400}?clientId\\s*:\\s*[\"']([0-9]{10,15}-[a-zA-Z0-9_-]{20,50}\\.apps\\.googleusercontent\\.com)[\"']")
        p2.find(js)?.let {
            return Pair(it.groupValues[2], it.groupValues[1])
        }
        val idRegex = Regex("([0-9]{10,15}-[a-zA-Z0-9_-]{20,50}\\.apps\\.googleusercontent\\.com)")
        val secRegex = Regex("(GOCSPX-[a-zA-Z0-9_-]{16,40})")
        for (m in idRegex.findAll(js)) {
            val start = (m.range.first - 600).coerceAtLeast(0)
            val end = (m.range.last + 600).coerceAtMost(js.length)
            val window = js.substring(start, end)
            val sec = secRegex.find(window)?.groupValues?.get(1)
            if (!sec.isNullOrBlank()) {
                return Pair(m.groupValues[1], sec)
            }
        }
        val genericSec = Regex("(?:secret|client_secret)\\s*[:=]\\s*[\"']([a-zA-Z0-9_-]{18,45})[\"']", RegexOption.IGNORE_CASE)
        for (m in idRegex.findAll(js)) {
            val start = (m.range.first - 300).coerceAtLeast(0)
            val end = (m.range.last + 300).coerceAtMost(js.length)
            val window = js.substring(start, end)
            val sec = genericSec.find(window)?.groupValues?.get(1)
            if (!sec.isNullOrBlank()) {
                return Pair(m.groupValues[1], sec)
            }
        }
        return null
    }

    suspend fun startDeviceAuth(deviceId: String): Result<DeviceAuthSession> = withContext(Dispatchers.IO) {
        val creds = fetchTvOAuthCredentials()
            ?: return@withContext Result.failure(Exception("تعذّر تجهيز جلسة تسجيل الدخول من يوتيوب. تأكد من الإنترنت وجرب تاني."))

        val (clientId, clientSecret) = creds
        val endpoints = listOf(
            Pair(YT_DEVICE_CODE_URL, YT_TOKEN_URL),
            Pair(GOOGLE_DEVICE_CODE_URL, GOOGLE_TOKEN_URL)
        )

        var lastErr = "تعذّر الاتصال بخادم تسجيل الدخول"
        for ((codeUrl, tokenUrl) in endpoints) {
            try {
                val payload = JSONObject()
                    .put("client_id", clientId)
                    .put("scope", OAUTH_SCOPE)
                    .put("device_id", deviceId)
                    .put("device_model", "ytlr::")

                val req = Request.Builder()
                    .url(codeUrl)
                    .header("User-Agent", TV_UA_COBALT)
                    .post(payload.toString().toRequestBody(JSON_MEDIA))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val bodyStr = resp.body?.string() ?: ""
                    if (resp.isSuccessful && bodyStr.isNotBlank()) {
                        val json = JSONObject(bodyStr)
                        val deviceCode = json.optString("device_code")
                        val userCode = json.optString("user_code")
                        if (deviceCode.isNotBlank() && userCode.isNotBlank()) {
                            return@withContext Result.success(
                                DeviceAuthSession(
                                    deviceCode = deviceCode,
                                    userCode = userCode,
                                    verificationUrl = json.optString("verification_url")
                                        .ifBlank { json.optString("verification_uri") }
                                        .ifBlank { "https://www.google.com/device" },
                                    expiresInSec = json.optInt("expires_in", 1800),
                                    intervalSec = json.optInt("interval", 5).coerceAtLeast(3),
                                    clientId = clientId,
                                    clientSecret = clientSecret,
                                    tokenEndpoint = tokenUrl
                                )
                            )
                        }
                    } else if (bodyStr.isNotBlank()) {
                        val errJson = runCatching { JSONObject(bodyStr) }.getOrNull()
                        lastErr = errJson?.optString("error_description")
                            ?.ifBlank { errJson.optString("error") }
                            ?: "HTTP ${resp.code}"
                    }
                }
            } catch (e: Exception) {
                lastErr = e.message ?: lastErr
            }
        }
        Result.failure(Exception(lastErr))
    }

    suspend fun pollForToken(session: DeviceAuthSession): PollResult = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("client_id", session.clientId)
                .put("client_secret", session.clientSecret)
                .put("code", session.deviceCode)
                .put("grant_type", "http://oauth.net/grant_type/device/1.0")

            val req = Request.Builder()
                .url(session.tokenEndpoint)
                .header("User-Agent", TV_UA_COBALT)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            http.newCall(req).execute().use { resp ->
                val txt = resp.body?.string() ?: return@withContext PollResult.Pending()
                val json = JSONObject(txt)
                val accessToken = json.optString("access_token")
                if (resp.isSuccessful && accessToken.isNotBlank()) {
                    val refreshToken = json.optString("refresh_token")
                    val expiresIn = json.optLong("expires_in", 3600L)
                    val profile = fetchAccountProfile(accessToken)
                    val account = GoogleAccount(
                        accessToken = accessToken,
                        refreshToken = refreshToken,
                        expiresAtMs = System.currentTimeMillis() + expiresIn * 1000L,
                        clientId = session.clientId,
                        clientSecret = session.clientSecret,
                        tokenEndpoint = session.tokenEndpoint,
                        displayName = profile.first.ifBlank { "Google Account" },
                        email = profile.second,
                        avatarUrl = profile.third
                    )
                    return@withContext PollResult.Success(account)
                }

                when (val err = json.optString("error")) {
                    "authorization_pending" -> PollResult.Pending(slowDown = false)
                    "slow_down" -> PollResult.Pending(slowDown = true)
                    "expired_token" -> PollResult.Failed("انتهت صلاحية الكود، اضغط لتوليد كود جديد.")
                    "access_denied" -> PollResult.Failed("تم إلغاء تسجيل الدخول.")
                    else -> {
                        if (resp.code == 428) PollResult.Pending()
                        else PollResult.Failed(
                            json.optString("error_description").ifBlank { err.ifBlank { "فشل تسجيل الدخول" } }
                        )
                    }
                }
            }
        } catch (_: Exception) {
            PollResult.Pending()
        }
    }

    suspend fun getValidAccessToken(store: LocalStore): String? = withContext(Dispatchers.IO) {
        val acc = store.getGoogleAccount() ?: return@withContext null
        if (!acc.isExpiredOrSoon && acc.accessToken.isNotBlank()) {
            return@withContext acc.accessToken
        }
        if (acc.refreshToken.isBlank()) return@withContext acc.accessToken.takeIf { it.isNotBlank() }

        try {
            val payload = JSONObject()
                .put("client_id", acc.clientId)
                .put("client_secret", acc.clientSecret)
                .put("refresh_token", acc.refreshToken)
                .put("grant_type", "refresh_token")

            val req = Request.Builder()
                .url(acc.tokenEndpoint.ifBlank { YT_TOKEN_URL })
                .header("User-Agent", TV_UA_COBALT)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext acc.accessToken.takeIf { it.isNotBlank() }
                val json = JSONObject(resp.body?.string() ?: return@withContext null)
                val newToken = json.optString("access_token")
                if (newToken.isBlank()) return@withContext acc.accessToken.takeIf { it.isNotBlank() }
                val expiresIn = json.optLong("expires_in", 3600L)
                val updated = acc.copy(
                    accessToken = newToken,
                    expiresAtMs = System.currentTimeMillis() + expiresIn * 1000L
                )
                store.saveGoogleAccount(updated)
                newToken
            }
        } catch (_: Exception) {
            acc.accessToken.takeIf { it.isNotBlank() }
        }
    }

    suspend fun fetchAccountProfile(accessToken: String): Triple<String, String, String> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().put(
                "context",
                JSONObject().put(
                    "client",
                    JSONObject()
                        .put("clientName", "TVHTML5")
                        .put("clientVersion", TV_VERSION)
                        .put("hl", "en")
                        .put("gl", "US")
                )
            )
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/account/account_menu?prettyPrint=false")
                .header("User-Agent", TV_UA_COBALT)
                .header("Authorization", "Bearer $accessToken")
                .header("X-YouTube-Client-Name", "7")
                .header("X-YouTube-Client-Version", TV_VERSION)
                .post(body.toString().toRequestBody(JSON_MEDIA))
                .build()

            http.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val str = resp.body?.string() ?: ""
                    if (str.isNotBlank()) {
                        val json = JSONObject(str)
                        val header = findObj(json, "activeAccountHeaderRenderer")
                            ?: findObj(json, "accountItem")
                        if (header != null) {
                            val name = textOf(header.opt("accountName"))
                            val email = textOf(header.opt("email"))
                                .ifBlank { textOf(header.opt("channelHandle")) }
                            val thumbs = header.optJSONObject("accountPhoto")?.optJSONArray("thumbnails")
                            val avatar = thumbs?.optJSONObject(thumbs.length() - 1)?.optString("url") ?: ""
                            if (name.isNotBlank() || email.isNotBlank()) {
                                return@withContext Triple(name, email, avatar)
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }

        try {
            val req = Request.Builder()
                .url("https://www.googleapis.com/oauth2/v2/userinfo")
                .header("Authorization", "Bearer $accessToken")
                .build()
            http.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val json = JSONObject(resp.body?.string() ?: "")
                    return@withContext Triple(
                        json.optString("name"),
                        json.optString("email"),
                        json.optString("picture")
                    )
                }
            }
        } catch (_: Exception) {
        }

        Triple("YouTube User", "Signed in with Google", "")
    }

    private fun findObj(node: Any?, key: String, depth: Int = 0): JSONObject? {
        if (node == null || depth > 30) return null
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { return it }
                val it = node.keys()
                while (it.hasNext()) {
                    findObj(node.opt(it.next()), key, depth + 1)?.let { found -> return found }
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    findObj(node.opt(i), key, depth + 1)?.let { found -> return found }
                }
            }
        }
        return null
    }

    private fun textOf(node: Any?): String {
        if (node == null) return ""
        if (node is String) return node
        if (node !is JSONObject) return ""
        node.optString("simpleText").takeIf { it.isNotBlank() }?.let { return it }
        val runs = node.optJSONArray("runs") ?: return ""
        return buildString {
            for (i in 0 until runs.length()) {
                append(runs.optJSONObject(i)?.optString("text") ?: "")
            }
        }
    }
}
