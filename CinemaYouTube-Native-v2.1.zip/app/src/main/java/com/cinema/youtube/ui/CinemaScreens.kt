package com.cinema.youtube.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.GoogleAccount
import com.cinema.youtube.model.HistoryEntry
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay

enum class TopTab { HOME, SUBSCRIPTIONS, PLAYLISTS, HISTORY }

@Composable
fun ChannelAvatar(url: String, name: String, size: Dp) {
    if (url.isNotBlank()) {
        AsyncImage(
            model = url,
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x28FFFFFF))
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
        )
    } else {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x2EFFFFFF))
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
        ) {
            Text(
                text = name.trim().firstOrNull()?.uppercase() ?: "Y",
                color = Color.White,
                fontSize = (size.value * 0.44f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun AccountAvatarButton(
    account: GoogleAccount?,
    size: Dp = 36.dp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size)
            .clickable(onClick = onClick)
    ) {
        if (account != null) {
            ChannelAvatar(
                url = account.avatarUrl,
                name = account.displayName.ifBlank { "G" },
                size = size
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(CinemaColors.AccentGreen)
                    .border(1.5.dp, CinemaColors.BgBlack, CircleShape)
            )
        } else {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color(0x28FFFFFF))
                    .border(1.dp, CinemaColors.GlassStroke, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Person,
                    contentDescription = "Account",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.54f)
                )
            }
        }
    }
}

// ---------- ADAPTIVE TOP NAVIGATION (Mobile Compact Header vs Tablet Cinema Top Pill) ----------
@Composable
fun AdaptiveTopNavigation(
    isTablet: Boolean,
    account: GoogleAccount?,
    activeTab: TopTab,
    isSearching: Boolean,
    searchText: String,
    recentSearches: List<String>,
    hl: String,
    onTabSelected: (TopTab) -> Unit,
    onSearchModeChange: (Boolean) -> Unit,
    onSearchTextChange: (String) -> Unit,
    onSubmitSearch: (String) -> Unit,
    onClearRecentSearches: () -> Unit,
    onOpenAccount: () -> Unit
) {
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(isSearching, searchText) {
        if (!isSearching || searchText.isBlank()) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(140)
        suggestions = InnerTubeClient.fetchSuggestions(searchText, hl)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(top = 10.dp, start = 12.dp, end = 12.dp)
    ) {
        if (isTablet) {
            // TABLET / LANDSCAPE: Full Cinema Floating Glass Pill Bar
            Surface(
                color = CinemaColors.GlassFill,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                shadowElevation = 14.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (activeTab == TopTab.HOME && !isSearching) Color(0x26FFFFFF) else Color.Transparent)
                            .clickable {
                                onSearchModeChange(false)
                                onTabSelected(TopTab.HOME)
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .width(32.dp)
                                .height(22.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(CinemaColors.YtRed)
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = "Home", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    if (isSearching) {
                        SearchInputField(
                            searchText = searchText,
                            onSearchTextChange = onSearchTextChange,
                            onSubmit = { onSubmitSearch(searchText) },
                            onClose = {
                                onSearchTextChange("")
                                onSearchModeChange(false)
                            },
                            modifier = Modifier.widthIn(min = 240.dp, max = 380.dp)
                        )
                    } else {
                        NavPillItem("Subscriptions", activeTab == TopTab.SUBSCRIPTIONS) { onTabSelected(TopTab.SUBSCRIPTIONS) }
                        NavPillItem("Playlists", activeTab == TopTab.PLAYLISTS) { onTabSelected(TopTab.PLAYLISTS) }
                        NavPillItem("History", activeTab == TopTab.HISTORY) { onTabSelected(TopTab.HISTORY) }

                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = Color.White,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .clickable { onSearchModeChange(true) }
                                .padding(8.dp)
                        )

                        Spacer(Modifier.width(2.dp))
                        AccountAvatarButton(account = account, size = 34.dp, onClick = onOpenAccount)
                    }
                }
            }
        } else {
            // MOBILE VIEW: Clean, Breathable Header (Brand Pill on Left, Search + Account on Right)
            if (isSearching) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    shadowElevation = 12.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Close Search",
                            tint = Color.White,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable {
                                    onSearchTextChange("")
                                    onSearchModeChange(false)
                                }
                                .padding(7.dp)
                        )
                        SearchInputField(
                            searchText = searchText,
                            onSearchTextChange = onSearchTextChange,
                            onSubmit = { onSubmitSearch(searchText) },
                            onClose = {
                                if (searchText.isNotEmpty()) onSearchTextChange("")
                                else onSearchModeChange(false)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = CinemaColors.GlassFill,
                        shape = RoundedCornerShape(999.dp),
                        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                        shadowElevation = 8.dp,
                        modifier = Modifier.clickable { onTabSelected(TopTab.HOME) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(start = 10.dp, end = 14.dp, top = 7.dp, bottom = 7.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .width(28.dp)
                                    .height(20.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CinemaColors.YtRed)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                            }
                            Text(
                                text = "Cinema",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.2.sp
                            )
                        }
                    }

                    Surface(
                        color = CinemaColors.GlassFill,
                        shape = RoundedCornerShape(999.dp),
                        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                        shadowElevation = 8.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = Color.White,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .clickable { onSearchModeChange(true) }
                                    .padding(7.dp)
                            )
                            AccountAvatarButton(account = account, size = 34.dp, onClick = onOpenAccount)
                        }
                    }
                }
            }
        }

        if (isSearching) {
            val showItems = if (searchText.isBlank()) recentSearches.take(7) else suggestions
            if (showItems.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    shadowElevation = 14.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 520.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (searchText.isBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Recent searches", color = CinemaColors.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Clear",
                                    color = CinemaColors.TextSecondary,
                                    fontSize = 12.sp,
                                    modifier = Modifier.clickable(onClick = onClearRecentSearches)
                                )
                            }
                        }
                        showItems.forEach { s ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSubmitSearch(s) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Icon(
                                    imageVector = if (searchText.isBlank()) Icons.Rounded.History else Icons.Rounded.Search,
                                    contentDescription = null,
                                    tint = CinemaColors.TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = s,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchInputField(
    searchText: String,
    onSearchTextChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        BasicTextField(
            value = searchText,
            onValueChange = onSearchTextChange,
            singleLine = true,
            modifier = Modifier.weight(1f),
            textStyle = TextStyle(color = Color.White, fontSize = 14.5.sp),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
            decorationBox = { inner ->
                Box(
                    contentAlignment = Alignment.CenterStart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color(0x16FFFFFF))
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                ) {
                    if (searchText.isEmpty()) {
                        Text("Search YouTube...", color = CinemaColors.TextSecondary, fontSize = 14.sp)
                    }
                    inner()
                }
            }
        )
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "Go",
            tint = Color.White,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .clickable(onClick = onSubmit)
                .padding(7.dp)
        )
        Icon(
            imageVector = Icons.Rounded.Close,
            contentDescription = "Clear",
            tint = CinemaColors.TextSecondary,
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .clickable(onClick = onClose)
                .padding(7.dp)
        )
    }
}

// ---------- MOBILE FLOATING GLASS BOTTOM NAVIGATION BAR ----------
@Composable
fun MobileFloatingBottomNav(
    activeTab: TopTab,
    onTabSelected: (TopTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = CinemaColors.GlassStrong,
            shape = RoundedCornerShape(999.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            shadowElevation = 18.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomNavItem(
                    icon = Icons.Rounded.Home,
                    label = "Home",
                    active = activeTab == TopTab.HOME,
                    modifier = Modifier.weight(1f),
                    onClick = { onTabSelected(TopTab.HOME) }
                )
                BottomNavItem(
                    icon = Icons.Rounded.Subscriptions,
                    label = "Subs",
                    active = activeTab == TopTab.SUBSCRIPTIONS,
                    modifier = Modifier.weight(1f),
                    onClick = { onTabSelected(TopTab.SUBSCRIPTIONS) }
                )
                BottomNavItem(
                    icon = Icons.Rounded.VideoLibrary,
                    label = "Playlists",
                    active = activeTab == TopTab.PLAYLISTS,
                    modifier = Modifier.weight(1f),
                    onClick = { onTabSelected(TopTab.PLAYLISTS) }
                )
                BottomNavItem(
                    icon = Icons.Rounded.History,
                    label = "History",
                    active = activeTab == TopTab.HISTORY,
                    modifier = Modifier.weight(1f),
                    onClick = { onTabSelected(TopTab.HISTORY) }
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (active) Color(0x26FFFFFF) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (active) Color.White else CinemaColors.TextSecondary,
            modifier = Modifier.size(21.dp)
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            color = if (active) Color.White else CinemaColors.TextSecondary,
            fontSize = 10.5.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun NavPillItem(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (active) CinemaColors.PillActiveBg else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (active) CinemaColors.PillActiveText else Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

// ---------- HOME SCREEN (Adaptive Mobile vs Tablet) ----------
@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    isTablet: Boolean,
    heroVideos: List<VideoItem>,
    shelves: List<HomeShelf>,
    continueWatching: List<VideoItem>,
    isLoading: Boolean,
    onRefresh: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    if (isLoading && heroVideos.isEmpty() && shelves.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                Text("Loading Cinema YouTube...", color = CinemaColors.TextSecondary, fontSize = 14.sp)
            }
        }
        return
    }

    if (!isLoading && heroVideos.isEmpty() && shelves.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تعذّر تحميل الصفحة الرئيسية", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onRefresh)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة المحاولة", color = Color.Black, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        return
    }

    val bottomClearance = if (isTablet) 48.dp else 108.dp

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(bottom = bottomClearance)
    ) {
        if (heroVideos.isNotEmpty()) {
            item(key = "hero") {
                HeroCarousel(
                    isTablet = isTablet,
                    videos = heroVideos,
                    onPlayVideo = onPlayVideo,
                    onOpenChannel = onOpenChannel
                )
            }
        } else {
            item { Spacer(Modifier.height(92.dp)) }
        }

        if (continueWatching.isNotEmpty()) {
            item(key = "continue_watching") {
                CinemaShelf(
                    title = "Continue watching",
                    videos = continueWatching,
                    isTablet = isTablet,
                    onPlayVideo = onPlayVideo
                )
            }
        }

        items(shelves, key = { it.title }) { shelf ->
            CinemaShelf(
                title = shelf.title,
                videos = shelf.videos,
                isTablet = isTablet,
                onPlayVideo = onPlayVideo
            )
        }
    }
}

@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HeroCarousel(
    isTablet: Boolean,
    videos: List<VideoItem>,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { videos.size })
    val screenHeightDp = LocalConfiguration.current.screenHeightDp

    val heroHeight = if (isTablet) {
        (screenHeightDp * 0.62f).dp.coerceIn(420.dp, 540.dp)
    } else {
        (screenHeightDp * 0.46f).dp.coerceIn(335.dp, 400.dp)
    }

    LaunchedEffect(videos.size) {
        if (videos.size > 1) {
            while (true) {
                delay(8500)
                val next = (pagerState.currentPage + 1) % videos.size
                pagerState.animateScrollToPage(next)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(heroHeight)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = videos[page]
            var useFallbackThumb by remember(item.id) { mutableStateOf(false) }

            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = if (useFallbackThumb) item.thumbnailUrl else item.heroThumbnailUrl,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    onError = { useFallbackThumb = true },
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colorStops = arrayOf(
                                    0.0f to Color(0x8A050505),
                                    0.25f to Color(0x1E050505),
                                    0.58f to Color(0xB3050505),
                                    1.0f to CinemaColors.BgBlack
                                )
                            )
                        )
                )

                if (isTablet) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colorStops = arrayOf(
                                        0.0f to Color(0xCC050505),
                                        0.48f to Color(0x55050505),
                                        1.0f to Color.Transparent
                                    )
                                )
                            )
                    )
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .widthIn(max = if (isTablet) 600.dp else 460.dp)
                        .fillMaxWidth()
                        .padding(
                            start = if (isTablet) 32.dp else 16.dp,
                            end = if (isTablet) 32.dp else 16.dp,
                            bottom = if (isTablet) 34.dp else 38.dp
                        ),
                    verticalArrangement = Arrangement.spacedBy(if (isTablet) 11.dp else 8.dp)
                ) {
                    if (item.channelName.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.clickable {
                                if (item.channelId.isNotBlank()) onOpenChannel(item.channelId)
                            }
                        ) {
                            ChannelAvatar(url = item.channelAvatar, name = item.channelName, size = if (isTablet) 34.dp else 28.dp)
                            Text(
                                text = item.channelName,
                                color = Color.White,
                                fontSize = if (isTablet) 15.sp else 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Text(
                        text = item.title,
                        color = Color.White,
                        fontSize = if (isTablet) 30.sp else 21.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = if (isTablet) 36.sp else 26.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (item.duration.isNotBlank()) {
                            Text(
                                text = item.duration,
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        if (item.meta.isNotBlank()) {
                            Text(
                                text = item.meta,
                                color = CinemaColors.TextSecondary,
                                fontSize = 12.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(Modifier.height(2.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            color = Color(0xFFF5F5F7),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { onPlayVideo(item) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(
                                    horizontal = if (isTablet) 24.dp else 18.dp,
                                    vertical = if (isTablet) 12.dp else 10.dp
                                )
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(19.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Play", color = Color.Black, fontSize = 14.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (item.channelId.isNotBlank()) {
                            Surface(
                                color = CinemaColors.GlassFill,
                                shape = RoundedCornerShape(999.dp),
                                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                                modifier = Modifier.clickable { onOpenChannel(item.channelId) }
                            ) {
                                Text(
                                    text = if (isTablet) "View channel" else "Channel",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(
                                        horizontal = if (isTablet) 20.dp else 16.dp,
                                        vertical = if (isTablet) 12.dp else 10.dp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        if (videos.size > 1) {
            Surface(
                color = CinemaColors.GlassFill,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                modifier = Modifier
                    .align(if (isTablet) Alignment.BottomEnd else Alignment.BottomCenter)
                    .padding(
                        end = if (isTablet) 28.dp else 0.dp,
                        bottom = if (isTablet) 26.dp else 8.dp
                    )
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    repeat(videos.size) { i ->
                        val active = i == pagerState.currentPage
                        Box(
                            modifier = Modifier
                                .height(5.5.dp)
                                .width(if (active) 18.dp else 5.5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(if (active) Color.White else Color(0x55FFFFFF))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CinemaShelf(
    title: String,
    videos: List<VideoItem>,
    isTablet: Boolean,
    onPlayVideo: (VideoItem) -> Unit
) {
    val hPad = if (isTablet) 28.dp else 16.dp
    val cardW = if (isTablet) 276.dp else 218.dp

    Column(modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)) {
        Text(
            text = title,
            color = Color.White,
            fontSize = if (isTablet) 21.sp else 18.5.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = hPad, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = hPad, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(if (isTablet) 16.dp else 12.dp)
        ) {
            items(videos, key = { "${title}_${it.id}" }) { item ->
                CinemaVideoCard(
                    item = item,
                    width = cardW,
                    showAvatar = false,
                    onClick = { onPlayVideo(item) }
                )
            }
        }
    }
}

@Composable
fun CinemaVideoCard(
    item: VideoItem,
    width: Dp? = null,
    showAvatar: Boolean = true,
    onClick: () -> Unit
) {
    val cardMod = if (width != null) Modifier.width(width) else Modifier.fillMaxWidth()
    Column(
        modifier = cardMod.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp))
                .background(CinemaColors.SurfaceDark)
                .border(1.dp, Color(0x18FFFFFF), RoundedCornerShape(14.dp))
        ) {
            AsyncImage(
                model = item.thumbnailUrl,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (item.duration.isNotBlank()) {
                Text(
                    text = item.duration,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 8.dp, bottom = if (item.progressPercent > 0) 15.dp else 8.dp)
                        .background(Color(0xC2000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            if (item.progressPercent > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                        .height(3.5.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0x4DFFFFFF))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((item.progressPercent / 100f).coerceIn(0f, 1f))
                            .background(CinemaColors.YtRed)
                    )
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            if (showAvatar && item.channelName.isNotBlank()) {
                ChannelAvatar(url = item.channelAvatar, name = item.channelName, size = 34.dp)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 18.5.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val subLine = listOf(item.channelName, item.meta).filter { it.isNotBlank() }.joinToString(" · ")
                if (subLine.isNotBlank()) {
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = subLine,
                        color = CinemaColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun SubscriptionsScreen(
    isTablet: Boolean,
    subscriptions: List<SubscribedChannel>,
    subVideos: List<VideoItem>,
    onOpenChannel: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val bottomPad = if (isTablet) 48.dp else 108.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 90.dp, bottom = bottomPad, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("Subscriptions", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }

        if (subscriptions.isEmpty() && subVideos.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyStateCard(
                    title = "No subscribed channels yet",
                    subtitle = "Sign in with Google from your profile icon to sync your YouTube subscriptions, or tap Subscribe on any channel."
                )
            }
        } else {
            if (subscriptions.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(subscriptions, key = { it.id }) { ch ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(74.dp)
                                    .clickable { onOpenChannel(ch.id) }
                            ) {
                                ChannelAvatar(url = ch.avatarUrl, name = ch.name, size = 56.dp)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = ch.name,
                                    color = Color.White,
                                    fontSize = 11.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
            items(subVideos, key = { "sub_${it.id}" }) { vid ->
                CinemaVideoCard(item = vid, showAvatar = true, onClick = { onPlayVideo(vid) })
            }
        }
    }
}

@Composable
fun PlaylistsScreen(
    isTablet: Boolean,
    playlists: List<UserPlaylist>,
    remotePlaylistVideos: Map<String, List<VideoItem>>,
    loadingRemotePlaylistId: String?,
    onLoadRemotePlaylist: (String) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    val selected = playlists.firstOrNull { it.id == selectedPlaylistId }
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val bottomPad = if (isTablet) 48.dp else 108.dp

    LaunchedEffect(selected?.id) {
        if (selected != null && selected.isRemote && !remotePlaylistVideos.containsKey(selected.id)) {
            onLoadRemotePlaylist(selected.id)
        }
    }

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 90.dp, bottom = bottomPad, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (selected != null) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .clickable { selectedPlaylistId = null }
                            .padding(4.dp)
                    )
                    Text(selected.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }

            val displayVideos = if (selected.isRemote) {
                remotePlaylistVideos[selected.id] ?: emptyList()
            } else selected.videos

            if (loadingRemotePlaylistId == selected.id) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                    }
                }
            } else if (displayVideos.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyStateCard(
                        title = "Playlist is empty",
                        subtitle = "Open any video and tap Save to add it to your playlists."
                    )
                }
            } else {
                items(displayVideos, key = { "${selected.id}_${it.id}" }) { vid ->
                    CinemaVideoCard(item = vid, showAvatar = true, onClick = { onPlayVideo(vid) })
                }
            }
        } else {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Playlists", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier.clickable { showCreateDialog = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("New", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            items(playlists, key = { it.id }) { pl ->
                Surface(
                    color = CinemaColors.SurfaceDark,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPlaylistId = pl.id }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(98.dp)
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x1AFFFFFF)),
                                contentAlignment = Alignment.Center
                            ) {
                                val thumb = pl.thumbnailUrl.ifBlank { pl.videos.firstOrNull()?.thumbnailUrl ?: "" }
                                if (thumb.isNotBlank()) {
                                    AsyncImage(
                                        model = thumb,
                                        contentDescription = pl.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = CinemaColors.TextSecondary)
                                }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    text = pl.name,
                                    color = Color.White,
                                    fontSize = 15.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val sub = if (pl.isRemote) {
                                    pl.videoCountText.ifBlank { "YouTube Account" }
                                } else {
                                    "${pl.videos.size} videos"
                                }
                                Text(sub, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                            }
                        }
                        if (!pl.isRemote && pl.id != "watch_later" && pl.id != "favorites") {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Delete",
                                tint = CinemaColors.TextSecondary,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .clickable { onDeletePlaylist(pl.id) }
                                    .padding(4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = Color(0xFF1C1C20),
            title = { Text("New Playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Playlist name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) onCreatePlaylist(newName)
                    newName = ""
                    showCreateDialog = false
                }) { Text("Create", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel", color = CinemaColors.TextSecondary) }
            }
        )
    }
}

@Composable
fun HistoryScreen(
    isTablet: Boolean,
    history: List<HistoryEntry>,
    onPlayVideo: (VideoItem) -> Unit,
    onClearHistory: () -> Unit
) {
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val bottomPad = if (isTablet) 48.dp else 108.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 90.dp, bottom = bottomPad, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("History", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) {
                    Text(
                        text = "Clear local",
                        color = Color(0xFFFF6B6B),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable(onClick = onClearHistory)
                    )
                }
            }
        }
        if (history.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyStateCard(
                    title = "No watch history yet",
                    subtitle = "Videos you watch will appear here with automatic resume progress."
                )
            }
        } else {
            items(history, key = { "hist_${it.video.id}_${it.watchedAt}" }) { entry ->
                CinemaVideoCard(
                    item = entry.video.copy(progressPercent = entry.progressPercent),
                    showAvatar = true,
                    onClick = { onPlayVideo(entry.video) }
                )
            }
        }
    }
}

@Composable
fun SearchResultsScreen(
    isTablet: Boolean,
    query: String,
    results: List<VideoItem>,
    isLoading: Boolean,
    onPlayVideo: (VideoItem) -> Unit
) {
    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 28.dp else 16.dp
    val bottomPad = if (isTablet) 48.dp else 108.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 90.dp, bottom = bottomPad, start = hPad, end = hPad),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                text = "Results for \"$query\"",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (isLoading) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                }
            }
        } else if (results.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyStateCard(title = "No results found", subtitle = "Try a different search query.")
            }
        } else {
            items(results, key = { "sr_${it.id}" }) { item ->
                CinemaVideoCard(item = item, showAvatar = true, onClick = { onPlayVideo(item) })
            }
        }
    }
}

@Composable
fun ChannelScreen(
    isTablet: Boolean,
    channel: ChannelInfo?,
    isLoading: Boolean,
    isSubscribed: Boolean,
    onBack: () -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    if (isLoading && channel == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
        }
        return
    }
    if (channel == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Text("Channel unavailable", color = CinemaColors.TextSecondary)
        }
        return
    }

    val gridCols = if (isTablet) GridCells.Adaptive(minSize = 270.dp) else GridCells.Fixed(1)
    val hPad = if (isTablet) 24.dp else 16.dp

    LazyVerticalGrid(
        columns = gridCols,
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isTablet) 240.dp else 190.dp)
                    .background(CinemaColors.SurfaceDark)
            ) {
                if (channel.bannerUrl.isNotBlank()) {
                    AsyncImage(
                        model = channel.bannerUrl,
                        contentDescription = channel.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0x66000000), CinemaColors.BgBlack)))
                )
                Surface(
                    color = CinemaColors.GlassFill,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(14.dp)
                        .size(42.dp)
                        .clickable(onClick = onBack)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = hPad),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ChannelAvatar(url = channel.avatarUrl, name = channel.name, size = if (isTablet) 64.dp else 52.dp)
                    Column {
                        Text(channel.name, color = Color.White, fontSize = if (isTablet) 22.sp else 19.sp, fontWeight = FontWeight.Bold)
                        if (channel.subscriberCount.isNotBlank()) {
                            Text(channel.subscriberCount, color = CinemaColors.TextSecondary, fontSize = 13.sp)
                        }
                    }
                }
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable {
                        onToggleSubscribe(SubscribedChannel(channel.id, channel.name, channel.avatarUrl))
                    }
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }

        items(channel.videos, key = { "ch_${it.id}" }) { vid ->
            Box(modifier = Modifier.padding(horizontal = if (isTablet) 14.dp else hPad)) {
                CinemaVideoCard(item = vid, showAvatar = false, onClick = { onPlayVideo(vid) })
            }
        }
    }
}

@Composable
private fun EmptyStateCard(title: String, subtitle: String) {
    Surface(
        color = CinemaColors.SurfaceDark,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = CinemaColors.TextSecondary, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}
