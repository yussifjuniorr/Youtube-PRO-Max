package com.cinema.youtube.data

import com.cinema.youtube.model.CaptionTrack
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.ResolvedStreams
import com.cinema.youtube.model.StreamChoice
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

object InnerTubeClient {

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private val DUR_REGEX = Regex("^\\d{1,2}(:\\d{2}){1,2}$")
    private val CPN_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    private val rng = SecureRandom()

    private const val WEB_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36"
    private const val WEB_VERSION = "2.20250923.01.00"

    private const val TV_UA = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version"
    private const val TV_VERSION = "7.20250923.13.00"

    private const val VR_UA_NEW =
        "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    private const val VR_UA_ALT =
        "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12; Quest 2) gzip"
    private const val IOS_UA =
        "com.google.ios.youtube/20.14.2 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
    private const val ANDROID_UA =
        "com.google.android.youtube/20.10.38 (Linux; U; Android 14; Pixel 8 Pro) gzip"

    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(16, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    @Volatile
    private var cachedVisitorData: String? = null

    private fun generateCpn(): String = buildString(16) {
        repeat(16) { append(CPN_CHARS[rng.nextInt(CPN_CHARS.length)]) }
    }

    private fun getVisitorData(): String {
        cachedVisitorData?.takeIf { it.isNotBlank() }?.let { return it }
        try {
            val req = Request.Builder()
                .url("https://www.youtube.com/sw.js_data")
                .header("User-Agent", WEB_UA)
                .build()
            http.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val txt = resp.body?.string() ?: ""
                    val m = Regex("\"(Cg[a-zA-Z0-9_%-]{10,60})\"").find(txt)
                    val vd = m?.groupValues?.get(1)
                    if (!vd.isNullOrBlank()) {
                        cachedVisitorData = vd
                        return vd
                    }
                }
            }
        } catch (_: Exception) {
        }

        try {
            val payload = JSONObject().put(
                "context",
                JSONObject().put(
                    "client",
                    JSONObject()
                        .put("clientName", "WEB")
                        .put("clientVersion", WEB_VERSION)
                )
            )
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/visitor_id?prettyPrint=false")
                .header("User-Agent", WEB_UA)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()
            http.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val json = JSONObject(resp.body?.string() ?: "")
                    val vd = json.optJSONObject("responseContext")?.optString("visitorData")
                    if (!vd.isNullOrBlank()) {
                        cachedVisitorData = vd
                        return vd
                    }
                }
            }
        } catch (_: Exception) {
        }
        return ""
    }

    suspend fun fetchHomeShelves(
        gl: String,
        hl: String,
        subscriptions: List<SubscribedChannel>,
        accessToken: String? = null
    ): Pair<List<VideoItem>, List<HomeShelf>> = withContext(Dispatchers.IO) {
        coroutineScope {
            if (!accessToken.isNullOrBlank()) {
                val authHomeDeferred = async { fetchAuthHomeShelves(accessToken, gl, hl) }
                val authSubsDeferred = async { fetchAuthSubscriptions(accessToken, gl, hl).second }
                val authShelves = authHomeDeferred.await()
                val authSubVids = authSubsDeferred.await()

                if (authShelves.isNotEmpty() || authSubVids.isNotEmpty()) {
                    val combined = mutableListOf<HomeShelf>()
                    if (authSubVids.isNotEmpty()) {
                        combined.add(HomeShelf("Subscriptions", authSubVids.take(20)))
                    }
                    combined.addAll(authShelves)
                    val heroPool = (authShelves.firstOrNull()?.videos ?: authSubVids)
                        .distinctBy { it.id }
                        .take(6)
                    if (heroPool.isNotEmpty()) {
                        return@coroutineScope Pair(heroPool, combined)
                    }
                }
            }

            val subsDeferred = async { fetchSubscriptionFeed(subscriptions) }
            val browseHomeDeferred = async { browseVideos("FEwhat_to_watch", gl, hl) }
            val trendingDeferred = async { browseVideos("FEtrending", gl, hl) }
            val musicDeferred = async { browseVideos("UC-9-kyTW8ZkZNDHQJ6FgpwQ", gl, hl) }
            val gamingDeferred = async { browseVideos("UCOpNcN46UbXVtpKMrmU4Abg", gl, hl) }

            val subVideos = subsDeferred.await()
            val homeVideos = browseHomeDeferred.await()
            val trendingVideos = trendingDeferred.await()
            val musicVideos = musicDeferred.await()
            val gamingVideos = gamingDeferred.await()

            var forYou = if (homeVideos.size >= 6) homeVideos else trendingVideos
            if (forYou.size < 6) {
                val fallbackQuery = if (gl == "EG" || hl == "ar") "بودكاست مصر 2026" else "trending podcasts documentary"
                forYou = searchVideos(fallbackQuery, gl, hl)
            }

            val shelves = mutableListOf<HomeShelf>()
            if (subVideos.isNotEmpty()) {
                shelves.add(HomeShelf("New videos", subVideos.take(24)))
            }
            if (forYou.isNotEmpty()) {
                shelves.add(HomeShelf("For you", forYou.take(18)))
            }
            if (trendingVideos.isNotEmpty() && trendingVideos != forYou) {
                shelves.add(HomeShelf("Trending now", trendingVideos.take(18)))
            }
            if (gamingVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Gaming", gamingVideos.take(16)))
            }
            if (musicVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Music", musicVideos.take(16)))
            }

            if (shelves.size < 3) {
                val extraQueries = if (hl == "ar") {
                    listOf("أفلام وثائقية" to "Documentaries", "ملخص مباريات" to "Football & Sports", "بودكاست عربي" to "Podcasts")
                } else {
                    listOf("documentary cinema" to "Documentaries", "football highlights" to "Sports", "tech reviews" to "Tech")
                }
                val extraResults = extraQueries.map { (q, title) ->
                    async { title to searchVideos(q, gl, hl).take(14) }
                }.awaitAll()
                for ((title, vids) in extraResults) {
                    if (vids.isNotEmpty()) shelves.add(HomeShelf(title, vids))
                }
            }

            val heroPool = (if (subVideos.isNotEmpty()) subVideos else forYou)
                .distinctBy { it.id }
                .take(6)

            Pair(heroPool, shelves)
        }
    }

    private fun fetchAuthHomeShelves(accessToken: String, gl: String, hl: String): List<HomeShelf> {
        val json = postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", "default"), accessToken)
            ?: postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", "FEwhat_to_watch"), accessToken)
            ?: return emptyList()

        val shelves = mutableListOf<HomeShelf>()
        val shelfObjs = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "shelfRenderer", shelfObjs)
        for (sr in shelfObjs) {
            val title = extractText(sr.opt("title")).ifBlank {
                extractText(sr.optJSONObject("headerRenderer")?.opt("title"))
            }.ifBlank { "For you" }
            val vids = mutableListOf<VideoItem>()
            walkVideos(sr, vids)
            val clean = vids.distinctBy { it.id }
            if (clean.isNotEmpty()) {
                shelves.add(HomeShelf(title, clean.take(18)))
            }
        }
        if (shelves.isEmpty()) {
            val all = mutableListOf<VideoItem>()
            walkVideos(json, all)
            val clean = all.distinctBy { it.id }
            if (clean.isNotEmpty()) {
                shelves.add(HomeShelf("For you", clean.take(24)))
            }
        }
        return shelves.take(8)
    }

    suspend fun fetchAuthSubscriptions(
        accessToken: String,
        gl: String,
        hl: String
    ): Pair<List<SubscribedChannel>, List<VideoItem>> = withContext(Dispatchers.IO) {
        val json = postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", "FEsubscriptions"), accessToken)
            ?: return@withContext Pair(emptyList(), emptyList())

        val videos = mutableListOf<VideoItem>()
        walkVideos(json, videos)
        val cleanVideos = videos.distinctBy { it.id }

        val channels = linkedMapOf<String, SubscribedChannel>()
        val channelObjs = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "gridChannelRenderer", channelObjs)
        collectObjectsByKey(json, "channelRenderer", channelObjs)
        for (c in channelObjs) {
            val cid = c.optString("channelId").ifBlank {
                deepFindObject(c, "browseEndpoint")?.optString("browseId") ?: ""
            }
            val name = extractText(c.opt("title"))
            val avatar = absUrl(deepFindThumbUrl(c, "thumbnail"))
            if (cid.startsWith("UC") && name.isNotBlank()) {
                channels[cid] = SubscribedChannel(cid, name, avatar)
            }
        }
        for (v in cleanVideos) {
            if (v.channelId.startsWith("UC") && v.channelName.isNotBlank() && !channels.containsKey(v.channelId)) {
                channels[v.channelId] = SubscribedChannel(v.channelId, v.channelName, v.channelAvatar)
            }
        }
        Pair(channels.values.toList(), cleanVideos)
    }

    suspend fun fetchAuthHistory(
        accessToken: String,
        gl: String,
        hl: String
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val json = postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", "FEhistory"), accessToken)
            ?: return@withContext emptyList()
        val vids = mutableListOf<VideoItem>()
        walkVideos(json, vids)
        vids.distinctBy { it.id }.take(50)
    }

    suspend fun fetchAuthPlaylists(
        accessToken: String,
        gl: String,
        hl: String
    ): List<UserPlaylist> = withContext(Dispatchers.IO) {
        val json = postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", "FElibrary"), accessToken)
            ?: postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", "FEplaylist_aggregation"), accessToken)
            ?: return@withContext emptyList()

        val result = linkedMapOf<String, UserPlaylist>()
        result["VLWL"] = UserPlaylist(
            id = "VLWL",
            name = "Watch Later (YouTube)",
            videos = emptyList(),
            isRemote = true,
            videoCountText = "YouTube Account"
        )
        result["VLLL"] = UserPlaylist(
            id = "VLLL",
            name = "Liked Videos (YouTube)",
            videos = emptyList(),
            isRemote = true,
            videoCountText = "YouTube Account"
        )

        val tiles = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "tileRenderer", tiles)
        collectObjectsByKey(json, "gridPlaylistRenderer", tiles)
        collectObjectsByKey(json, "playlistRenderer", tiles)
        for (t in tiles) {
            val browseId = deepFindObject(t, "browseEndpoint")?.optString("browseId") ?: ""
            val plId = t.optString("playlistId").takeIf { it.isNotBlank() }
                ?: if (browseId.startsWith("VL")) browseId else ""
            if (plId.isBlank()) continue
            val normalizedId = if (plId.startsWith("VL")) plId else "VL$plId"
            val title = extractText(t.opt("title")).ifBlank {
                extractText(deepFindObject(t, "tileMetadataRenderer")?.opt("title"))
            }
            if (title.isBlank()) continue
            val thumb = absUrl(deepFindThumbUrl(t, "thumbnails"))
            val countText = extractText(t.opt("videoCountText"))
                .ifBlank { extractText(t.opt("videoCountShortText")) }
                .ifBlank { "YouTube Playlist" }
            result[normalizedId] = UserPlaylist(
                id = normalizedId,
                name = title,
                videos = emptyList(),
                isRemote = true,
                thumbnailUrl = thumb,
                videoCountText = countText
            )
        }
        result.values.toList()
    }

    suspend fun fetchRemotePlaylistVideos(
        playlistBrowseId: String,
        accessToken: String?,
        gl: String,
        hl: String
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val bid = if (playlistBrowseId.startsWith("VL")) playlistBrowseId else "VL$playlistBrowseId"
        val json = if (!accessToken.isNullOrBlank()) {
            postTvInnerTube("browse", tvContextBody(gl, hl).put("browseId", bid), accessToken)
        } else {
            postInnerTube("browse", webContextBody(gl, hl).put("browseId", bid))
        } ?: return@withContext emptyList()
        val vids = mutableListOf<VideoItem>()
        walkVideos(json, vids)
        vids.distinctBy { it.id }.take(60)
    }

    suspend fun syncLikeVideo(videoId: String, like: Boolean, accessToken: String?): Boolean =
        withContext(Dispatchers.IO) {
            if (accessToken.isNullOrBlank()) return@withContext false
            val endpoint = if (like) "like/like" else "like/removelike"
            val body = tvContextBody("US", "en")
                .put("target", JSONObject().put("videoId", videoId))
            postTvInnerTube(endpoint, body, accessToken) != null
        }

    suspend fun syncSubscribeChannel(channelId: String, subscribe: Boolean, accessToken: String?): Boolean =
        withContext(Dispatchers.IO) {
            if (accessToken.isNullOrBlank() || !channelId.startsWith("UC")) return@withContext false
            val endpoint = if (subscribe) "subscription/subscribe" else "subscription/unsubscribe"
            val body = tvContextBody("US", "en")
                .put("channelIds", JSONArray().put(channelId))
            postTvInnerTube(endpoint, body, accessToken) != null
        }

    suspend fun fetchSubscriptionFeed(subscriptions: List<SubscribedChannel>): List<VideoItem> =
        withContext(Dispatchers.IO) {
            if (subscriptions.isEmpty()) return@withContext emptyList()
            coroutineScope {
                subscriptions.take(15).map { ch ->
                    async { fetchChannelRss(ch) }
                }.awaitAll()
                    .flatten()
                    .distinctBy { it.id }
            }
        }

    private fun fetchChannelRss(channel: SubscribedChannel): List<VideoItem> {
        if (!channel.id.startsWith("UC")) return emptyList()
        return try {
            val req = Request.Builder()
                .url("https://www.youtube.com/feeds/videos.xml?channel_id=${channel.id}")
                .header("User-Agent", WEB_UA)
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val xml = resp.body?.string() ?: return emptyList()
                val out = mutableListOf<VideoItem>()
                val entryRegex = Regex("<entry>([\\s\\S]*?)</entry>")
                val vidRegex = Regex("<yt:videoId>([^<]+)</yt:videoId>")
                val titleRegex = Regex("<title>([\\s\\S]*?)</title>")
                val pubRegex = Regex("<published>([^<]+)</published>")
                for (m in entryRegex.findAll(xml)) {
                    val block = m.groupValues[1]
                    val id = vidRegex.find(block)?.groupValues?.get(1)?.trim() ?: continue
                    val rawTitle = titleRegex.find(block)?.groupValues?.get(1)?.trim() ?: continue
                    val pub = pubRegex.find(block)?.groupValues?.get(1)?.take(10) ?: ""
                    out.add(
                        VideoItem(
                            id = id,
                            title = decodeXml(rawTitle),
                            channelName = channel.name,
                            channelId = channel.id,
                            channelAvatar = channel.avatarUrl,
                            meta = pub
                        )
                    )
                }
                out.take(8)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun searchVideos(query: String, gl: String, hl: String): List<VideoItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isEmpty()) return@withContext emptyList()
            val body = webContextBody(gl, hl).put("query", q)
            val json = postInnerTube("search", body) ?: return@withContext emptyList()
            val out = mutableListOf<VideoItem>()
            walkVideos(json, out)
            out.distinctBy { it.id }
        }

    suspend fun fetchSuggestions(query: String, hl: String): List<String> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isEmpty()) return@withContext emptyList()
            try {
                val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&oe=utf-8" +
                    "&hl=${URLEncoder.encode(hl, "UTF-8")}&q=${URLEncoder.encode(q, "UTF-8")}"
                val req = Request.Builder().url(url).header("User-Agent", WEB_UA).build()
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    val text = resp.body?.string() ?: return@withContext emptyList()
                    val arr = JSONArray(text)
                    if (arr.length() < 2) return@withContext emptyList()
                    val items = arr.getJSONArray(1)
                    (0 until items.length()).mapNotNull { items.optString(it).takeIf { s -> s.isNotBlank() } }.take(8)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    suspend fun fetchChannel(channelId: String, gl: String, hl: String): ChannelInfo? =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl)
                .put("browseId", channelId)
                .put("params", "EgZ2aWRlb3PyBgQKAjoA")
            val json = postInnerTube("browse", body) ?: return@withContext null

            val videos = mutableListOf<VideoItem>()
            walkVideos(json, videos)

            val meta = json.optJSONObject("metadata")?.optJSONObject("channelMetadataRenderer")
            val header = json.optJSONObject("header")

            val name = meta?.optString("title")?.takeIf { it.isNotBlank() }
                ?: extractText(deepFindObject(header, "title"))
                    .ifBlank { videos.firstOrNull()?.channelName ?: "Channel" }

            val avatarUrl = absUrl(
                meta?.optJSONObject("avatar")?.optJSONArray("thumbnails")?.lastThumbUrl()
                    ?: deepFindThumbUrl(header, "avatar")
            )
            val bannerUrl = absUrl(
                deepFindThumbUrl(header, "banner")
                    .ifBlank { deepFindThumbUrl(header, "imageBannerViewModel") }
            )
            val subCount = extractText(deepFindObject(header, "subscriberCountText"))
                .ifBlank { extractSubscriberFromPageHeader(header) }
            val desc = meta?.optString("description") ?: ""

            val normalizedVideos = videos.distinctBy { it.id }.map {
                it.copy(
                    channelName = it.channelName.ifBlank { name },
                    channelId = it.channelId.ifBlank { channelId },
                    channelAvatar = it.channelAvatar.ifBlank { avatarUrl }
                )
            }

            ChannelInfo(
                id = channelId,
                name = name,
                avatarUrl = avatarUrl,
                bannerUrl = bannerUrl,
                subscriberCount = subCount,
                description = desc,
                videos = normalizedVideos
            )
        }

    suspend fun fetchWatchDetails(videoId: String, gl: String, hl: String): VideoDetails? =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl).put("videoId", videoId)
            val json = postInnerTube("next", body) ?: return@withContext null

            val primary = deepFindObject(json, "videoPrimaryInfoRenderer")
            val secondary = deepFindObject(json, "videoSecondaryInfoRenderer")
            val owner = secondary?.optJSONObject("owner")?.optJSONObject("videoOwnerRenderer")

            val title = extractText(primary?.opt("title"))
            val viewCount = extractText(
                primary?.optJSONObject("viewCount")?.optJSONObject("videoViewCountRenderer")?.opt("viewCount")
            ).ifBlank {
                extractText(primary?.optJSONObject("viewCount")?.optJSONObject("videoViewCountRenderer")?.opt("shortViewCount"))
            }
            val publishDate = extractText(primary?.opt("dateText"))
                .ifBlank { extractText(primary?.opt("relativeDateText")) }

            val channelName = extractText(owner?.opt("title"))
            val channelId = owner?.optJSONObject("navigationEndpoint")
                ?.optJSONObject("browseEndpoint")
                ?.optString("browseId") ?: ""
            val channelAvatar = absUrl(
                owner?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
            )
            val subCount = extractText(owner?.opt("subscriberCountText"))

            val description = extractText(secondary?.opt("attributedDescription"))
                .ifBlank { extractText(secondary?.opt("description")) }

            val likeText = findLikeCount(primary)

            val secondaryResults = deepFindObject(json, "secondaryResults")
            val related = mutableListOf<VideoItem>()
            if (secondaryResults != null) {
                walkVideos(secondaryResults, related)
            }

            val commentsToken = findCommentsContinuation(json)

            VideoDetails(
                videoId = videoId,
                title = title,
                channelName = channelName,
                channelId = channelId,
                channelAvatar = channelAvatar,
                viewCount = viewCount,
                publishDate = publishDate,
                description = description,
                likeCount = likeText,
                subscriberCount = subCount,
                relatedVideos = related.distinctBy { it.id }.filterNot { it.id == videoId }.take(25),
                commentsContinuation = commentsToken
            )
        }

    suspend fun fetchComments(continuation: String, gl: String, hl: String): List<CommentItem> =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl).put("continuation", continuation)
            val json = postInnerTube("next", body) ?: return@withContext emptyList()
            val out = mutableListOf<CommentItem>()

            val payloads = mutableListOf<JSONObject>()
            collectObjectsByKey(json, "commentEntityPayload", payloads)
            for (p in payloads) {
                val props = p.optJSONObject("properties") ?: continue
                val authorObj = p.optJSONObject("author")
                val toolbar = p.optJSONObject("toolbar")
                val text = props.optJSONObject("content")?.optString("content") ?: continue
                if (text.isBlank()) continue
                out.add(
                    CommentItem(
                        author = authorObj?.optString("displayName")?.ifBlank { "User" } ?: "User",
                        avatarUrl = absUrl(authorObj?.optString("avatarThumbnailUrl") ?: ""),
                        text = text,
                        publishedTime = props.optString("publishedTime"),
                        likeCount = toolbar?.optString("likeCountNotliked") ?: ""
                    )
                )
            }

            if (out.isEmpty()) {
                val renderers = mutableListOf<JSONObject>()
                collectObjectsByKey(json, "commentRenderer", renderers)
                for (r in renderers) {
                    val text = extractText(r.opt("contentText"))
                    if (text.isBlank()) continue
                    out.add(
                        CommentItem(
                            author = extractText(r.opt("authorText")).ifBlank { "User" },
                            avatarUrl = absUrl(
                                r.optJSONObject("authorThumbnail")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
                            ),
                            text = text,
                            publishedTime = extractText(r.opt("publishedTimeText")),
                            likeCount = extractText(r.opt("voteCount"))
                        )
                    )
                }
            }
            out.take(45)
        }

    // ---------- 7-Layer Ad-Free Stream Resolver ----------

    suspend fun resolveStreams(
        videoId: String,
        accessToken: String? = null
    ): ResolvedStreams = withContext(Dispatchers.IO) {
        val allChoices = mutableListOf<StreamChoice>()
        val allCaptions = linkedMapOf<String, CaptionTrack>()
        var title = ""
        var channelName = ""
        var channelId = ""
        var durationSec = 0L
        var lastError: String? = null

        val visitorData = getVisitorData()
        val cpn = generateCpn()

        val clients = buildList {
            add(
                PlayerClientSpec(
                    tag = "VR",
                    userAgent = VR_UA_NEW,
                    clientNameHeader = "28",
                    clientVersionHeader = "1.65.10",
                    useOriginHeader = false,
                    useAuth = false,
                    clientJson = JSONObject()
                        .put("clientName", "ANDROID_VR")
                        .put("clientVersion", "1.65.10")
                        .put("deviceMake", "Oculus")
                        .put("deviceModel", "Quest 3")
                        .put("osName", "Android")
                        .put("osVersion", "12L")
                        .put("androidSdkVersion", 32)
                        .put("hl", "en")
                        .put("gl", "US")
                )
            )
            if (!accessToken.isNullOrBlank()) {
                add(
                    PlayerClientSpec(
                        tag = "TV_AUTH",
                        userAgent = TV_UA,
                        clientNameHeader = "7",
                        clientVersionHeader = TV_VERSION,
                        useOriginHeader = true,
                        useAuth = true,
                        clientJson = JSONObject()
                            .put("clientName", "TVHTML5")
                            .put("clientVersion", TV_VERSION)
                            .put("hl", "en")
                            .put("gl", "US")
                    )
                )
            }
            add(
                PlayerClientSpec(
                    tag = "IOS",
                    userAgent = IOS_UA,
                    clientNameHeader = "5",
                    clientVersionHeader = "20.14.2",
                    useOriginHeader = false,
                    useAuth = false,
                    clientJson = JSONObject()
                        .put("clientName", "IOS")
                        .put("clientVersion", "20.14.2")
                        .put("deviceMake", "Apple")
                        .put("deviceModel", "iPhone16,2")
                        .put("osName", "iPhone")
                        .put("osVersion", "18.3.2.22D82")
                        .put("hl", "en")
                        .put("gl", "US")
                )
            )
            add(
                PlayerClientSpec(
                    tag = "VR2",
                    userAgent = VR_UA_ALT,
                    clientNameHeader = "28",
                    clientVersionHeader = "1.62.27",
                    useOriginHeader = false,
                    useAuth = false,
                    clientJson = JSONObject()
                        .put("clientName", "ANDROID_VR")
                        .put("clientVersion", "1.62.27")
                        .put("deviceMake", "Oculus")
                        .put("deviceModel", "Quest 2")
                        .put("osName", "Android")
                        .put("osVersion", "12")
                        .put("androidSdkVersion", 32)
                        .put("hl", "en")
                        .put("gl", "US")
                )
            )
            add(
                PlayerClientSpec(
                    tag = "ANDROID",
                    userAgent = ANDROID_UA,
                    clientNameHeader = "3",
                    clientVersionHeader = "20.10.38",
                    useOriginHeader = false,
                    useAuth = false,
                    clientJson = JSONObject()
                        .put("clientName", "ANDROID")
                        .put("clientVersion", "20.10.38")
                        .put("deviceMake", "Google")
                        .put("deviceModel", "Pixel 8 Pro")
                        .put("osName", "Android")
                        .put("osVersion", "14")
                        .put("androidSdkVersion", 34)
                        .put("hl", "en")
                        .put("gl", "US")
                )
            )
            add(
                PlayerClientSpec(
                    tag = "EMBED",
                    userAgent = WEB_UA,
                    clientNameHeader = "56",
                    clientVersionHeader = "1.20250923.21.00",
                    useOriginHeader = true,
                    useAuth = false,
                    isEmbed = true,
                    clientJson = JSONObject()
                        .put("clientName", "WEB_EMBEDDED_PLAYER")
                        .put("clientVersion", "1.20250923.21.00")
                        .put("hl", "en")
                        .put("gl", "US")
                )
            )
        }

        for (spec in clients) {
            try {
                val clientObj = JSONObject(spec.clientJson.toString())
                if (visitorData.isNotBlank()) {
                    clientObj.put("visitorData", visitorData)
                }
                val contextObj = JSONObject().put("client", clientObj)
                if (spec.isEmbed) {
                    contextObj.put("thirdParty", JSONObject().put("embedUrl", "https://www.youtube.com/"))
                }

                val payload = JSONObject()
                    .put("videoId", videoId)
                    .put("cpn", cpn)
                    .put("contentCheckOk", true)
                    .put("racyCheckOk", true)
                    .put("context", contextObj)

                val reqBuilder = Request.Builder()
                    .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                    .header("User-Agent", spec.userAgent)
                    .header("X-YouTube-Client-Name", spec.clientNameHeader)
                    .header("X-YouTube-Client-Version", spec.clientVersionHeader)
                    .post(payload.toString().toRequestBody(JSON_MEDIA))

                if (visitorData.isNotBlank()) {
                    reqBuilder.header("X-Goog-Visitor-Id", visitorData)
                }
                if (spec.useOriginHeader) {
                    reqBuilder.header("Origin", "https://www.youtube.com")
                    reqBuilder.header("Referer", "https://www.youtube.com/")
                }
                if (spec.useAuth && !accessToken.isNullOrBlank()) {
                    reqBuilder.header("Authorization", "Bearer $accessToken")
                }

                val json = http.newCall(reqBuilder.build()).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        if (lastError == null) lastError = "HTTP ${resp.code}"
                        null
                    } else {
                        val txt = resp.body?.string()
                        if (txt.isNullOrBlank()) null else JSONObject(txt)
                    }
                } ?: continue

                extractCaptions(json).forEach { cap ->
                    if (!allCaptions.containsKey(cap.languageCode)) {
                        allCaptions[cap.languageCode] = cap
                    }
                }

                val status = json.optJSONObject("playabilityStatus")?.optString("status") ?: ""
                if (status != "OK") {
                    val reason = json.optJSONObject("playabilityStatus")?.optString("reason")
                    if (!reason.isNullOrBlank() && lastError == null) {
                        lastError = reason
                    }
                    continue
                }

                val vd = json.optJSONObject("videoDetails")
                if (vd != null && title.isBlank()) {
                    title = vd.optString("title")
                    channelName = vd.optString("author")
                    channelId = vd.optString("channelId")
                    durationSec = vd.optString("lengthSeconds").toLongOrNull() ?: 0L
                }

                val sd = json.optJSONObject("streamingData") ?: continue
                val extracted = extractStreamChoices(sd, spec.tag, spec.userAgent)
                if (extracted.isNotEmpty()) {
                    allChoices.addAll(extracted)
                    if (allChoices.map { it.clientTag }.distinct().size >= 2) break
                }
            } catch (e: Exception) {
                if (lastError == null) lastError = e.message
            }
        }

        if (allChoices.isEmpty()) {
            val fallbackChoices = resolveViaPipedOrInvidious(videoId, allCaptions)
            if (fallbackChoices.isNotEmpty()) {
                allChoices.addAll(fallbackChoices)
            }
        }

        ResolvedStreams(
            choices = allChoices,
            captions = allCaptions.values.toList(),
            title = title,
            channelName = channelName,
            channelId = channelId,
            durationSec = durationSec,
            errorMessage = if (allChoices.isEmpty()) {
                lastError ?: "تعذّر جلب روابط تشغيل هذا الفيديو. جرّب إعادة المحاولة."
            } else null
        )
    }

    private fun extractCaptions(json: JSONObject): List<CaptionTrack> {
        val tracks = json.optJSONObject("captions")
            ?.optJSONObject("playerCaptionsTracklistRenderer")
            ?.optJSONArray("captionTracks") ?: return emptyList()
        val out = mutableListOf<CaptionTrack>()
        for (i in 0 until tracks.length()) {
            val t = tracks.optJSONObject(i) ?: continue
            val base = t.optString("baseUrl")
            if (!base.startsWith("http")) continue
            val lang = t.optString("languageCode").ifBlank { "und" }
            val name = extractText(t.opt("name")).ifBlank { lang.uppercase() }
            val vttUrl = if (base.contains("fmt=")) base else "$base&fmt=vtt"
            out.add(CaptionTrack(label = name, languageCode = lang, url = vttUrl))
        }
        return out
    }

    private fun resolveViaPipedOrInvidious(
        videoId: String,
        captionsOut: MutableMap<String, CaptionTrack>
    ): List<StreamChoice> {
        val pipedHosts = listOf(
            "https://api.piped.private.coffee",
            "https://pipedapi.kavin.rocks",
            "https://pipedapi.adminforge.de"
        )
        for (host in pipedHosts) {
            try {
                val req = Request.Builder()
                    .url("$host/streams/$videoId")
                    .header("User-Agent", WEB_UA)
                    .build()
                val json = http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) null
                    else resp.body?.string()?.let { JSONObject(it) }
                } ?: continue

                val out = mutableListOf<StreamChoice>()
                val hls = json.optString("hls")
                if (hls.startsWith("http")) {
                    out.add(StreamChoice("PIPED", "Auto HD", 1080, hls, null, isHls = true, userAgent = WEB_UA))
                }
                val audios = json.optJSONArray("audioStreams")
                var bestAudio: String? = null
                var bestBitrate = -1
                if (audios != null) {
                    for (i in 0 until audios.length()) {
                        val a = audios.optJSONObject(i) ?: continue
                        val u = a.optString("url")
                        val br = a.optInt("bitrate", 0)
                        if (u.startsWith("http") && br > bestBitrate) {
                            bestBitrate = br
                            bestAudio = u
                        }
                    }
                }
                val vids = json.optJSONArray("videoStreams")
                if (vids != null) {
                    val seenH = mutableSetOf<Int>()
                    for (i in 0 until vids.length()) {
                        val v = vids.optJSONObject(i) ?: continue
                        val u = v.optString("url")
                        if (!u.startsWith("http")) continue
                        val h = v.optInt("height", 0)
                        val videoOnly = v.optBoolean("videoOnly", true)
                        if (h in 240..1440 && !seenH.contains(h)) {
                            if (!videoOnly) {
                                seenH.add(h)
                                out.add(StreamChoice("PIPED", "${h}p", h, u, null, userAgent = WEB_UA))
                            } else if (bestAudio != null) {
                                seenH.add(h)
                                out.add(StreamChoice("PIPED", "${h}p", h, u, bestAudio, userAgent = WEB_UA))
                            }
                        }
                    }
                }
                val subs = json.optJSONArray("subtitles")
                if (subs != null) {
                    for (i in 0 until subs.length()) {
                        val s = subs.optJSONObject(i) ?: continue
                        val u = s.optString("url")
                        val code = s.optString("code").ifBlank { "sub_$i" }
                        val name = s.optString("name").ifBlank { code }
                        if (u.startsWith("http") && !captionsOut.containsKey(code)) {
                            captionsOut[code] = CaptionTrack(name, code, u)
                        }
                    }
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {
            }
        }

        val invHosts = listOf(
            "https://inv.nadeko.net",
            "https://yewtu.be"
        )
        for (host in invHosts) {
            try {
                val req = Request.Builder()
                    .url("$host/api/v1/videos/$videoId")
                    .header("User-Agent", WEB_UA)
                    .build()
                val json = http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) null
                    else resp.body?.string()?.let { JSONObject(it) }
                } ?: continue

                val out = mutableListOf<StreamChoice>()
                val fmts = json.optJSONArray("formatStreams")
                if (fmts != null) {
                    for (i in 0 until fmts.length()) {
                        val f = fmts.optJSONObject(i) ?: continue
                        val u = f.optString("url")
                        if (!u.startsWith("http")) continue
                        val qLabel = f.optString("qualityLabel").ifBlank { "360p" }
                        val h = qLabel.filter { it.isDigit() }.toIntOrNull() ?: 360
                        out.add(StreamChoice("INV", qLabel, h, u, null, userAgent = WEB_UA))
                    }
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }

    private fun extractStreamChoices(sd: JSONObject, tag: String, ua: String): List<StreamChoice> {
        val result = mutableListOf<StreamChoice>()

        val hlsUrl = sd.optString("hlsManifestUrl")
        if (hlsUrl.startsWith("http")) {
            result.add(
                StreamChoice(
                    clientTag = tag,
                    label = "Auto HD",
                    height = 1080,
                    videoUrl = hlsUrl,
                    audioUrl = null,
                    isHls = true,
                    userAgent = ua
                )
            )
        }

        val dashUrl = sd.optString("dashManifestUrl")
        if (dashUrl.startsWith("http") && hlsUrl.isBlank()) {
            result.add(
                StreamChoice(
                    clientTag = tag,
                    label = "Auto DASH",
                    height = 1080,
                    videoUrl = dashUrl,
                    audioUrl = null,
                    isDash = true,
                    userAgent = ua
                )
            )
        }

        val adaptive = sd.optJSONArray("adaptiveFormats")
        if (adaptive != null) {
            var bestAudioUrl: String? = null
            var bestAudioBitrate = -1

            data class RawVid(val height: Int, val url: String, val isAvc: Boolean, val bitrate: Int)
            val vids = mutableListOf<RawVid>()

            for (i in 0 until adaptive.length()) {
                val f = adaptive.optJSONObject(i) ?: continue
                val url = f.optString("url")
                if (!url.startsWith("http")) continue
                val mime = f.optString("mimeType").lowercase()
                val bitrate = f.optInt("bitrate", 0)
                if (mime.startsWith("audio/mp4")) {
                    if (bitrate > bestAudioBitrate) {
                        bestAudioBitrate = bitrate
                        bestAudioUrl = url
                    }
                } else if (mime.startsWith("audio/") && bestAudioUrl == null) {
                    bestAudioBitrate = bitrate
                    bestAudioUrl = url
                } else if (mime.startsWith("video/mp4") || mime.startsWith("video/webm")) {
                    val h = f.optInt("height", 0)
                    if (h in 144..1440) {
                        val isAvc = mime.contains("avc1")
                        vids.add(RawVid(h, url, isAvc, bitrate))
                    }
                }
            }

            if (bestAudioUrl != null && vids.isNotEmpty()) {
                val byHeight = vids.groupBy { it.height }
                    .mapValues { (_, list) ->
                        list.sortedWith(
                            compareByDescending<RawVid> { it.isAvc }.thenByDescending { it.bitrate }
                        ).first()
                    }
                val preferredHeights = listOf(1440, 1080, 720, 480, 360, 240).filter { byHeight.containsKey(it) }
                for (h in preferredHeights) {
                    val rv = byHeight[h] ?: continue
                    result.add(
                        StreamChoice(
                            clientTag = tag,
                            label = "${h}p",
                            height = h,
                            videoUrl = rv.url,
                            audioUrl = bestAudioUrl,
                            isHls = false,
                            userAgent = ua
                        )
                    )
                }
            }
        }

        val formats = sd.optJSONArray("formats")
        if (formats != null) {
            for (i in 0 until formats.length()) {
                val f = formats.optJSONObject(i) ?: continue
                val url = f.optString("url")
                if (!url.startsWith("http")) continue
                val h = f.optInt("height", 360)
                result.add(
                    StreamChoice(
                        clientTag = tag,
                        label = "${h}p (MP4)",
                        height = h,
                        videoUrl = url,
                        audioUrl = null,
                        isHls = false,
                        userAgent = ua
                    )
                )
            }
        }

        return result
    }

    private data class PlayerClientSpec(
        val tag: String,
        val userAgent: String,
        val clientNameHeader: String,
        val clientVersionHeader: String,
        val useOriginHeader: Boolean,
        val useAuth: Boolean,
        val isEmbed: Boolean = false,
        val clientJson: JSONObject
    )

    private fun browseVideos(browseId: String, gl: String, hl: String): List<VideoItem> {
        val body = webContextBody(gl, hl).put("browseId", browseId)
        val json = postInnerTube("browse", body) ?: return emptyList()
        val out = mutableListOf<VideoItem>()
        walkVideos(json, out)
        return out.distinctBy { it.id }
    }

    private fun webContextBody(gl: String, hl: String): JSONObject {
        return JSONObject().put(
            "context",
            JSONObject().put(
                "client",
                JSONObject()
                    .put("clientName", "WEB")
                    .put("clientVersion", WEB_VERSION)
                    .put("hl", hl)
                    .put("gl", gl)
                    .put("utcOffsetMinutes", 120)
            )
        )
    }

    private fun tvContextBody(gl: String, hl: String): JSONObject {
        return JSONObject().put(
            "context",
            JSONObject().put(
                "client",
                JSONObject()
                    .put("clientName", "TVHTML5")
                    .put("clientVersion", TV_VERSION)
                    .put("hl", hl)
                    .put("gl", gl)
                    .put("utcOffsetMinutes", 120)
            )
        )
    }

    private fun postInnerTube(endpoint: String, body: JSONObject): JSONObject? {
        return try {
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/$endpoint?prettyPrint=false")
                .header("User-Agent", WEB_UA)
                .header("Origin", "https://www.youtube.com")
                .header("Referer", "https://www.youtube.com/")
                .header("X-YouTube-Client-Name", "1")
                .header("X-YouTube-Client-Version", WEB_VERSION)
                .post(body.toString().toRequestBody(JSON_MEDIA))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val str = resp.body?.string() ?: return null
                JSONObject(str)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun postTvInnerTube(endpoint: String, body: JSONObject, accessToken: String): JSONObject? {
        return try {
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/$endpoint?prettyPrint=false")
                .header("User-Agent", TV_UA)
                .header("Authorization", "Bearer $accessToken")
                .header("Origin", "https://www.youtube.com")
                .header("X-YouTube-Client-Name", "7")
                .header("X-YouTube-Client-Version", TV_VERSION)
                .post(body.toString().toRequestBody(JSON_MEDIA))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val str = resp.body?.string() ?: return null
                JSONObject(str)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun walkVideos(node: Any?, out: MutableList<VideoItem>, depth: Int = 0) {
        if (node == null || depth > 45) return
        when (node) {
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    walkVideos(node.opt(i), out, depth + 1)
                }
            }
            is JSONObject -> {
                val vr = node.optJSONObject("videoRenderer")
                    ?: node.optJSONObject("gridVideoRenderer")
                    ?: node.optJSONObject("compactVideoRenderer")
                    ?: node.optJSONObject("playlistVideoRenderer")
                if (vr != null) {
                    parseVideoRenderer(vr)?.let { out.add(it) }
                    return
                }
                val lvm = node.optJSONObject("lockupViewModel")
                if (lvm != null) {
                    parseLockupViewModel(lvm)?.let { out.add(it) }
                    return
                }
                val tr = node.optJSONObject("tileRenderer")
                if (tr != null) {
                    parseTileRenderer(tr)?.let { out.add(it) }
                    return
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    walkVideos(node.opt(k), out, depth + 1)
                }
            }
        }
    }

    private fun parseTileRenderer(t: JSONObject): VideoItem? {
        val watchEp = t.optJSONObject("onSelectCommand")?.optJSONObject("watchEndpoint")
        val id = watchEp?.optString("videoId")?.takeIf { it.length == 11 }
            ?: t.optString("contentId").takeIf { it.length == 11 }
            ?: return null
        val ctype = t.optString("contentType")
        if (ctype.isNotBlank() && !ctype.contains("VIDEO", ignoreCase = true)) return null

        val md = t.optJSONObject("metadata")?.optJSONObject("tileMetadataRenderer")
        val title = extractText(md?.opt("title")).trim()
        if (title.isEmpty()) return null

        val lines = md?.optJSONArray("lines")
        val lineTexts = mutableListOf<String>()
        if (lines != null) {
            for (i in 0 until lines.length()) {
                val items = lines.optJSONObject(i)?.optJSONObject("lineRenderer")?.optJSONArray("items") ?: continue
                val parts = mutableListOf<String>()
                for (j in 0 until items.length()) {
                    val txt = extractText(items.optJSONObject(j)?.optJSONObject("lineItemRenderer")?.opt("text")).trim()
                    if (txt.isNotBlank()) parts.add(txt)
                }
                if (parts.isNotEmpty()) lineTexts.add(parts.joinToString(" · "))
            }
        }
        val channelName = lineTexts.getOrNull(0) ?: ""
        val meta = lineTexts.getOrNull(1) ?: ""

        val header = t.optJSONObject("header")?.optJSONObject("tileHeaderRenderer")
        val overlays = header?.optJSONArray("thumbnailOverlays")
        var dur = ""
        var progress = 0
        if (overlays != null) {
            for (i in 0 until overlays.length()) {
                val o = overlays.optJSONObject(i) ?: continue
                o.optJSONObject("thumbnailOverlayTimeStatusRenderer")?.let {
                    dur = extractText(it.opt("text"))
                }
                o.optJSONObject("thumbnailOverlayResumePlaybackRenderer")?.let {
                    progress = it.optInt("percentDurationWatched", 0)
                }
            }
        }

        val channelId = deepFindObject(t, "browseEndpoint")?.optString("browseId")
            ?.takeIf { it.startsWith("UC") } ?: ""

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            duration = dur,
            meta = meta,
            progressPercent = progress
        )
    }

    private fun parseVideoRenderer(v: JSONObject): VideoItem? {
        val id = v.optString("videoId")
        if (id.length != 11) return null
        if (v.has("upcomingEventData")) return null
        val nav = v.optJSONObject("navigationEndpoint")
        if (nav != null && nav.has("reelWatchEndpoint")) return null

        val title = extractText(v.opt("title")).trim()
        if (title.isEmpty()) return null

        val owner = v.optJSONObject("ownerText")
            ?: v.optJSONObject("shortBylineText")
            ?: v.optJSONObject("longBylineText")
        val channelName = extractText(owner).trim()
        val channelId = owner?.optJSONArray("runs")?.optJSONObject(0)
            ?.optJSONObject("navigationEndpoint")
            ?.optJSONObject("browseEndpoint")
            ?.optString("browseId") ?: ""

        val avatar = absUrl(
            deepFindThumbUrl(v.optJSONObject("channelThumbnailSupportedRenderers"), "thumbnails")
                .ifBlank { deepFindThumbUrl(v.optJSONObject("channelThumbnail"), "thumbnails") }
        )

        val views = extractText(v.opt("shortViewCountText")).ifBlank { extractText(v.opt("viewCountText")) }
        val pub = extractText(v.opt("publishedTimeText"))
        val meta = listOf(views, pub).filter { it.isNotBlank() }.joinToString(" · ")
        val dur = extractText(v.opt("lengthText"))

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = avatar,
            duration = dur,
            meta = meta
        )
    }

    private fun parseLockupViewModel(l: JSONObject): VideoItem? {
        val id = l.optString("contentId")
        if (id.length != 11) return null
        val ctype = l.optString("contentType")
        if (ctype.isNotBlank() && !ctype.contains("VIDEO", ignoreCase = true)) return null

        val md = l.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel") ?: return null
        val title = extractText(md.opt("title")).trim()
        if (title.isEmpty()) return null

        val rows = deepFindArray(md, "metadataRows")
        val parts = mutableListOf<List<String>>()
        if (rows != null) {
            for (i in 0 until rows.length()) {
                val r = rows.optJSONObject(i) ?: continue
                val mp = r.optJSONArray("metadataParts") ?: continue
                val rowTexts = mutableListOf<String>()
                for (j in 0 until mp.length()) {
                    val t = mp.optJSONObject(j)?.optJSONObject("text")?.optString("content")
                    if (!t.isNullOrBlank()) rowTexts.add(t)
                }
                if (rowTexts.isNotEmpty()) parts.add(rowTexts)
            }
        }

        val channelName = parts.getOrNull(0)?.firstOrNull() ?: ""
        val meta = parts.getOrNull(1)?.joinToString(" · ") ?: ""
        val channelId = deepFindObject(md.opt("image"), "browseEndpoint")?.optString("browseId") ?: ""
        val avatar = absUrl(deepFindArray(md.opt("image"), "sources")?.optJSONObject(0)?.optString("url") ?: "")

        val badges = mutableListOf<JSONObject>()
        collectObjectsByKey(l.opt("contentImage"), "thumbnailBadgeViewModel", badges)
        val dur = badges.mapNotNull { it.optString("text").takeIf { s -> DUR_REGEX.matches(s) } }.firstOrNull() ?: ""

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = avatar,
            duration = dur,
            meta = meta
        )
    }

    private fun extractText(node: Any?): String {
        if (node == null) return ""
        if (node is String) return node
        if (node !is JSONObject) return ""
        node.optString("simpleText").takeIf { it.isNotBlank() }?.let { return it }
        node.optString("content").takeIf { it.isNotBlank() }?.let { return it }
        val runs = node.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        }
        return sb.toString()
    }

    private fun deepFindObject(node: Any?, key: String, depth: Int = 0): JSONObject? {
        if (node == null || depth > 35) return null
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = deepFindObject(node.opt(keys.next()), key, depth + 1)
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = deepFindObject(node.opt(i), key, depth + 1)
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun deepFindArray(node: Any?, key: String, depth: Int = 0): JSONArray? {
        if (node == null || depth > 35) return null
        when (node) {
            is JSONObject -> {
                node.optJSONArray(key)?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = deepFindArray(node.opt(keys.next()), key, depth + 1)
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = deepFindArray(node.opt(i), key, depth + 1)
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun collectObjectsByKey(node: Any?, key: String, out: MutableList<JSONObject>, depth: Int = 0) {
        if (node == null || depth > 40) return
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { out.add(it) }
                val keys = node.keys()
                while (keys.hasNext()) {
                    collectObjectsByKey(node.opt(keys.next()), key, out, depth + 1)
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    collectObjectsByKey(node.opt(i), key, out, depth + 1)
                }
            }
        }
    }

    private fun deepFindThumbUrl(node: Any?, key: String): String {
        val target = if (key == "thumbnails") node else deepFindObject(node, key) ?: return ""
        val thumbs = deepFindArray(target, "thumbnails")
            ?: deepFindArray(target, "sources")
            ?: return ""
        return thumbs.lastThumbUrl()
    }

    private fun JSONArray.lastThumbUrl(): String {
        if (length() == 0) return ""
        return optJSONObject(length() - 1)?.optString("url") ?: ""
    }

    private fun extractSubscriberFromPageHeader(header: JSONObject?): String {
        val rows = deepFindArray(header, "metadataRows") ?: return ""
        for (i in 0 until rows.length()) {
            val mp = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
            for (j in 0 until mp.length()) {
                val txt = mp.optJSONObject(j)?.optJSONObject("text")?.optString("content") ?: ""
                if (txt.contains("sub", ignoreCase = true) || txt.contains("مشترك")) return txt
            }
        }
        return ""
    }

    private fun findLikeCount(primary: JSONObject?): String {
        if (primary == null) return ""
        val likeBtn = deepFindObject(primary, "likeButtonViewModel")
            ?: deepFindObject(primary, "segmentedLikeDislikeButtonViewModel")
        val title = deepFindObject(likeBtn, "buttonViewModel")?.optString("title") ?: ""
        return if (title.isNotBlank() && title != "Like") title else ""
    }

    private fun findCommentsContinuation(json: JSONObject): String? {
        val sections = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "itemSectionRenderer", sections)
        for (s in sections) {
            val id = s.optString("sectionIdentifier")
            val targetId = s.optString("targetId")
            if (id.contains("comment", ignoreCase = true) || targetId.contains("comment", ignoreCase = true)) {
                val token = deepFindObject(s, "continuationCommand")?.optString("token")
                if (!token.isNullOrBlank()) return token
            }
        }
        val ep = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "engagementPanelSectionListRenderer", ep)
        for (panel in ep) {
            if (panel.optString("panelIdentifier").contains("comment", ignoreCase = true)) {
                val token = deepFindObject(panel, "continuationCommand")?.optString("token")
                if (!token.isNullOrBlank()) return token
            }
        }
        return null
    }

    private fun absUrl(u: String): String {
        return when {
            u.isBlank() -> ""
            u.startsWith("//") -> "https:$u"
            else -> u
        }
    }

    private fun decodeXml(s: String): String = s
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
}
