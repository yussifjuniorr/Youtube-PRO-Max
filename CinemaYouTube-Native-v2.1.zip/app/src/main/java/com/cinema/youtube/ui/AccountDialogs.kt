package com.cinema.youtube.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Login
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cinema.youtube.data.GoogleAuthManager
import com.cinema.youtube.model.AppPrefs
import com.cinema.youtube.model.DeviceAuthSession
import com.cinema.youtube.model.GoogleAccount
import kotlinx.coroutines.delay

@Composable
fun AccountSheetDialog(
    account: GoogleAccount?,
    prefs: AppPrefs,
    onStartGoogleSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onSyncNow: () -> Unit,
    onUpdatePrefs: (AppPrefs) -> Unit,
    onDismiss: () -> Unit
) {
    val isAr = prefs.languageCode == "ar"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xFF151519),
            shape = RoundedCornerShape(26.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .fillMaxWidth()
                .widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "الحساب والإعدادات" else "Account & Settings",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = Color(0x1FFFFFFF),
                        shape = CircleShape,
                        modifier = Modifier
                            .size(34.dp)
                            .clickable(onClick = onDismiss)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Surface(
                    color = CinemaColors.SurfaceElevated,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (account != null) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                ChannelAvatar(
                                    url = account.avatarUrl,
                                    name = account.displayName.ifBlank { "G" },
                                    size = 52.dp
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = account.displayName.ifBlank { "Google Account" },
                                            color = Color.White,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Icon(
                                            Icons.Rounded.CheckCircle,
                                            contentDescription = null,
                                            tint = CinemaColors.AccentGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    if (account.email.isNotBlank()) {
                                        Text(
                                            text = account.email,
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = if (isAr) "متصل بحساب YouTube الخاص بك" else "Synced with your YouTube account",
                                        color = CinemaColors.AccentGreen,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = Color(0x24FFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            onSyncNow()
                                            onDismiss()
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Rounded.Sync, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "تحديث البيانات" else "Sync Now",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Surface(
                                    color = Color(0x28FF3B30),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable(onClick = onSignOut)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = Color(0xFFFF6B6B), modifier = Modifier.size(17.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "تسجيل خروج" else "Sign Out",
                                            color = Color(0xFFFF6B6B),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(Color(0x26FFFFFF))
                                ) {
                                    Icon(Icons.Rounded.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
                                }
                                Column {
                                    Text(
                                        text = if (isAr) "سجّل دخولك بحساب جوجل" else "Sign in with Google",
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isAr) "لمزامنة الاشتراكات، القوائم، السجل، واقتراحاتك الحقيقية"
                                        else "Sync your real Subscriptions, Playlists, History & For You feed",
                                        color = CinemaColors.TextSecondary,
                                        fontSize = 12.5.sp,
                                        lineHeight = 17.sp
                                    )
                                }
                            }

                            Button(
                                onClick = onStartGoogleSignIn,
                                shape = RoundedCornerShape(999.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Rounded.Login, contentDescription = null, modifier = Modifier.size(19.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = if (isAr) "تسجيل الدخول بحساب Google" else "Sign in with Google",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = Color(0x18FFFFFF))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.Tune, contentDescription = null, tint = CinemaColors.TextSecondary, modifier = Modifier.size(18.dp))
                    Text(
                        text = if (isAr) "إعدادات التطبيق" else "App Settings",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isAr) "الدولة / المحتوى" else "Content Region",
                        color = CinemaColors.TextSecondary,
                        fontSize = 12.5.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("EG" to "Egypt", "SA" to "Saudi", "US" to "Global").forEach { (code, label) ->
                            OptionChip(
                                label = label,
                                active = prefs.regionCode == code,
                                onClick = { onUpdatePrefs(prefs.copy(regionCode = code)) }
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isAr) "اللغة" else "Language",
                        color = CinemaColors.TextSecondary,
                        fontSize = 12.5.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("ar" to "العربية", "en" to "English").forEach { (code, label) ->
                            OptionChip(
                                label = label,
                                active = prefs.languageCode == code,
                                onClick = { onUpdatePrefs(prefs.copy(languageCode = code)) }
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isAr) "الجودة الافتراضية" else "Default Quality",
                        color = CinemaColors.TextSecondary,
                        fontSize = 12.5.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1080 to "1080p", 720 to "720p", 480 to "480p", 360 to "360p").forEach { (q, label) ->
                            OptionChip(
                                label = label,
                                active = prefs.preferredQuality == q,
                                onClick = { onUpdatePrefs(prefs.copy(preferredQuality = q)) }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isAr) "صورة داخل صورة تلقائياً (PiP)" else "Auto Picture-in-Picture",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isAr) "تصغير الفيديو عند الخروج للشاشة الرئيسية" else "Keep playing in floating window when leaving app",
                            color = CinemaColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = prefs.autoPip,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(autoPip = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Color.White
                        )
                    )
                }

                Text(
                    text = "Cinema YouTube Native v2.0 · Ad-Free Engine",
                    color = CinemaColors.TextSecondary,
                    fontSize = 11.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun OptionChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (active) Color.White else Color(0x1EFFFFFF),
        shape = RoundedCornerShape(999.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            color = if (active) Color.Black else Color.White,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp)
        )
    }
}

@Composable
fun GoogleDeviceSignInDialog(
    deviceId: String,
    isAr: Boolean,
    onSignedIn: (GoogleAccount) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var session by remember { mutableStateOf<DeviceAuthSession?>(null) }
    var loading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var retryNonce by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf("") }

    LaunchedEffect(retryNonce) {
        loading = true
        errorMsg = null
        session = null
        val res = GoogleAuthManager.startDeviceAuth(deviceId)
        loading = false
        res.onSuccess { s ->
            session = s
            statusText = if (isAr) "في انتظار موافقتك من المتصفح..." else "Waiting for approval in your browser..."
        }.onFailure { err ->
            errorMsg = err.message ?: if (isAr) "تعذّر بدء تسجيل الدخول" else "Unable to start sign-in"
        }
    }

    LaunchedEffect(session) {
        val activeSession = session ?: return@LaunchedEffect
        var intervalMs = (activeSession.intervalSec.coerceAtLeast(3)) * 1000L
        while (true) {
            delay(intervalMs)
            when (val poll = GoogleAuthManager.pollForToken(activeSession)) {
                is GoogleAuthManager.PollResult.Success -> {
                    onSignedIn(poll.account)
                    break
                }
                is GoogleAuthManager.PollResult.Pending -> {
                    if (poll.slowDown) intervalMs = (intervalMs + 2000L).coerceAtMost(12_000L)
                }
                is GoogleAuthManager.PollResult.Failed -> {
                    errorMsg = poll.message
                    session = null
                    break
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xFF151519),
            shape = RoundedCornerShape(26.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .fillMaxWidth()
                .widthIn(max = 430.dp)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "تسجيل الدخول بحساب جوجل" else "Sign in with Google",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = CinemaColors.TextSecondary,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onDismiss)
                            .padding(4.dp)
                    )
                }

                when {
                    loading -> {
                        Spacer(Modifier.height(10.dp))
                        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                        Text(
                            text = if (isAr) "جاري تجهيز كود التفعيل الآمن..." else "Generating secure sign-in code...",
                            color = CinemaColors.TextSecondary,
                            fontSize = 13.5.sp
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    errorMsg != null -> {
                        Text(
                            text = errorMsg ?: "",
                            color = Color(0xFFFF7B7B),
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { retryNonce++ },
                            shape = RoundedCornerShape(999.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isAr) "إعادة المحاولة" else "Try Again", fontWeight = FontWeight.Bold)
                        }
                    }

                    session != null -> {
                        val s = session!!
                        Text(
                            text = if (isAr)
                                "لتفادي حظر المتصفح الداخلي، سجّل دخولك بأمان من متصفح الموبايل بالكود ده:"
                            else
                                "Sign in safely through your phone's browser using this activation code:",
                            color = CinemaColors.TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 19.sp
                        )

                        Surface(
                            color = Color(0xFF0D0D10),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.5.dp, Color(0x40FFFFFF)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { copyToClipboard(context, s.userCode, isAr) }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 18.dp, horizontal = 12.dp)
                            ) {
                                Text(
                                    text = s.userCode,
                                    color = Color.White,
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 3.sp
                                )
                                Spacer(Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = CinemaColors.TextSecondary, modifier = Modifier.size(14.dp))
                                    Text(
                                        text = if (isAr) "اضغط لنسخ الكود" else "Tap to copy code",
                                        color = CinemaColors.TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = {
                                copyToClipboard(context, s.userCode, isAr)
                                runCatching {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(s.verificationUrl))
                                    context.startActivity(intent)
                                }
                            },
                            shape = RoundedCornerShape(999.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Rounded.OpenInBrowser, contentDescription = null, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (isAr) "نسخ الكود وفتح google.com/device" else "Copy Code & Open Google Sign-In",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            CircularProgressIndicator(color = CinemaColors.TextSecondary, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                            Text(
                                text = statusText,
                                color = CinemaColors.TextSecondary,
                                fontSize = 12.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String, isAr: Boolean) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    cm?.setPrimaryClip(ClipData.newPlainText("YouTube Code", text))
    Toast.makeText(
        context,
        if (isAr) "تم نسخ الكود: $text" else "Code copied: $text",
        Toast.LENGTH_SHORT
    ).show()
}
