package com.cinema.youtube

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.cinema.youtube.data.GoogleAuthManager
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.data.LocalStore
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.HistoryEntry
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoItem
import com.cinema.youtube.ui.AccountSheetDialog
import com.cinema.youtube.ui.AdaptiveTopNavigation
import com.cinema.youtube.ui.ChannelScreen
import com.cinema.youtube.ui.CinemaColors
import com.cinema.youtube.ui.CinemaTheme
import com.cinema.youtube.ui.GoogleDeviceSignInDialog
import com.cinema.youtube.ui.HistoryScreen
import com.cinema.youtube.ui.HomeScreen
import com.cinema.youtube.ui.MobileFloatingBottomNav
import com.cinema.youtube.ui.PlaylistsScreen
import com.cinema.youtube.ui.SearchResultsScreen
import com.cinema.youtube.ui.SubscriptionsScreen
import com.cinema.youtube.ui.TopTab
import com.cinema.youtube.ui.WatchScreen
import com.cinema.youtube.ui.rememberIsTablet
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var store: LocalStore
    private var isInPipState by mutableStateOf(false)
    private var isWatchingNow = false
    private var autoPipEnabled = true

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipState = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isWatchingNow && autoPipEnabled) {
            enterCinemaPip()
        }
    }

    private fun enterCinemaPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runCatching {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.parseColor("#050505"))
        )
        store = LocalStore(applicationContext)

        setContent {
            CinemaTheme {
                val scope = rememberCoroutineScope()
                val isTablet = rememberIsTablet()
                val config = LocalConfiguration.current
                val isPhysicalLandscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE

                var appPrefs by remember { mutableStateOf(store.getAppPrefs()) }
                var googleAccount by remember { mutableStateOf(store.getGoogleAccount()) }
                var activeAccessToken by remember { mutableStateOf<String?>(googleAccount?.accessToken) }

                var localSubscriptions by remember { mutableStateOf(store.getSubscriptions()) }
                var remoteSubscriptions by remember { mutableStateOf<List<SubscribedChannel>>(emptyList()) }
                var localPlaylists by remember { mutableStateOf(store.getPlaylists()) }
                var remotePlaylists by remember { mutableStateOf<List<UserPlaylist>>(emptyList()) }
                var remotePlaylistVideos by remember { mutableStateOf<Map<String, List<VideoItem>>>(emptyMap()) }
                var loadingRemotePlaylistId by remember { mutableStateOf<String?>(null) }

                var localHistory by remember { mutableStateOf(store.getHistory()) }
                var remoteHistory by remember { mutableStateOf<List<HistoryEntry>>(emptyList()) }
                var likedIds by remember { mutableStateOf(store.getLikedIds()) }
                var recentSearches by remember { mutableStateOf(store.getRecentSearches()) }

                var activeTab by remember { mutableStateOf(TopTab.HOME) }
                var isSearching by remember { mutableStateOf(false) }
                var searchText by remember { mutableStateOf("") }
                var activeSearchQuery by remember { mutableStateOf<String?>(null) }
                var searchResults by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var searchLoading by remember { mutableStateOf(false) }

                var heroVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var homeShelves by remember { mutableStateOf<List<HomeShelf>>(emptyList()) }
                var subFeedVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var homeLoading by remember { mutableStateOf(true) }
                var syncNonce by remember { mutableIntStateOf(0) }

                var activeChannelId by remember { mutableStateOf<String?>(null) }
                var activeChannelInfo by remember { mutableStateOf<ChannelInfo?>(null) }
                var channelLoading by remember { mutableStateOf(false) }

                var watchingVideo by remember { mutableStateOf<VideoItem?>(null) }
                var manualLandscape by remember { mutableStateOf(false) }
                var showAccountDialog by remember { mutableStateOf(false) }
                var showGoogleSignInDialog by remember { mutableStateOf(false) }

                val effectiveLandscape = watchingVideo != null && (manualLandscape || isPhysicalLandscape)

                LaunchedEffect(watchingVideo, appPrefs.autoPip) {
                    isWatchingNow = watchingVideo != null
                    autoPipEnabled = appPrefs.autoPip
                }

                fun setImmersive(enabled: Boolean) {
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    if (enabled) {
                        controller.systemBarsBehavior =
                            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        controller.hide(WindowInsetsCompat.Type.systemBars())
                    } else {
                        controller.show(WindowInsetsCompat.Type.systemBars())
                    }
                }

                LaunchedEffect(effectiveLandscape, isInPipState) {
                    setImmersive(effectiveLandscape && !isInPipState)
                }

                fun updateLandscape(landscape: Boolean) {
                    manualLandscape = landscape
                    requestedOrientation = if (landscape) {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }
                }

                LaunchedEffect(appPrefs.regionCode, appPrefs.languageCode, googleAccount?.refreshToken, syncNonce) {
                    homeLoading = true
                    val token = if (googleAccount != null) {
                        GoogleAuthManager.getValidAccessToken(store).also { fresh ->
                            activeAccessToken = fresh
                            googleAccount = store.getGoogleAccount()
                        }
                    } else {
                        activeAccessToken = null
                        null
                    }

                    val (hero, shelves) = InnerTubeClient.fetchHomeShelves(
                        gl = appPrefs.regionCode,
                        hl = appPrefs.languageCode,
                        subscriptions = localSubscriptions,
                        accessToken = token
                    )
                    heroVideos = hero
                    homeShelves = shelves
                    homeLoading = false

                    if (!token.isNullOrBlank()) {
                        launch {
                            val (rSubs, rSubVids) = InnerTubeClient.fetchAuthSubscriptions(
                                token, appPrefs.regionCode, appPrefs.languageCode
                            )
                            remoteSubscriptions = rSubs
                            if (rSubVids.isNotEmpty()) {
                                subFeedVideos = rSubVids
                            }
                        }
                        launch {
                            remotePlaylists = InnerTubeClient.fetchAuthPlaylists(
                                token, appPrefs.regionCode, appPrefs.languageCode
                            )
                        }
                        launch {
                            val histVids = InnerTubeClient.fetchAuthHistory(
                                token, appPrefs.regionCode, appPrefs.languageCode
                            )
                            val now = System.currentTimeMillis()
                            remoteHistory = histVids.mapIndexed { idx, v ->
                                HistoryEntry(v, 0L, 0L, now - idx * 1000L)
                            }
                        }
                    } else {
                        remoteSubscriptions = emptyList()
                        remotePlaylists = emptyList()
                        remoteHistory = emptyList()
                        subFeedVideos = InnerTubeClient.fetchSubscriptionFeed(localSubscriptions)
                    }
                }

                LaunchedEffect(localSubscriptions, activeAccessToken) {
                    if (activeAccessToken.isNullOrBlank()) {
                        subFeedVideos = InnerTubeClient.fetchSubscriptionFeed(localSubscriptions)
                    }
                }

                LaunchedEffect(activeChannelId) {
                    val cid = activeChannelId ?: return@LaunchedEffect
                    channelLoading = true
                    activeChannelInfo = null
                    activeChannelInfo = InnerTubeClient.fetchChannel(cid, appPrefs.regionCode, appPrefs.languageCode)
                    channelLoading = false
                }

                BackHandler(
                    enabled = watchingVideo != null ||
                        activeChannelId != null ||
                        activeSearchQuery != null ||
                        isSearching ||
                        activeTab != TopTab.HOME
                ) {
                    when {
                        watchingVideo != null && manualLandscape -> {
                            updateLandscape(false)
                        }
                        watchingVideo != null -> {
                            updateLandscape(false)
                            watchingVideo = null
                        }
                        activeChannelId != null -> {
                            activeChannelId = null
                        }
                        isSearching -> {
                            isSearching = false
                            searchText = ""
                        }
                        activeSearchQuery != null -> {
                            activeSearchQuery = null
                            searchResults = emptyList()
                        }
                        activeTab != TopTab.HOME -> {
                            activeTab = TopTab.HOME
                        }
                    }
                }

                val mergedSubscriptions = remember(remoteSubscriptions, localSubscriptions) {
                    (remoteSubscriptions + localSubscriptions).distinctBy { it.id }
                }
                val mergedPlaylists = remember(remotePlaylists, localPlaylists) {
                    remotePlaylists + localPlaylists
                }
                val mergedHistory = remember(localHistory, remoteHistory) {
                    (localHistory + remoteHistory).distinctBy { it.video.id }
                }
                val continueWatching = remember(mergedHistory) {
                    mergedHistory
                        .filter { it.progressPercent in 3..94 }
                        .map { it.video.copy(progressPercent = it.progressPercent) }
                        .take(15)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(CinemaColors.BgBlack)
                ) {
                    val currentWatch = watchingVideo
                    val currentChannel = activeChannelId

                    when {
                        currentWatch != null -> {
                            WatchScreen(
                                video = currentWatch,
                                initialPositionMs = store.getSavedPosition(currentWatch.id),
                                gl = appPrefs.regionCode,
                                hl = appPrefs.languageCode,
                                preferredQuality = appPrefs.preferredQuality,
                                accessToken = activeAccessToken,
                                isTablet = isTablet,
                                isLandscape = effectiveLandscape,
                                isInPipMode = isInPipState,
                                isLiked = likedIds.contains(currentWatch.id),
                                isSubscribed = { cid -> mergedSubscriptions.any { it.id == cid } },
                                playlists = mergedPlaylists,
                                onToggleLike = { vidId ->
                                    val nowLiked = !likedIds.contains(vidId)
                                    likedIds = store.toggleLikedId(vidId)
                                    val token = activeAccessToken
                                    if (!token.isNullOrBlank()) {
                                        scope.launch { InnerTubeClient.syncLikeVideo(vidId, nowLiked, token) }
                                    }
                                },
                                onToggleLandscape = { updateLandscape(!effectiveLandscape) },
                                onEnterPip = { enterCinemaPip() },
                                onBack = {
                                    updateLandscape(false)
                                    watchingVideo = null
                                },
                                onOpenVideo = { nextVid -> watchingVideo = nextVid },
                                onOpenChannel = { cid ->
                                    updateLandscape(false)
                                    watchingVideo = null
                                    activeChannelId = cid
                                },
                                onToggleSubscribe = { ch ->
                                    val willSub = mergedSubscriptions.none { it.id == ch.id }
                                    localSubscriptions = store.toggleSubscription(ch)
                                    val token = activeAccessToken
                                    if (!token.isNullOrBlank()) {
                                        scope.launch { InnerTubeClient.syncSubscribeChannel(ch.id, willSub, token) }
                                    }
                                },
                                onToggleVideoInPlaylist = { plId, v ->
                                    localPlaylists = store.toggleVideoInPlaylist(plId, v)
                                },
                                onSaveProgress = { v, pos, dur ->
                                    localHistory = store.saveHistoryEntry(v, pos, dur)
                                }
                            )
                        }

                        currentChannel != null -> {
                            ChannelScreen(
                                isTablet = isTablet,
                                channel = activeChannelInfo,
                                isLoading = channelLoading,
                                isSubscribed = mergedSubscriptions.any { it.id == currentChannel },
                                onBack = { activeChannelId = null },
                                onToggleSubscribe = { ch ->
                                    val willSub = mergedSubscriptions.none { it.id == ch.id }
                                    localSubscriptions = store.toggleSubscription(ch)
                                    val token = activeAccessToken
                                    if (!token.isNullOrBlank()) {
                                        scope.launch { InnerTubeClient.syncSubscribeChannel(ch.id, willSub, token) }
                                    }
                                },
                                onPlayVideo = { vid -> watchingVideo = vid }
                            )
                        }

                        activeSearchQuery != null -> {
                            SearchResultsScreen(
                                isTablet = isTablet,
                                query = activeSearchQuery ?: "",
                                results = searchResults,
                                isLoading = searchLoading,
                                onPlayVideo = { vid -> watchingVideo = vid }
                            )
                        }

                        else -> {
                            when (activeTab) {
                                TopTab.HOME -> HomeScreen(
                                    isTablet = isTablet,
                                    heroVideos = heroVideos,
                                    shelves = homeShelves,
                                    continueWatching = continueWatching,
                                    isLoading = homeLoading,
                                    onRefresh = { syncNonce++ },
                                    onPlayVideo = { vid -> watchingVideo = vid },
                                    onOpenChannel = { cid -> activeChannelId = cid }
                                )

                                TopTab.SUBSCRIPTIONS -> SubscriptionsScreen(
                                    isTablet = isTablet,
                                    subscriptions = mergedSubscriptions,
                                    subVideos = subFeedVideos,
                                    onOpenChannel = { cid -> activeChannelId = cid },
                                    onPlayVideo = { vid -> watchingVideo = vid }
                                )

                                TopTab.PLAYLISTS -> PlaylistsScreen(
                                    isTablet = isTablet,
                                    playlists = mergedPlaylists,
                                    remotePlaylistVideos = remotePlaylistVideos,
                                    loadingRemotePlaylistId = loadingRemotePlaylistId,
                                    onLoadRemotePlaylist = { plId ->
                                        scope.launch {
                                            loadingRemotePlaylistId = plId
                                            val vids = InnerTubeClient.fetchRemotePlaylistVideos(
                                                plId, activeAccessToken, appPrefs.regionCode, appPrefs.languageCode
                                            )
                                            remotePlaylistVideos = remotePlaylistVideos + (plId to vids)
                                            loadingRemotePlaylistId = null
                                        }
                                    },
                                    onCreatePlaylist = { name -> localPlaylists = store.createPlaylist(name) },
                                    onDeletePlaylist = { id -> localPlaylists = store.deletePlaylist(id) },
                                    onPlayVideo = { vid -> watchingVideo = vid }
                                )

                                TopTab.HISTORY -> HistoryScreen(
                                    isTablet = isTablet,
                                    history = mergedHistory,
                                    onPlayVideo = { vid -> watchingVideo = vid },
                                    onClearHistory = {
                                        store.clearHistory()
                                        localHistory = emptyList()
                                    }
                                )
                            }
                        }
                    }

                    if (watchingVideo == null && activeChannelId == null) {
                        AdaptiveTopNavigation(
                            isTablet = isTablet,
                            account = googleAccount,
                            activeTab = activeTab,
                            isSearching = isSearching,
                            searchText = searchText,
                            recentSearches = recentSearches,
                            hl = appPrefs.languageCode,
                            onTabSelected = { tab ->
                                activeSearchQuery = null
                                activeTab = tab
                            },
                            onSearchModeChange = { isSearching = it },
                            onSearchTextChange = { searchText = it },
                            onSubmitSearch = { q ->
                                val cleaned = q.trim()
                                if (cleaned.isNotEmpty()) {
                                    isSearching = false
                                    activeSearchQuery = cleaned
                                    recentSearches = store.addRecentSearch(cleaned)
                                    scope.launch {
                                        searchLoading = true
                                        searchResults = InnerTubeClient.searchVideos(
                                            cleaned,
                                            appPrefs.regionCode,
                                            appPrefs.languageCode
                                        )
                                        searchLoading = false
                                    }
                                }
                            },
                            onClearRecentSearches = {
                                store.clearRecentSearches()
                                recentSearches = emptyList()
                            },
                            onOpenAccount = { showAccountDialog = true }
                        )

                        if (!isTablet && !isSearching) {
                            MobileFloatingBottomNav(
                                activeTab = activeTab,
                                onTabSelected = { tab ->
                                    activeSearchQuery = null
                                    activeTab = tab
                                },
                                modifier = Modifier.align(Alignment.BottomCenter)
                            )
                        }
                    }

                    if (showAccountDialog) {
                        AccountSheetDialog(
                            account = googleAccount,
                            prefs = appPrefs,
                            onStartGoogleSignIn = {
                                showAccountDialog = false
                                showGoogleSignInDialog = true
                            },
                            onSignOut = {
                                store.saveGoogleAccount(null)
                                googleAccount = null
                                activeAccessToken = null
                                remoteSubscriptions = emptyList()
                                remotePlaylists = emptyList()
                                remotePlaylistVideos = emptyMap()
                                remoteHistory = emptyList()
                                syncNonce++
                            },
                            onSyncNow = { syncNonce++ },
                            onUpdatePrefs = { updated ->
                                appPrefs = updated
                                store.saveAppPrefs(updated)
                            },
                            onDismiss = { showAccountDialog = false }
                        )
                    }

                    if (showGoogleSignInDialog) {
                        GoogleDeviceSignInDialog(
                            deviceId = store.getOrCreateDeviceId(),
                            isAr = appPrefs.languageCode == "ar",
                            onSignedIn = { newAcc ->
                                store.saveGoogleAccount(newAcc)
                                googleAccount = newAcc
                                activeAccessToken = newAcc.accessToken
                                showGoogleSignInDialog = false
                                syncNonce++
                            },
                            onDismiss = { showGoogleSignInDialog = false }
                        )
                    }
                }
            }
        }
    }
}
