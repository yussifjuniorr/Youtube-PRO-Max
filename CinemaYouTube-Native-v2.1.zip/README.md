# Cinema YouTube Native (v2.0)

100% Native Android app built with **Kotlin + Jetpack Compose + Media3 ExoPlayer**:
- **Fixed Ad-Free Multi-Engine Stream Resolver:** Updated InnerTube clients (`ANDROID_VR`, authenticated `TVHTML5`, `IOS`, `ANDROID`, `WEB_EMBEDDED_PLAYER`) with fresh `visitorData` + Piped/Invidious fallback + WebVTT Captions.
- **Pro Adaptive Video Player:** YouTube-style pinned 16:9 portrait player with scrollable channel/actions/comments/Up Next feed below, and full Cinema Landscape/Tablet mode with floating glass HUD & side drawers. Includes double-tap ±10s seek with animation, swipe gestures for volume & brightness, hold-for-2x speed, quality/speed/CC/zoom controls, and Picture-in-Picture (PiP).
- **Real Google Account Sign-In:** Secure TV/Device Code OAuth (`google.com/device`) that syncs your real Home feed, Subscriptions, Playlists, and Watch History without WebView security errors.
- **True Adaptive Mobile vs. Tablet UI:** Floating bottom nav & clean header on phones (`< 600dp`), full Cinema top pill nav & multi-column grids on tablets/landscape (`>= 600dp`).
