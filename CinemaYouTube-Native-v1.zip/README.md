# Cinema YouTube Native (v1.0)

A 100% Native Android app built with **Kotlin + Jetpack Compose + Media3 ExoPlayer**, featuring:
- Exact Cinema Style dark glass UI (Hero Carousel, Floating Pill Nav, Horizontal Shelves, Full-Screen Watch HUD with Details / Comments / Up next drawers)
- Ad-free native HD playback via Media3 ExoPlayer with multi-client InnerTube resolution & automatic fallback
- Local Subscriptions (live channel feeds), Playlists, Watch History, Continue Watching progress, and instant YouTube search suggestions
- Properly signed Release APK (`CinemaYouTube-Release.apk`) built automatically by GitHub Actions
