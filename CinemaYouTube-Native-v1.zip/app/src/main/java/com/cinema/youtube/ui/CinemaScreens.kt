package com.cinema.youtube.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.AppPrefs
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.HistoryEntry
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay

enum class TopTab { HOME, SUBSCRIPTIONS, PLAYLISTS, HISTORY }

// ---------- Shared Avatar ----------
@Composable
fun ChannelAvatar(url: String, name: String, size: Dp) {
    if (url.isNotBlank()) {
        AsyncImage(
            model = url,
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x28FFFFFF))
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
        )
    } else {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0x2EFFFFFF))
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
        ) {
            Text(
                text = name.trim().firstOrNull()?.uppercase() ?: "Y",
                color = Color.White,
                fontSize = (size.value * 0.44f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ---------- Floating Cinema Style Pill Navigation Bar ----------
@Composable
fun FloatingCinemaNav(
    activeTab: TopTab,
    isSearching: Boolean,
    searchText: String,
    recentSearches: List<String>,
    hl: String,
    onTabSelected: (TopTab) -> Unit,
    onSearchModeChange: (Boolean) -> Unit,
    onSearchTextChange: (String) -> Unit,
    onSubmitSearch: (String) -> Unit,
    onClearRecentSearches: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(isSearching, searchText) {
        if (!isSearching || searchText.isBlank()) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(140)
        suggestions = InnerTubeClient.fetchSuggestions(searchText, hl)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(top = 10.dp, start = 8.dp, end = 8.dp)
    ) {
        Surface(
            color = CinemaColors.GlassFill,
            shape = RoundedCornerShape(999.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            shadowElevation = 12.dp
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 4.dp)
            ) {
                // Red YouTube Pill Logo (Home)
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(if (activeTab == TopTab.HOME && !isSearching) Color(0x24FFFFFF) else Color.Transparent)
                        .clickable {
                            onSearchModeChange(false)
                            onTabSelected(TopTab.HOME)
                        }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .width(30.dp)
                            .height(21.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(CinemaColors.YtRed)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Home",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                if (isSearching) {
                    BasicTextField(
                        value = searchText,
                        onValueChange = onSearchTextChange,
                        singleLine = true,
                        modifier = Modifier.widthIn(min = 160.dp, max = 250.dp),
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Color.White),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onSubmitSearch(searchText) }),
                        decorationBox = { inner ->
                            Box(
                                contentAlignment = Alignment.CenterStart,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Color(0x18FFFFFF))
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                if (searchText.isEmpty()) {
                                    Text("Search YouTube", color = CinemaColors.TextSecondary, fontSize = 14.sp)
                                }
                                inner()
                            }
                        }
                    )
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Go",
                        tint = Color.White,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .clickable { onSubmitSearch(searchText) }
                            .padding(7.dp)
                    )
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close Search",
                        tint = CinemaColors.TextSecondary,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .clickable {
                                onSearchTextChange("")
                                onSearchModeChange(false)
                            }
                            .padding(7.dp)
                    )
                } else {
                    NavPillItem("Subscriptions", activeTab == TopTab.SUBSCRIPTIONS) { onTabSelected(TopTab.SUBSCRIPTIONS) }
                    NavPillItem("Playlists", activeTab == TopTab.PLAYLISTS) { onTabSelected(TopTab.PLAYLISTS) }
                    NavPillItem("History", activeTab == TopTab.HISTORY) { onTabSelected(TopTab.HISTORY) }

                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .clickable { onSearchModeChange(true) }
                            .padding(7.dp)
                    )

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0x28FFFFFF))
                            .clickable(onClick = onOpenSettings)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = "Account & Settings",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Suggestions / Recent Searches Glass Dropdown
        if (isSearching) {
            val showItems = if (searchText.isBlank()) recentSearches.take(7) else suggestions
            if (showItems.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 460.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (searchText.isBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Recent searches", color = CinemaColors.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Clear",
                                    color = CinemaColors.TextSecondary,
                                    fontSize = 12.sp,
                                    modifier = Modifier.clickable(onClick = onClearRecentSearches)
                                )
                            }
                        }
                        showItems.forEach { s ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSubmitSearch(s) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Icon(
                                    imageVector = if (searchText.isBlank()) Icons.Rounded.History else Icons.Rounded.Search,
                                    contentDescription = null,
                                    tint = CinemaColors.TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = s,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavPillItem(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (active) CinemaColors.PillActiveBg else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (active) CinemaColors.PillActiveText else Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

// ---------- HOME SCREEN (Hero Banner + Horizontal Cinema Shelves) ----------
@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    heroVideos: List<VideoItem>,
    shelves: List<HomeShelf>,
    continueWatching: List<VideoItem>,
    isLoading: Boolean,
    onRefresh: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    if (isLoading && heroVideos.isEmpty() && shelves.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                Text("Loading Cinema YouTube…", color = CinemaColors.TextSecondary, fontSize = 14.sp)
            }
        }
        return
    }

    if (!isLoading && heroVideos.isEmpty() && shelves.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تعذّر تحميل الصفحة الرئيسية", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onRefresh)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة المحاولة", color = Color.Black, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(bottom = 48.dp)
    ) {
        if (heroVideos.isNotEmpty()) {
            item(key = "hero") {
                HeroCarousel(
                    videos = heroVideos,
                    onPlayVideo = onPlayVideo,
                    onOpenChannel = onOpenChannel
                )
            }
        } else {
            item { Spacer(Modifier.height(86.dp)) }
        }

        if (continueWatching.isNotEmpty()) {
            item(key = "continue_watching") {
                CinemaShelf(
                    title = "Continue watching",
                    videos = continueWatching,
                    onPlayVideo = onPlayVideo
                )
            }
        }

        items(shelves, key = { it.title }) { shelf ->
            CinemaShelf(
                title = shelf.title,
                videos = shelf.videos,
                onPlayVideo = onPlayVideo
            )
        }
    }
}

@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HeroCarousel(
    videos: List<VideoItem>,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { videos.size })

    LaunchedEffect(videos.size) {
        if (videos.size > 1) {
            while (true) {
                delay(8500)
                val next = (pagerState.currentPage + 1) % videos.size
                pagerState.animateScrollToPage(next)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(500.dp)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = videos[page]
            var useFallbackThumb by remember(item.id) { mutableStateOf(false) }

            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = if (useFallbackThumb) item.thumbnailUrl else item.heroThumbnailUrl,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    onError = { useFallbackThumb = true },
                    modifier = Modifier.fillMaxSize()
                )

                // Cinematic Vignette Scrims (matching Cinema Style screenshots)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colorStops = arrayOf(
                                    0.0f to Color(0x88050505),
                                    0.25f to Color(0x22050505),
                                    0.58f to Color(0xA6050505),
                                    1.0f to CinemaColors.BgBlack
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, bottom = 46.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Channel Avatar + Name
                    if (item.channelName.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.clickable {
                                if (item.channelId.isNotBlank()) onOpenChannel(item.channelId)
                            }
                        ) {
                            ChannelAvatar(url = item.channelAvatar, name = item.channelName, size = 34.dp)
                            Text(
                                text = item.channelName,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Bold Hero Title
                    Text(
                        text = item.title,
                        color = Color.White,
                        fontSize = 27.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 32.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    // Duration Badge + Meta
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (item.duration.isNotBlank()) {
                            Text(
                                text = item.duration,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        if (item.meta.isNotBlank()) {
                            Text(
                                text = item.meta,
                                color = CinemaColors.TextSecondary,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(Modifier.height(2.dp))

                    // Play + View Channel Buttons (Exact Cinema Style Pills)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            color = Color(0xFFF5F5F7),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { onPlayVideo(item) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Play", color = Color.Black, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (item.channelId.isNotBlank()) {
                            Surface(
                                color = CinemaColors.GlassFill,
                                shape = RoundedCornerShape(999.dp),
                                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                                modifier = Modifier.clickable { onOpenChannel(item.channelId) }
                            ) {
                                Text(
                                    text = "View channel",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom-Right Glass Dots Indicator
        if (videos.size > 1) {
            Surface(
                color = CinemaColors.GlassFill,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    repeat(videos.size) { i ->
                        val active = i == pagerState.currentPage
                        Box(
                            modifier = Modifier
                                .height(6.dp)
                                .width(if (active) 18.dp else 6.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(if (active) Color.White else Color(0x55FFFFFF))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CinemaShelf(
    title: String,
    videos: List<VideoItem>,
    onPlayVideo: (VideoItem) -> Unit
) {
    Column(modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(videos, key = { "${title}_${it.id}" }) { item ->
                CinemaVideoCard(item = item, width = 236.dp, onClick = { onPlayVideo(item) })
            }
        }
    }
}

@Composable
fun CinemaVideoCard(
    item: VideoItem,
    width: Dp? = null,
    onClick: () -> Unit
) {
    val cardMod = if (width != null) Modifier.width(width) else Modifier.fillMaxWidth()
    Column(
        modifier = cardMod.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp))
                .background(CinemaColors.SurfaceDark)
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(14.dp))
        ) {
            AsyncImage(
                model = item.thumbnailUrl,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (item.duration.isNotBlank()) {
                Text(
                    text = item.duration,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 8.dp, bottom = if (item.progressPercent > 0) 16.dp else 8.dp)
                        .background(Color(0xBA000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            if (item.progressPercent > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .height(3.5.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0x4DFFFFFF))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((item.progressPercent / 100f).coerceIn(0f, 1f))
                            .background(Color.White)
                    )
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        Text(
            text = item.title,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 18.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (item.channelName.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = item.channelName,
                color = CinemaColors.TextSecondary,
                fontSize = 12.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---------- SUBSCRIPTIONS SCREEN ----------
@Composable
fun SubscriptionsScreen(
    subscriptions: List<SubscribedChannel>,
    subVideos: List<VideoItem>,
    onOpenChannel: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 86.dp, bottom = 48.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Subscriptions", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }

        if (subscriptions.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "No subscribed channels yet",
                    subtitle = "Open any video or channel and tap Subscribe — their latest videos will appear right here and on your Home screen."
                )
            }
        } else {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(subscriptions, key = { it.id }) { ch ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(72.dp)
                                .clickable { onOpenChannel(ch.id) }
                        ) {
                            ChannelAvatar(url = ch.avatarUrl, name = ch.name, size = 56.dp)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = ch.name,
                                color = Color.White,
                                fontSize = 11.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
            items(subVideos, key = { "sub_${it.id}" }) { vid ->
                CinemaVideoCard(item = vid, onClick = { onPlayVideo(vid) })
            }
        }
    }
}

// ---------- PLAYLISTS SCREEN ----------
@Composable
fun PlaylistsScreen(
    playlists: List<UserPlaylist>,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    val selected = playlists.firstOrNull { it.id == selectedPlaylistId }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 86.dp, bottom = 48.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (selected != null) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable { selectedPlaylistId = null }
                            .padding(4.dp)
                    )
                    Text(selected.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (selected.videos.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "Playlist is empty",
                        subtitle = "Open any video → tap Details → Save to Playlist."
                    )
                }
            } else {
                items(selected.videos, key = { "${selected.id}_${it.id}" }) { vid ->
                    CinemaVideoCard(item = vid, onClick = { onPlayVideo(vid) })
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Playlists", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier.clickable { showCreateDialog = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("New", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            items(playlists, key = { it.id }) { pl ->
                Surface(
                    color = CinemaColors.SurfaceDark,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPlaylistId = pl.id }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(96.dp)
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x1AFFFFFF)),
                                contentAlignment = Alignment.Center
                            ) {
                                val firstThumb = pl.videos.firstOrNull()?.thumbnailUrl
                                if (firstThumb != null) {
                                    AsyncImage(
                                        model = firstThumb,
                                        contentDescription = pl.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = CinemaColors.TextSecondary)
                                }
                            }
                            Column {
                                Text(pl.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Text("${pl.videos.size} videos", color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
                            }
                        }
                        if (pl.id != "watch_later" && pl.id != "favorites") {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Delete",
                                tint = CinemaColors.TextSecondary,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .clickable { onDeletePlaylist(pl.id) }
                                    .padding(4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = Color(0xFF1C1C20),
            title = { Text("New Playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Playlist name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) onCreatePlaylist(newName)
                    newName = ""
                    showCreateDialog = false
                }) { Text("Create", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel", color = CinemaColors.TextSecondary) }
            }
        )
    }
}

// ---------- HISTORY SCREEN ----------
@Composable
fun HistoryScreen(
    history: List<HistoryEntry>,
    onPlayVideo: (VideoItem) -> Unit,
    onClearHistory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 86.dp, bottom = 48.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("History", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) {
                    Text(
                        text = "Clear all",
                        color = Color(0xFFFF6B6B),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable(onClick = onClearHistory)
                    )
                }
            }
        }
        if (history.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "No watch history yet",
                    subtitle = "Videos you watch will appear here with automatic resume progress."
                )
            }
        } else {
            items(history, key = { "hist_${it.video.id}_${it.watchedAt}" }) { entry ->
                CinemaVideoCard(
                    item = entry.video.copy(progressPercent = entry.progressPercent),
                    onClick = { onPlayVideo(entry.video) }
                )
            }
        }
    }
}

// ---------- SEARCH RESULTS SCREEN ----------
@Composable
fun SearchResultsScreen(
    query: String,
    results: List<VideoItem>,
    isLoading: Boolean,
    onPlayVideo: (VideoItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(top = 86.dp, bottom = 48.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text(
                text = "Results for \"$query\"",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                }
            }
        } else if (results.isEmpty()) {
            item {
                EmptyStateCard(title = "No results found", subtitle = "Try a different search query.")
            }
        } else {
            items(results, key = { "sr_${it.id}" }) { item ->
                CinemaVideoCard(item = item, onClick = { onPlayVideo(item) })
            }
        }
    }
}

// ---------- CHANNEL SCREEN ----------
@Composable
fun ChannelScreen(
    channel: ChannelInfo?,
    isLoading: Boolean,
    isSubscribed: Boolean,
    onBack: () -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onPlayVideo: (VideoItem) -> Unit
) {
    if (isLoading && channel == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
        }
        return
    }
    if (channel == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CinemaColors.BgBlack),
            contentAlignment = Alignment.Center
        ) {
            Text("Channel unavailable", color = CinemaColors.TextSecondary)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack),
        contentPadding = PaddingValues(bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(CinemaColors.SurfaceDark)
            ) {
                if (channel.bannerUrl.isNotBlank()) {
                    AsyncImage(
                        model = channel.bannerUrl,
                        contentDescription = channel.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(listOf(Color(0x66000000), CinemaColors.BgBlack))
                        )
                )
                Surface(
                    color = CinemaColors.GlassFill,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(14.dp)
                        .size(42.dp)
                        .clickable(onClick = onBack)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ChannelAvatar(url = channel.avatarUrl, name = channel.name, size = 56.dp)
                    Column {
                        Text(channel.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        if (channel.subscriberCount.isNotBlank()) {
                            Text(channel.subscriberCount, color = CinemaColors.TextSecondary, fontSize = 13.sp)
                        }
                    }
                }
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable {
                        onToggleSubscribe(SubscribedChannel(channel.id, channel.name, channel.avatarUrl))
                    }
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }

        items(channel.videos, key = { "ch_${it.id}" }) { vid ->
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                CinemaVideoCard(item = vid, onClick = { onPlayVideo(vid) })
            }
        }
    }
}

// ---------- SETTINGS / ACCOUNT DIALOG ----------
@Composable
fun SettingsDialog(
    prefs: AppPrefs,
    onUpdatePrefs: (AppPrefs) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1A1A1E),
        title = {
            Text("Cinema YouTube Settings", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Content Region", color = CinemaColors.TextSecondary, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("EG" to "Egypt", "SA" to "Saudi", "US" to "Global").forEach { (code, label) ->
                        val active = prefs.regionCode == code
                        Surface(
                            color = if (active) Color.White else Color(0x1FFFFFFF),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { onUpdatePrefs(prefs.copy(regionCode = code)) }
                        ) {
                            Text(
                                text = label,
                                color = if (active) Color.Black else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Text("Language", color = CinemaColors.TextSecondary, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ar" to "العربية", "en" to "English").forEach { (code, label) ->
                        val active = prefs.languageCode == code
                        Surface(
                            color = if (active) Color.White else Color(0x1FFFFFFF),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.clickable { onUpdatePrefs(prefs.copy(languageCode = code)) }
                        ) {
                            Text(
                                text = label,
                                color = if (active) Color.Black else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Surface(
                    color = Color(0x14FFFFFF),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Native Release v1.0 · Ad-Free ExoPlayer\nSubscriptions, Playlists & History are saved locally on your phone.",
                        color = CinemaColors.TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done", color = Color.White) }
        }
    )
}

@Composable
private fun EmptyStateCard(title: String, subtitle: String) {
    Surface(
        color = CinemaColors.SurfaceDark,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = CinemaColors.TextSecondary, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}
