package com.cinema.youtube.data

import android.content.Context
import com.cinema.youtube.model.AppPrefs
import com.cinema.youtube.model.HistoryEntry
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoItem
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {

    private val prefs = context.getSharedPreferences("cinema_native_store", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_HISTORY = "history_v1"
        private const val KEY_SUBS = "subs_v1"
        private const val KEY_PLAYLISTS = "playlists_v1"
        private const val KEY_SEARCHES = "searches_v1"
        private const val KEY_REGION = "region_code"
        private const val KEY_LANG = "lang_code"
    }

    fun getAppPrefs(): AppPrefs {
        return AppPrefs(
            regionCode = prefs.getString(KEY_REGION, "EG") ?: "EG",
            languageCode = prefs.getString(KEY_LANG, "ar") ?: "ar"
        )
    }

    fun saveAppPrefs(appPrefs: AppPrefs) {
        prefs.edit()
            .putString(KEY_REGION, appPrefs.regionCode)
            .putString(KEY_LANG, appPrefs.languageCode)
            .apply()
    }

    // ---------- History & Continue Watching ----------
    fun getHistory(): List<HistoryEntry> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<HistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    HistoryEntry(
                        video = videoFromJson(o.getJSONObject("video")),
                        positionMs = o.optLong("positionMs", 0L),
                        durationMs = o.optLong("durationMs", 0L),
                        watchedAt = o.optLong("watchedAt", 0L)
                    )
                )
            }
            list.sortedByDescending { it.watchedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getSavedPosition(videoId: String): Long {
        val entry = getHistory().firstOrNull { it.video.id == videoId } ?: return 0L
        return if (entry.durationMs > 0 && entry.positionMs < entry.durationMs - 10_000L) {
            entry.positionMs
        } else 0L
    }

    fun saveHistoryEntry(video: VideoItem, positionMs: Long, durationMs: Long): List<HistoryEntry> {
        val current = getHistory().filterNot { it.video.id == video.id }.toMutableList()
        val pct = if (durationMs > 1000L) ((positionMs * 100L) / durationMs).toInt().coerceIn(0, 100) else 0
        val updated = HistoryEntry(
            video = video.copy(progressPercent = pct),
            positionMs = positionMs,
            durationMs = durationMs,
            watchedAt = System.currentTimeMillis()
        )
        current.add(0, updated)
        val trimmed = current.take(120)
        val arr = JSONArray()
        for (h in trimmed) {
            arr.put(
                JSONObject()
                    .put("video", videoToJson(h.video))
                    .put("positionMs", h.positionMs)
                    .put("durationMs", h.durationMs)
                    .put("watchedAt", h.watchedAt)
            )
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
        return trimmed
    }

    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    // ---------- Subscriptions ----------
    fun getSubscriptions(): List<SubscribedChannel> {
        val raw = prefs.getString(KEY_SUBS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<SubscribedChannel>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    SubscribedChannel(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        avatarUrl = o.optString("avatarUrl")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun toggleSubscription(channel: SubscribedChannel): List<SubscribedChannel> {
        val current = getSubscriptions().toMutableList()
        val exists = current.any { it.id == channel.id }
        if (exists) {
            current.removeAll { it.id == channel.id }
        } else if (channel.id.isNotBlank()) {
            current.add(0, channel)
        }
        val arr = JSONArray()
        for (c in current) {
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("avatarUrl", c.avatarUrl)
            )
        }
        prefs.edit().putString(KEY_SUBS, arr.toString()).apply()
        return current
    }

    // ---------- Playlists ----------
    fun getPlaylists(): List<UserPlaylist> {
        val raw = prefs.getString(KEY_PLAYLISTS, null)
        if (raw == null) {
            val defaults = listOf(
                UserPlaylist("watch_later", "Watch Later", emptyList()),
                UserPlaylist("favorites", "Favorites", emptyList())
            )
            savePlaylists(defaults)
            return defaults
        }
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<UserPlaylist>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val vidsArr = o.optJSONArray("videos") ?: JSONArray()
                val vids = mutableListOf<VideoItem>()
                for (j in 0 until vidsArr.length()) {
                    vids.add(videoFromJson(vidsArr.getJSONObject(j)))
                }
                list.add(
                    UserPlaylist(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        videos = vids
                    )
                )
            }
            list
        } catch (_: Exception) {
            listOf(UserPlaylist("watch_later", "Watch Later", emptyList()))
        }
    }

    private fun savePlaylists(list: List<UserPlaylist>) {
        val arr = JSONArray()
        for (p in list) {
            val vids = JSONArray()
            for (v in p.videos) vids.put(videoToJson(v))
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("videos", vids)
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    fun createPlaylist(name: String): List<UserPlaylist> {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return getPlaylists()
        val current = getPlaylists().toMutableList()
        current.add(UserPlaylist(id = "pl_${System.currentTimeMillis()}", name = trimmed, videos = emptyList()))
        savePlaylists(current)
        return current
    }

    fun deletePlaylist(playlistId: String): List<UserPlaylist> {
        val current = getPlaylists().filterNot { it.id == playlistId }
        savePlaylists(current)
        return current
    }

    fun toggleVideoInPlaylist(playlistId: String, video: VideoItem): List<UserPlaylist> {
        val updated = getPlaylists().map { pl ->
            if (pl.id == playlistId) {
                val exists = pl.videos.any { it.id == video.id }
                val newVids = if (exists) {
                    pl.videos.filterNot { it.id == video.id }
                } else {
                    listOf(video) + pl.videos
                }
                pl.copy(videos = newVids)
            } else pl
        }
        savePlaylists(updated)
        return updated
    }

    // ---------- Recent Searches ----------
    fun getRecentSearches(): List<String> {
        val raw = prefs.getString(KEY_SEARCHES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addRecentSearch(query: String): List<String> {
        val q = query.trim()
        if (q.isEmpty()) return getRecentSearches()
        val list = (listOf(q) + getRecentSearches().filterNot { it.equals(q, ignoreCase = true) }).take(20)
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString(KEY_SEARCHES, arr.toString()).apply()
        return list
    }

    fun clearRecentSearches() {
        prefs.edit().remove(KEY_SEARCHES).apply()
    }

    private fun videoToJson(v: VideoItem): JSONObject = JSONObject()
        .put("id", v.id)
        .put("title", v.title)
        .put("channelName", v.channelName)
        .put("channelId", v.channelId)
        .put("channelAvatar", v.channelAvatar)
        .put("duration", v.duration)
        .put("meta", v.meta)
        .put("progressPercent", v.progressPercent)
        .put("thumbnailUrl", v.thumbnailUrl)
        .put("heroThumbnailUrl", v.heroThumbnailUrl)

    private fun videoFromJson(o: JSONObject): VideoItem {
        val id = o.optString("id")
        return VideoItem(
            id = id,
            title = o.optString("title"),
            channelName = o.optString("channelName"),
            channelId = o.optString("channelId"),
            channelAvatar = o.optString("channelAvatar"),
            duration = o.optString("duration"),
            meta = o.optString("meta"),
            progressPercent = o.optInt("progressPercent", 0),
            thumbnailUrl = o.optString("thumbnailUrl").ifBlank { "https://i.ytimg.com/vi/$id/hqdefault.jpg" },
            heroThumbnailUrl = o.optString("heroThumbnailUrl").ifBlank { "https://i.ytimg.com/vi/$id/maxresdefault.jpg" }
        )
    }
}
