package com.cinema.youtube.data

import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.ResolvedStreams
import com.cinema.youtube.model.StreamChoice
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object InnerTubeClient {

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private val DUR_REGEX = Regex("^\\d{1,2}(:\\d{2}){1,2}$")

    private const val WEB_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private const val WEB_VERSION = "2.20250501.00.00"

    private const val VR_UA =
        "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    private const val IOS_UA =
        "com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)"
    private const val ANDROID_UA =
        "com.google.android.youtube/19.29.37 (Linux; U; Android 14) gzip"

    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // ---------- Public API ----------

    suspend fun fetchHomeShelves(
        gl: String,
        hl: String,
        subscriptions: List<SubscribedChannel>
    ): Pair<List<VideoItem>, List<HomeShelf>> = withContext(Dispatchers.IO) {
        coroutineScope {
            val subsDeferred = async { fetchSubscriptionFeed(subscriptions) }
            val browseHomeDeferred = async { browseVideos("FEwhat_to_watch", gl, hl) }
            val trendingDeferred = async { browseVideos("FEtrending", gl, hl) }
            val musicDeferred = async {
                browseVideos("UC-9-kyTW8ZkZNDHQJ6FgpwQ", gl, hl)
            }
            val gamingDeferred = async {
                browseVideos("UCOpNcN46UbXVtpKMrmU4Abg", gl, hl)
            }

            val subVideos = subsDeferred.await()
            val homeVideos = browseHomeDeferred.await()
            val trendingVideos = trendingDeferred.await()
            val musicVideos = musicDeferred.await()
            val gamingVideos = gamingDeferred.await()

            var forYou = if (homeVideos.size >= 6) homeVideos else trendingVideos
            if (forYou.size < 6) {
                val fallbackQuery = if (gl == "EG" || hl == "ar") "بودكاست مصر 2026" else "trending podcasts documentary"
                forYou = searchVideos(fallbackQuery, gl, hl)
            }

            val shelves = mutableListOf<HomeShelf>()
            if (subVideos.isNotEmpty()) {
                shelves.add(HomeShelf("New videos", subVideos.take(24)))
            }
            if (forYou.isNotEmpty()) {
                shelves.add(HomeShelf("For you", forYou.take(18)))
            }
            if (trendingVideos.isNotEmpty() && trendingVideos != forYou) {
                shelves.add(HomeShelf("Trending now", trendingVideos.take(18)))
            }
            if (gamingVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Gaming", gamingVideos.take(16)))
            }
            if (musicVideos.isNotEmpty()) {
                shelves.add(HomeShelf("Music", musicVideos.take(16)))
            }

            // Extra curated shelves when cookieless YouTube returns few tabs
            if (shelves.size < 3) {
                val extraQueries = if (hl == "ar") {
                    listOf("أفلام وثائقية" to "Documentaries", "ملخص مباريات" to "Football & Sports", "بودكاست عربي" to "Podcasts")
                } else {
                    listOf("documentary cinema" to "Documentaries", "football highlights" to "Sports", "tech reviews" to "Tech")
                }
                val extraResults = extraQueries.map { (q, title) ->
                    async { title to searchVideos(q, gl, hl).take(14) }
                }.awaitAll()
                for ((title, vids) in extraResults) {
                    if (vids.isNotEmpty()) shelves.add(HomeShelf(title, vids))
                }
            }

            val heroPool = (if (subVideos.isNotEmpty()) subVideos else forYou)
                .distinctBy { it.id }
                .take(6)

            Pair(heroPool, shelves)
        }
    }

    suspend fun fetchSubscriptionFeed(subscriptions: List<SubscribedChannel>): List<VideoItem> =
        withContext(Dispatchers.IO) {
            if (subscriptions.isEmpty()) return@withContext emptyList()
            coroutineScope {
                subscriptions.take(15).map { ch ->
                    async { fetchChannelRss(ch) }
                }.awaitAll()
                    .flatten()
                    .distinctBy { it.id }
            }
        }

    private fun fetchChannelRss(channel: SubscribedChannel): List<VideoItem> {
        if (!channel.id.startsWith("UC")) return emptyList()
        return try {
            val req = Request.Builder()
                .url("https://www.youtube.com/feeds/videos.xml?channel_id=${channel.id}")
                .header("User-Agent", WEB_UA)
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val xml = resp.body?.string() ?: return emptyList()
                val out = mutableListOf<VideoItem>()
                val entryRegex = Regex("<entry>([\\s\\S]*?)</entry>")
                val vidRegex = Regex("<yt:videoId>([^<]+)</yt:videoId>")
                val titleRegex = Regex("<title>([\\s\\S]*?)</title>")
                val pubRegex = Regex("<published>([^<]+)</published>")
                for (m in entryRegex.findAll(xml)) {
                    val block = m.groupValues[1]
                    val id = vidRegex.find(block)?.groupValues?.get(1)?.trim() ?: continue
                    val rawTitle = titleRegex.find(block)?.groupValues?.get(1)?.trim() ?: continue
                    val pub = pubRegex.find(block)?.groupValues?.get(1)?.take(10) ?: ""
                    out.add(
                        VideoItem(
                            id = id,
                            title = decodeXml(rawTitle),
                            channelName = channel.name,
                            channelId = channel.id,
                            channelAvatar = channel.avatarUrl,
                            meta = pub
                        )
                    )
                }
                out.take(8)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun searchVideos(query: String, gl: String, hl: String): List<VideoItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isEmpty()) return@withContext emptyList()
            val body = webContextBody(gl, hl).put("query", q)
            val json = postInnerTube("search", body) ?: return@withContext emptyList()
            val out = mutableListOf<VideoItem>()
            walkVideos(json, out)
            out.distinctBy { it.id }
        }

    suspend fun fetchSuggestions(query: String, hl: String): List<String> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isEmpty()) return@withContext emptyList()
            try {
                val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&oe=utf-8" +
                    "&hl=${URLEncoder.encode(hl, "UTF-8")}&q=${URLEncoder.encode(q, "UTF-8")}"
                val req = Request.Builder().url(url).header("User-Agent", WEB_UA).build()
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    val text = resp.body?.string() ?: return@withContext emptyList()
                    val arr = JSONArray(text)
                    if (arr.length() < 2) return@withContext emptyList()
                    val items = arr.getJSONArray(1)
                    (0 until items.length()).mapNotNull { items.optString(it).takeIf { s -> s.isNotBlank() } }.take(8)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    suspend fun fetchChannel(channelId: String, gl: String, hl: String): ChannelInfo? =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl)
                .put("browseId", channelId)
                .put("params", "EgZ2aWRlb3PyBgQKAjoA") // Videos tab
            val json = postInnerTube("browse", body) ?: return@withContext null

            val videos = mutableListOf<VideoItem>()
            walkVideos(json, videos)

            val meta = json.optJSONObject("metadata")?.optJSONObject("channelMetadataRenderer")
            val header = json.optJSONObject("header")

            val name = meta?.optString("title")?.takeIf { it.isNotBlank() }
                ?: extractText(deepFindObject(header, "title"))
                .ifBlank { videos.firstOrNull()?.channelName ?: "Channel" }

            val avatarUrl = absUrl(
                meta?.optJSONObject("avatar")?.optJSONArray("thumbnails")?.lastThumbUrl()
                    ?: deepFindThumbUrl(header, "avatar")
            )
            val bannerUrl = absUrl(
                deepFindThumbUrl(header, "banner")
                    .ifBlank { deepFindThumbUrl(header, "imageBannerViewModel") }
            )
            val subCount = extractText(deepFindObject(header, "subscriberCountText"))
                .ifBlank { extractSubscriberFromPageHeader(header) }
            val desc = meta?.optString("description") ?: ""

            val normalizedVideos = videos.distinctBy { it.id }.map {
                it.copy(
                    channelName = it.channelName.ifBlank { name },
                    channelId = it.channelId.ifBlank { channelId },
                    channelAvatar = it.channelAvatar.ifBlank { avatarUrl }
                )
            }

            ChannelInfo(
                id = channelId,
                name = name,
                avatarUrl = avatarUrl,
                bannerUrl = bannerUrl,
                subscriberCount = subCount,
                description = desc,
                videos = normalizedVideos
            )
        }

    suspend fun fetchWatchDetails(videoId: String, gl: String, hl: String): VideoDetails? =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl).put("videoId", videoId)
            val json = postInnerTube("next", body) ?: return@withContext null

            val primary = deepFindObject(json, "videoPrimaryInfoRenderer")
            val secondary = deepFindObject(json, "videoSecondaryInfoRenderer")
            val owner = secondary?.optJSONObject("owner")?.optJSONObject("videoOwnerRenderer")

            val title = extractText(primary?.opt("title"))
            val viewCount = extractText(
                primary?.optJSONObject("viewCount")?.optJSONObject("videoViewCountRenderer")?.opt("viewCount")
            ).ifBlank {
                extractText(primary?.optJSONObject("viewCount")?.optJSONObject("videoViewCountRenderer")?.opt("shortViewCount"))
            }
            val publishDate = extractText(primary?.opt("dateText"))
                .ifBlank { extractText(primary?.opt("relativeDateText")) }

            val channelName = extractText(owner?.opt("title"))
            val channelId = owner?.optJSONObject("navigationEndpoint")
                ?.optJSONObject("browseEndpoint")
                ?.optString("browseId") ?: ""
            val channelAvatar = absUrl(
                owner?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
            )
            val subCount = extractText(owner?.opt("subscriberCountText"))

            val description = extractText(secondary?.opt("attributedDescription"))
                .ifBlank { extractText(secondary?.opt("description")) }

            val likeText = findLikeCount(primary)

            val secondaryResults = deepFindObject(json, "secondaryResults")
            val related = mutableListOf<VideoItem>()
            if (secondaryResults != null) {
                walkVideos(secondaryResults, related)
            }

            val commentsToken = findCommentsContinuation(json)

            VideoDetails(
                videoId = videoId,
                title = title,
                channelName = channelName,
                channelId = channelId,
                channelAvatar = channelAvatar,
                viewCount = viewCount,
                publishDate = publishDate,
                description = description,
                likeCount = likeText,
                subscriberCount = subCount,
                relatedVideos = related.distinctBy { it.id }.filterNot { it.id == videoId }.take(25),
                commentsContinuation = commentsToken
            )
        }

    suspend fun fetchComments(continuation: String, gl: String, hl: String): List<CommentItem> =
        withContext(Dispatchers.IO) {
            val body = webContextBody(gl, hl).put("continuation", continuation)
            val json = postInnerTube("next", body) ?: return@withContext emptyList()
            val out = mutableListOf<CommentItem>()

            // New YouTube comments format: entityBatchUpdate -> mutations -> payload -> commentEntityPayload
            val payloads = mutableListOf<JSONObject>()
            collectObjectsByKey(json, "commentEntityPayload", payloads)
            for (p in payloads) {
                val props = p.optJSONObject("properties") ?: continue
                val authorObj = p.optJSONObject("author")
                val toolbar = p.optJSONObject("toolbar")
                val text = props.optJSONObject("content")?.optString("content") ?: continue
                if (text.isBlank()) continue
                out.add(
                    CommentItem(
                        author = authorObj?.optString("displayName")?.ifBlank { "User" } ?: "User",
                        avatarUrl = absUrl(authorObj?.optString("avatarThumbnailUrl") ?: ""),
                        text = text,
                        publishedTime = props.optString("publishedTime"),
                        likeCount = toolbar?.optString("likeCountNotliked") ?: ""
                    )
                )
            }

            // Legacy YouTube comments format fallback: commentRenderer
            if (out.isEmpty()) {
                val renderers = mutableListOf<JSONObject>()
                collectObjectsByKey(json, "commentRenderer", renderers)
                for (r in renderers) {
                    val text = extractText(r.opt("contentText"))
                    if (text.isBlank()) continue
                    out.add(
                        CommentItem(
                            author = extractText(r.opt("authorText")).ifBlank { "User" },
                            avatarUrl = absUrl(
                                r.optJSONObject("authorThumbnail")?.optJSONArray("thumbnails")?.lastThumbUrl() ?: ""
                            ),
                            text = text,
                            publishedTime = extractText(r.opt("publishedTimeText")),
                            likeCount = extractText(r.opt("voteCount"))
                        )
                    )
                }
            }
            out.take(40)
        }

    // ---------- Multi-Client Ad-Free Stream Resolver ----------

    suspend fun resolveStreams(videoId: String): ResolvedStreams = withContext(Dispatchers.IO) {
        val allChoices = mutableListOf<StreamChoice>()
        var title = ""
        var channelName = ""
        var channelId = ""
        var durationSec = 0L
        var lastError: String? = null

        val clients = listOf(
            PlayerClientSpec(
                tag = "VR",
                userAgent = VR_UA,
                clientNameHeader = "28",
                clientVersionHeader = "1.60.19",
                clientJson = JSONObject()
                    .put("clientName", "ANDROID_VR")
                    .put("clientVersion", "1.60.19")
                    .put("deviceMake", "Oculus")
                    .put("deviceModel", "Quest 3")
                    .put("osName", "Android")
                    .put("osVersion", "12L")
                    .put("androidSdkVersion", 32)
                    .put("hl", "en")
                    .put("gl", "US")
            ),
            PlayerClientSpec(
                tag = "IOS",
                userAgent = IOS_UA,
                clientNameHeader = "5",
                clientVersionHeader = "19.45.4",
                clientJson = JSONObject()
                    .put("clientName", "IOS")
                    .put("clientVersion", "19.45.4")
                    .put("deviceMake", "Apple")
                    .put("deviceModel", "iPhone16,2")
                    .put("osName", "iPhone")
                    .put("osVersion", "18.1.0.22B83")
                    .put("hl", "en")
                    .put("gl", "US")
            ),
            PlayerClientSpec(
                tag = "ANDROID",
                userAgent = ANDROID_UA,
                clientNameHeader = "3",
                clientVersionHeader = "19.29.37",
                clientJson = JSONObject()
                    .put("clientName", "ANDROID")
                    .put("clientVersion", "19.29.37")
                    .put("androidSdkVersion", 34)
                    .put("hl", "en")
                    .put("gl", "US")
            ),
            PlayerClientSpec(
                tag = "TV_EMBED",
                userAgent = WEB_UA,
                clientNameHeader = "85",
                clientVersionHeader = "2.0",
                clientJson = JSONObject()
                    .put("clientName", "TVHTML5_SIMPLY_EMBEDDED_PLAYER")
                    .put("clientVersion", "2.0")
                    .put("hl", "en")
                    .put("gl", "US")
            )
        )

        for (spec in clients) {
            try {
                val payload = JSONObject()
                    .put("videoId", videoId)
                    .put("contentCheckOk", true)
                    .put("racyCheckOk", true)
                    .put("context", JSONObject().put("client", spec.clientJson))

                val req = Request.Builder()
                    .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                    .header("User-Agent", spec.userAgent)
                    .header("X-YouTube-Client-Name", spec.clientNameHeader)
                    .header("X-YouTube-Client-Version", spec.clientVersionHeader)
                    .header("Origin", "https://www.youtube.com")
                    .post(payload.toString().toRequestBody(JSON_MEDIA))
                    .build()

                val json = http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        lastError = "HTTP ${resp.code}"
                        null
                    } else {
                        val txt = resp.body?.string()
                        if (txt.isNullOrBlank()) null else JSONObject(txt)
                    }
                } ?: continue

                val status = json.optJSONObject("playabilityStatus")?.optString("status") ?: ""
                if (status != "OK") {
                    val reason = json.optJSONObject("playabilityStatus")?.optString("reason")
                    if (!reason.isNullOrBlank()) lastError = reason
                    continue
                }

                val vd = json.optJSONObject("videoDetails")
                if (vd != null && title.isBlank()) {
                    title = vd.optString("title")
                    channelName = vd.optString("author")
                    channelId = vd.optString("channelId")
                    durationSec = vd.optString("lengthSeconds").toLongOrNull() ?: 0L
                }

                val sd = json.optJSONObject("streamingData") ?: continue
                val extracted = extractStreamChoices(sd, spec.tag, spec.userAgent)
                if (extracted.isNotEmpty()) {
                    allChoices.addAll(extracted)
                    // Once we have good streams from at least 2 clients (primary + backup), stop early for speed
                    if (allChoices.map { it.clientTag }.distinct().size >= 2) break
                }
            } catch (e: Exception) {
                lastError = e.message
            }
        }

        ResolvedStreams(
            choices = allChoices,
            title = title,
            channelName = channelName,
            channelId = channelId,
            durationSec = durationSec,
            errorMessage = if (allChoices.isEmpty()) (lastError ?: "No playable streams found") else null
        )
    }

    private fun extractStreamChoices(sd: JSONObject, tag: String, ua: String): List<StreamChoice> {
        val result = mutableListOf<StreamChoice>()

        // 1. HLS Manifest (great on iOS client — adaptive quality + zero audio sync issues)
        val hlsUrl = sd.optString("hlsManifestUrl")
        if (hlsUrl.startsWith("http")) {
            result.add(
                StreamChoice(
                    clientTag = tag,
                    label = "Auto HD",
                    height = 1080,
                    videoUrl = hlsUrl,
                    audioUrl = null,
                    isHls = true,
                    userAgent = ua
                )
            )
        }

        // 2. Adaptive Video + Best Audio (HD 1080p / 720p / 480p / 360p)
        val adaptive = sd.optJSONArray("adaptiveFormats")
        if (adaptive != null) {
            var bestAudioUrl: String? = null
            var bestAudioBitrate = -1

            data class RawVid(val height: Int, val url: String, val isAvc: Boolean, val bitrate: Int)
            val vids = mutableListOf<RawVid>()

            for (i in 0 until adaptive.length()) {
                val f = adaptive.optJSONObject(i) ?: continue
                val url = f.optString("url")
                if (!url.startsWith("http")) continue
                val mime = f.optString("mimeType").lowercase()
                val bitrate = f.optInt("bitrate", 0)
                if (mime.startsWith("audio/mp4")) {
                    if (bitrate > bestAudioBitrate) {
                        bestAudioBitrate = bitrate
                        bestAudioUrl = url
                    }
                } else if (mime.startsWith("audio/") && bestAudioUrl == null) {
                    bestAudioBitrate = bitrate
                    bestAudioUrl = url
                } else if (mime.startsWith("video/mp4") || mime.startsWith("video/webm")) {
                    val h = f.optInt("height", 0)
                    if (h in 240..1440) {
                        val isAvc = mime.contains("avc1")
                        vids.add(RawVid(h, url, isAvc, bitrate))
                    }
                }
            }

            if (bestAudioUrl != null && vids.isNotEmpty()) {
                val byHeight = vids.groupBy { it.height }
                    .mapValues { (_, list) ->
                        list.sortedWith(
                            compareByDescending<RawVid> { it.isAvc }.thenByDescending { it.bitrate }
                        ).first()
                    }
                val preferredHeights = listOf(1080, 720, 480, 360).filter { byHeight.containsKey(it) }
                for (h in preferredHeights) {
                    val rv = byHeight[h] ?: continue
                    result.add(
                        StreamChoice(
                            clientTag = tag,
                            label = "${h}p",
                            height = h,
                            videoUrl = rv.url,
                            audioUrl = bestAudioUrl,
                            isHls = false,
                            userAgent = ua
                        )
                    )
                }
            }
        }

        // 3. Progressive Muxed MP4 fallback
        val formats = sd.optJSONArray("formats")
        if (formats != null) {
            for (i in 0 until formats.length()) {
                val f = formats.optJSONObject(i) ?: continue
                val url = f.optString("url")
                if (!url.startsWith("http")) continue
                val h = f.optInt("height", 360)
                result.add(
                    StreamChoice(
                        clientTag = tag,
                        label = "${h}p (MP4)",
                        height = h,
                        videoUrl = url,
                        audioUrl = null,
                        isHls = false,
                        userAgent = ua
                    )
                )
            }
        }

        return result
    }

    private data class PlayerClientSpec(
        val tag: String,
        val userAgent: String,
        val clientNameHeader: String,
        val clientVersionHeader: String,
        val clientJson: JSONObject
    )

    // ---------- Internal InnerTube helpers ----------

    private fun browseVideos(browseId: String, gl: String, hl: String): List<VideoItem> {
        val body = webContextBody(gl, hl).put("browseId", browseId)
        val json = postInnerTube("browse", body) ?: return emptyList()
        val out = mutableListOf<VideoItem>()
        walkVideos(json, out)
        return out.distinctBy { it.id }
    }

    private fun webContextBody(gl: String, hl: String): JSONObject {
        return JSONObject().put(
            "context",
            JSONObject().put(
                "client",
                JSONObject()
                    .put("clientName", "WEB")
                    .put("clientVersion", WEB_VERSION)
                    .put("hl", hl)
                    .put("gl", gl)
                    .put("utcOffsetMinutes", 120)
            )
        )
    }

    private fun postInnerTube(endpoint: String, body: JSONObject): JSONObject? {
        return try {
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/$endpoint?prettyPrint=false")
                .header("User-Agent", WEB_UA)
                .header("Origin", "https://www.youtube.com")
                .header("Referer", "https://www.youtube.com/")
                .header("X-YouTube-Client-Name", "1")
                .header("X-YouTube-Client-Version", WEB_VERSION)
                .post(body.toString().toRequestBody(JSON_MEDIA))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val str = resp.body?.string() ?: return null
                JSONObject(str)
            }
        } catch (_: Exception) {
            null
        }
    }

    // ---------- Recursive JSON Video Parser (supports videoRenderer + compactVideoRenderer + lockupViewModel) ----------

    private fun walkVideos(node: Any?, out: MutableList<VideoItem>, depth: Int = 0) {
        if (node == null || depth > 45) return
        when (node) {
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    walkVideos(node.opt(i), out, depth + 1)
                }
            }
            is JSONObject -> {
                val vr = node.optJSONObject("videoRenderer")
                    ?: node.optJSONObject("gridVideoRenderer")
                    ?: node.optJSONObject("compactVideoRenderer")
                    ?: node.optJSONObject("playlistVideoRenderer")
                if (vr != null) {
                    parseVideoRenderer(vr)?.let { out.add(it) }
                    return
                }
                val lvm = node.optJSONObject("lockupViewModel")
                if (lvm != null) {
                    parseLockupViewModel(lvm)?.let { out.add(it) }
                    return
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    walkVideos(node.opt(k), out, depth + 1)
                }
            }
        }
    }

    private fun parseVideoRenderer(v: JSONObject): VideoItem? {
        val id = v.optString("videoId")
        if (id.length != 11) return null
        if (v.has("upcomingEventData")) return null
        val nav = v.optJSONObject("navigationEndpoint")
        if (nav != null && nav.has("reelWatchEndpoint")) return null

        val title = extractText(v.opt("title")).trim()
        if (title.isEmpty()) return null

        val owner = v.optJSONObject("ownerText")
            ?: v.optJSONObject("shortBylineText")
            ?: v.optJSONObject("longBylineText")
        val channelName = extractText(owner).trim()
        val channelId = owner?.optJSONArray("runs")?.optJSONObject(0)
            ?.optJSONObject("navigationEndpoint")
            ?.optJSONObject("browseEndpoint")
            ?.optString("browseId") ?: ""

        val avatar = absUrl(
            deepFindThumbUrl(v.optJSONObject("channelThumbnailSupportedRenderers"), "thumbnails")
                .ifBlank { deepFindThumbUrl(v.optJSONObject("channelThumbnail"), "thumbnails") }
        )

        val views = extractText(v.opt("shortViewCountText")).ifBlank { extractText(v.opt("viewCountText")) }
        val pub = extractText(v.opt("publishedTimeText"))
        val meta = listOf(views, pub).filter { it.isNotBlank() }.joinToString(" · ")
        val dur = extractText(v.opt("lengthText"))

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = avatar,
            duration = dur,
            meta = meta
        )
    }

    private fun parseLockupViewModel(l: JSONObject): VideoItem? {
        val id = l.optString("contentId")
        if (id.length != 11) return null
        val ctype = l.optString("contentType")
        if (ctype.isNotBlank() && !ctype.contains("VIDEO", ignoreCase = true)) return null

        val md = l.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel") ?: return null
        val title = extractText(md.opt("title")).trim()
        if (title.isEmpty()) return null

        val rows = deepFindArray(md, "metadataRows")
        val parts = mutableListOf<List<String>>()
        if (rows != null) {
            for (i in 0 until rows.length()) {
                val r = rows.optJSONObject(i) ?: continue
                val mp = r.optJSONArray("metadataParts") ?: continue
                val rowTexts = mutableListOf<String>()
                for (j in 0 until mp.length()) {
                    val t = mp.optJSONObject(j)?.optJSONObject("text")?.optString("content")
                    if (!t.isNullOrBlank()) rowTexts.add(t)
                }
                if (rowTexts.isNotEmpty()) parts.add(rowTexts)
            }
        }

        val channelName = parts.getOrNull(0)?.firstOrNull() ?: ""
        val meta = parts.getOrNull(1)?.joinToString(" · ") ?: ""
        val channelId = deepFindObject(md.opt("image"), "browseEndpoint")?.optString("browseId") ?: ""
        val avatar = absUrl(deepFindArray(md.opt("image"), "sources")?.optJSONObject(0)?.optString("url") ?: "")

        val badges = mutableListOf<JSONObject>()
        collectObjectsByKey(l.opt("contentImage"), "thumbnailBadgeViewModel", badges)
        val dur = badges.mapNotNull { it.optString("text").takeIf { s -> DUR_REGEX.matches(s) } }.firstOrNull() ?: ""

        return VideoItem(
            id = id,
            title = title,
            channelName = channelName,
            channelId = channelId,
            channelAvatar = avatar,
            duration = dur,
            meta = meta
        )
    }

    private fun extractText(node: Any?): String {
        if (node == null) return ""
        if (node is String) return node
        if (node !is JSONObject) return ""
        node.optString("simpleText").takeIf { it.isNotBlank() }?.let { return it }
        node.optString("content").takeIf { it.isNotBlank() }?.let { return it }
        val runs = node.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        }
        return sb.toString()
    }

    private fun deepFindObject(node: Any?, key: String, depth: Int = 0): JSONObject? {
        if (node == null || depth > 35) return null
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = deepFindObject(node.opt(keys.next()), key, depth + 1)
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = deepFindObject(node.opt(i), key, depth + 1)
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun deepFindArray(node: Any?, key: String, depth: Int = 0): JSONArray? {
        if (node == null || depth > 35) return null
        when (node) {
            is JSONObject -> {
                node.optJSONArray(key)?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = deepFindArray(node.opt(keys.next()), key, depth + 1)
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = deepFindArray(node.opt(i), key, depth + 1)
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun collectObjectsByKey(node: Any?, key: String, out: MutableList<JSONObject>, depth: Int = 0) {
        if (node == null || depth > 40) return
        when (node) {
            is JSONObject -> {
                node.optJSONObject(key)?.let { out.add(it) }
                val keys = node.keys()
                while (keys.hasNext()) {
                    collectObjectsByKey(node.opt(keys.next()), key, out, depth + 1)
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    collectObjectsByKey(node.opt(i), key, out, depth + 1)
                }
            }
        }
    }

    private fun deepFindThumbUrl(node: Any?, key: String): String {
        val target = if (key == "thumbnails") node else deepFindObject(node, key) ?: return ""
        val thumbs = deepFindArray(target, "thumbnails")
            ?: deepFindArray(target, "sources")
            ?: return ""
        return thumbs.lastThumbUrl()
    }

    private fun JSONArray.lastThumbUrl(): String {
        if (length() == 0) return ""
        return optJSONObject(length() - 1)?.optString("url") ?: ""
    }

    private fun extractSubscriberFromPageHeader(header: JSONObject?): String {
        val rows = deepFindArray(header, "metadataRows") ?: return ""
        for (i in 0 until rows.length()) {
            val mp = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
            for (j in 0 until mp.length()) {
                val txt = mp.optJSONObject(j)?.optJSONObject("text")?.optString("content") ?: ""
                if (txt.contains("sub", ignoreCase = true) || txt.contains("مشترك")) return txt
            }
        }
        return ""
    }

    private fun findLikeCount(primary: JSONObject?): String {
        if (primary == null) return ""
        val likeBtn = deepFindObject(primary, "likeButtonViewModel")
            ?: deepFindObject(primary, "segmentedLikeDislikeButtonViewModel")
        val title = deepFindObject(likeBtn, "buttonViewModel")?.optString("title") ?: ""
        return if (title.isNotBlank() && title != "Like") title else ""
    }

    private fun findCommentsContinuation(json: JSONObject): String? {
        val sections = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "itemSectionRenderer", sections)
        for (s in sections) {
            val id = s.optString("sectionIdentifier")
            val targetId = s.optString("targetId")
            if (id.contains("comment", ignoreCase = true) || targetId.contains("comment", ignoreCase = true)) {
                val token = deepFindObject(s, "continuationCommand")?.optString("token")
                if (!token.isNullOrBlank()) return token
            }
        }
        val ep = mutableListOf<JSONObject>()
        collectObjectsByKey(json, "engagementPanelSectionListRenderer", ep)
        for (panel in ep) {
            if (panel.optString("panelIdentifier").contains("comment", ignoreCase = true)) {
                val token = deepFindObject(panel, "continuationCommand")?.optString("token")
                if (!token.isNullOrBlank()) return token
            }
        }
        return null
    }

    private fun absUrl(u: String): String {
        return when {
            u.isBlank() -> ""
            u.startsWith("//") -> "https:$u"
            else -> u
        }
    }

    private fun decodeXml(s: String): String = s
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
}
