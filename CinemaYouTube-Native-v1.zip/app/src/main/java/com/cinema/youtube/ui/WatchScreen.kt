package com.cinema.youtube.ui

import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.StreamChoice
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay

enum class WatchPanel { NONE, DETAILS, COMMENTS, UP_NEXT }

@OptIn(UnstableApi::class)
@Composable
fun WatchScreen(
    video: VideoItem,
    initialPositionMs: Long,
    gl: String,
    hl: String,
    isSubscribed: (String) -> Boolean,
    playlists: List<UserPlaylist>,
    isLandscape: Boolean,
    onToggleLandscape: () -> Unit,
    onBack: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onToggleVideoInPlaylist: (String, VideoItem) -> Unit,
    onSaveProgress: (VideoItem, Long, Long) -> Unit
) {
    val context = LocalContext.current

    var streams by remember(video.id) { mutableStateOf<List<StreamChoice>>(emptyList()) }
    var currentStreamIndex by remember(video.id) { mutableIntStateOf(0) }
    var loadingStreams by remember(video.id) { mutableStateOf(true) }
    var streamError by remember(video.id) { mutableStateOf<String?>(null) }
    var reloadNonce by remember(video.id) { mutableIntStateOf(0) }

    var details by remember(video.id) { mutableStateOf<VideoDetails?>(null) }
    var comments by remember(video.id) { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsLoaded by remember(video.id) { mutableStateOf(false) }

    var activePanel by remember(video.id) { mutableStateOf(WatchPanel.NONE) }
    var showControls by remember(video.id) { mutableStateOf(true) }
    var showQualityMenu by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }

    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(true) }
    var positionMs by remember(video.id) { mutableLongStateOf(initialPositionMs) }
    var durationMs by remember(video.id) { mutableLongStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var sliderPos by remember { mutableFloatStateOf(0f) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var restoredInitialSeek by remember(video.id) { mutableStateOf(false) }

    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    // Build & load ExoPlayer media source for chosen stream
    fun playChoice(choice: StreamChoice, seekMs: Long) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(12_000)
            .setReadTimeoutMs(15_000)
            .apply {
                if (choice.userAgent.isNotBlank()) {
                    setUserAgent(choice.userAgent)
                }
            }

        val mediaSource = when {
            choice.isHls -> {
                HlsMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
            !choice.audioUrl.isNullOrBlank() -> {
                val vidSrc = ProgressiveMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
                val audSrc = ProgressiveMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.audioUrl))
                MergingMediaSource(vidSrc, audSrc)
            }
            else -> {
                ProgressiveMediaSource.Factory(httpFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
        }

        exoPlayer.setMediaSource(mediaSource)
        exoPlayer.prepare()
        if (seekMs > 2_000L) {
            exoPlayer.seekTo(seekMs)
        }
        exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
        exoPlayer.playWhenReady = true
    }

    // ExoPlayer listener with automatic fallback to next client stream on error
    DisposableEffect(exoPlayer, streams, currentStreamIndex) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_READY && exoPlayer.duration > 0) {
                    durationMs = exoPlayer.duration
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val nextIdx = currentStreamIndex + 1
                if (nextIdx < streams.size) {
                    currentStreamIndex = nextIdx
                    playChoice(streams[nextIdx], exoPlayer.currentPosition.coerceAtLeast(positionMs))
                } else {
                    isBuffering = false
                    streamError = "تعذّر تشغيل الفيديو (${error.errorCodeName}). جرّب إعادة المحاولة."
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    // Release ExoPlayer and save progress on exit
    DisposableEffect(video.id) {
        onDispose {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (pos > 0L || dur > 0L) {
                onSaveProgress(
                    video.copy(
                        title = details?.title?.ifBlank { video.title } ?: video.title,
                        channelName = details?.channelName?.ifBlank { video.channelName } ?: video.channelName,
                        channelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId,
                        channelAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
                    ),
                    pos,
                    dur
                )
            }
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    // Resolve ad-free streams + fetch video metadata/related
    LaunchedEffect(video.id, reloadNonce) {
        loadingStreams = true
        streamError = null
        isBuffering = true
        exoPlayer.stop()

        val resolved = InnerTubeClient.resolveStreams(video.id)
        loadingStreams = false
        if (resolved.choices.isEmpty()) {
            isBuffering = false
            streamError = resolved.errorMessage ?: "لم يتم العثور على رابط تشغيل لهذا الفيديو"
        } else {
            streams = resolved.choices
            // Default to 720p or Auto HD for instant smooth playback on mobile
            val preferredIdx = resolved.choices.indexOfFirst { it.isHls || it.height == 720 }
                .takeIf { it >= 0 } ?: 0
            currentStreamIndex = preferredIdx
            val seekTarget = if (!restoredInitialSeek) {
                restoredInitialSeek = true
                initialPositionMs
            } else positionMs
            playChoice(resolved.choices[preferredIdx], seekTarget)
        }
    }

    LaunchedEffect(video.id) {
        details = InnerTubeClient.fetchWatchDetails(video.id, gl, hl)
    }

    // Load comments lazily when Comments drawer opens
    LaunchedEffect(activePanel, details?.commentsContinuation) {
        if (activePanel == WatchPanel.COMMENTS && !commentsLoaded) {
            val token = details?.commentsContinuation
            if (!token.isNullOrBlank()) {
                comments = InnerTubeClient.fetchComments(token, gl, hl)
                commentsLoaded = true
            }
        }
    }

    // Poll playback progress & periodically persist Continue Watching
    LaunchedEffect(video.id, exoPlayer) {
        var tick = 0
        while (true) {
            delay(500)
            if (!isSeeking) {
                positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                if (exoPlayer.duration > 0) {
                    durationMs = exoPlayer.duration
                    sliderPos = (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                }
            }
            tick++
            if (tick % 12 == 0 && durationMs > 0L && isPlaying) {
                onSaveProgress(video, positionMs, durationMs)
            }
        }
    }

    // Auto-hide controls after 3.2s when playing
    LaunchedEffect(showControls, isPlaying, activePanel) {
        if (showControls && isPlaying && activePanel == WatchPanel.NONE) {
            delay(3200)
            showControls = false
        }
    }

    val displayTitle = details?.title?.ifBlank { video.title } ?: video.title
    val displayChannel = details?.channelName?.ifBlank { video.channelName } ?: video.channelName
    val displayChannelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId
    val displayAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Native Media3 Video Surface
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (activePanel != WatchPanel.NONE) {
                        activePanel = WatchPanel.NONE
                    } else {
                        showControls = !showControls
                    }
                },
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    keepScreenOn = true
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv ->
                if (pv.player !== exoPlayer) pv.player = exoPlayer
            }
        )

        // Loading / Error Center Overlay
        if (loadingStreams || (isBuffering && streamError == null)) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 3.dp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
            )
        }

        if (streamError != null) {
            Surface(
                color = CinemaColors.GlassStrong,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .widthIn(max = 340.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = streamError ?: "",
                        color = CinemaColors.TextPrimary,
                        fontSize = 14.sp
                    )
                    Button(
                        onClick = { reloadNonce++ },
                        shape = RoundedCornerShape(999.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة المحاولة", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Cinema Style Floating HUD (Top + Center + Bottom)
        AnimatedVisibility(
            visible = showControls || activePanel != WatchPanel.NONE,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top & Bottom subtle gradients
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xB3000000), Color.Transparent)
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xCC000000))
                            )
                        )
                )

                // TOP BAR — Matches Cinema Style Screenshot 3 (Back + NowCard | Details, Comments, Up next)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        GlassCircleButton(
                            icon = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            onClick = onBack
                        )

                        // Floating Now-Playing Pill (Avatar + Video Title + Channel)
                        Surface(
                            color = CinemaColors.GlassFill,
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                            modifier = Modifier
                                .height(46.dp)
                                .widthIn(max = if (isLandscape) 380.dp else 185.dp)
                                .clickable {
                                    if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId)
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(start = 5.dp, end = 12.dp)
                            ) {
                                ChannelAvatar(url = displayAvatar, name = displayChannel, size = 34.dp)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = displayTitle,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (displayChannel.isNotBlank()) {
                                        Text(
                                            text = displayChannel,
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.width(8.dp))

                    // Right Pills: Details | Comments | Up next
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WatchPanelPill(
                            icon = Icons.Rounded.Info,
                            label = if (isLandscape) "Details" else null,
                            active = activePanel == WatchPanel.DETAILS,
                            onClick = {
                                activePanel = if (activePanel == WatchPanel.DETAILS) WatchPanel.NONE else WatchPanel.DETAILS
                            }
                        )
                        WatchPanelPill(
                            icon = Icons.Rounded.ChatBubbleOutline,
                            label = if (isLandscape) "Comments" else null,
                            active = activePanel == WatchPanel.COMMENTS,
                            onClick = {
                                activePanel = if (activePanel == WatchPanel.COMMENTS) WatchPanel.NONE else WatchPanel.COMMENTS
                            }
                        )
                        WatchPanelPill(
                            icon = Icons.Rounded.QueueMusic,
                            label = if (isLandscape) "Up next" else null,
                            active = activePanel == WatchPanel.UP_NEXT,
                            onClick = {
                                activePanel = if (activePanel == WatchPanel.UP_NEXT) WatchPanel.NONE else WatchPanel.UP_NEXT
                            }
                        )
                    }
                }

                // CENTER PLAYBACK CONTROLS (-10s, Play/Pause, +10s)
                if (activePanel == WatchPanel.NONE && streamError == null && !loadingStreams) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(28.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlassCircleButton(
                            icon = Icons.Rounded.Replay10,
                            contentDescription = "-10s",
                            size = 50.dp,
                            onClick = {
                                exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L))
                            }
                        )
                        Surface(
                            color = Color(0xEBFFFFFF),
                            shape = CircleShape,
                            modifier = Modifier
                                .size(64.dp)
                                .clickable {
                                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.Black,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                        GlassCircleButton(
                            icon = Icons.Rounded.Forward10,
                            contentDescription = "+10s",
                            size = 50.dp,
                            onClick = {
                                val target = exoPlayer.currentPosition + 10_000L
                                exoPlayer.seekTo(if (durationMs > 0) target.coerceAtMost(durationMs) else target)
                            }
                        )
                    }
                }

                // BOTTOM SEEKBAR + QUALITY / SPEED / FULLSCREEN
                if (activePanel == WatchPanel.NONE) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Slider(
                            value = sliderPos,
                            onValueChange = { v ->
                                isSeeking = true
                                sliderPos = v
                            },
                            onValueChangeFinished = {
                                if (durationMs > 0L) {
                                    val seekTo = (sliderPos * durationMs).toLong()
                                    exoPlayer.seekTo(seekTo)
                                    positionMs = seekTo
                                }
                                isSeeking = false
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White,
                                inactiveTrackColor = Color(0x4DFFFFFF)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${formatTime(positionMs)} / ${formatTime(durationMs)}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Speed Pill
                                Surface(
                                    color = CinemaColors.GlassFill,
                                    shape = RoundedCornerShape(999.dp),
                                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                                    modifier = Modifier.clickable {
                                        val speeds = listOf(1f, 1.25f, 1.5f, 2f, 0.75f)
                                        val next = speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.size]
                                        playbackSpeed = next
                                        exoPlayer.playbackParameters = PlaybackParameters(next)
                                    }
                                ) {
                                    Text(
                                        text = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                                    )
                                }

                                // Quality Picker Pill
                                Box {
                                    val activeLabel = streams.getOrNull(currentStreamIndex)?.label ?: "HD"
                                    Surface(
                                        color = CinemaColors.GlassFill,
                                        shape = RoundedCornerShape(999.dp),
                                        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                                        modifier = Modifier.clickable { showQualityMenu = true }
                                    ) {
                                        Text(
                                            text = activeLabel,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showQualityMenu,
                                        onDismissRequest = { showQualityMenu = false },
                                        modifier = Modifier.background(Color(0xFF1C1C20))
                                    ) {
                                        streams.forEachIndexed { idx, choice ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = "${choice.label} (${choice.clientTag})",
                                                        color = if (idx == currentStreamIndex) Color.White else CinemaColors.TextSecondary,
                                                        fontWeight = if (idx == currentStreamIndex) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                },
                                                onClick = {
                                                    showQualityMenu = false
                                                    currentStreamIndex = idx
                                                    playChoice(choice, exoPlayer.currentPosition)
                                                }
                                            )
                                        }
                                    }
                                }

                                // Fullscreen Rotation Toggle
                                GlassCircleButton(
                                    icon = if (isLandscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                    contentDescription = "Fullscreen",
                                    size = 38.dp,
                                    onClick = onToggleLandscape
                                )
                            }
                        }
                    }
                }
            }
        }

        // SLIDING CINEMA SIDE DRAWER (Details / Comments / Up next)
        AnimatedVisibility(
            visible = activePanel != WatchPanel.NONE,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .statusBarsPadding()
                .padding(top = 64.dp, end = 10.dp, bottom = 10.dp, start = 10.dp)
                .widthIn(max = 420.dp)
                .fillMaxWidth(if (isLandscape) 0.45f else 0.96f)
                .fillMaxHeight()
        ) {
            Surface(
                color = CinemaColors.GlassStrong,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Drawer Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = when (activePanel) {
                                WatchPanel.DETAILS -> "Details"
                                WatchPanel.COMMENTS -> "Comments"
                                WatchPanel.UP_NEXT -> "Up next"
                                WatchPanel.NONE -> ""
                            },
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .clickable { activePanel = WatchPanel.NONE }
                        )
                    }

                    when (activePanel) {
                        WatchPanel.DETAILS -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = displayTitle,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 24.sp
                                )

                                val metaText = listOfNotNull(
                                    details?.viewCount?.takeIf { it.isNotBlank() },
                                    details?.publishDate?.takeIf { it.isNotBlank() },
                                    details?.likeCount?.takeIf { it.isNotBlank() }?.let { "👍 $it" }
                                ).joinToString(" · ")
                                if (metaText.isNotBlank()) {
                                    Text(text = metaText, color = CinemaColors.TextSecondary, fontSize = 13.sp)
                                }

                                // Channel Row + Subscribe Button
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId)
                                            }
                                    ) {
                                        ChannelAvatar(url = displayAvatar, name = displayChannel, size = 40.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = displayChannel,
                                                color = Color.White,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            details?.subscriberCount?.takeIf { it.isNotBlank() }?.let {
                                                Text(text = it, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                                            }
                                        }
                                    }

                                    if (displayChannelId.isNotBlank()) {
                                        val subbed = isSubscribed(displayChannelId)
                                        Surface(
                                            color = if (subbed) Color(0x26FFFFFF) else Color.White,
                                            shape = RoundedCornerShape(999.dp),
                                            modifier = Modifier.clickable {
                                                onToggleSubscribe(
                                                    SubscribedChannel(
                                                        id = displayChannelId,
                                                        name = displayChannel,
                                                        avatarUrl = displayAvatar
                                                    )
                                                )
                                            }
                                        ) {
                                            Text(
                                                text = if (subbed) "Subscribed" else "Subscribe",
                                                color = if (subbed) Color.White else Color.Black,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                            )
                                        }
                                    }
                                }

                                // Save to Playlist Pill
                                Surface(
                                    color = Color(0x1FFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable { showPlaylistDialog = true }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Icon(
                                            Icons.Rounded.BookmarkAdd,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text("Save to Playlist", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    }
                                }

                                // Description Box
                                val desc = details?.description ?: ""
                                if (desc.isNotBlank()) {
                                    Surface(
                                        color = Color(0x12FFFFFF),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = desc,
                                            color = CinemaColors.TextPrimary,
                                            fontSize = 13.sp,
                                            lineHeight = 19.sp,
                                            modifier = Modifier.padding(14.dp)
                                        )
                                    }
                                }
                                Spacer(Modifier.height(16.dp))
                            }
                        }

                        WatchPanel.COMMENTS -> {
                            if (!commentsLoaded && details?.commentsContinuation != null) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
                                }
                            } else if (comments.isEmpty()) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No comments available", color = CinemaColors.TextSecondary, fontSize = 14.sp)
                                }
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    items(comments) { c ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            ChannelAvatar(url = c.avatarUrl, name = c.author, size = 32.dp)
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Text(
                                                        text = c.author,
                                                        color = Color.White,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    if (c.publishedTime.isNotBlank()) {
                                                        Text(
                                                            text = c.publishedTime,
                                                            color = CinemaColors.TextSecondary,
                                                            fontSize = 11.sp
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = c.text,
                                                    color = CinemaColors.TextPrimary,
                                                    fontSize = 13.sp,
                                                    lineHeight = 18.sp
                                                )
                                                if (c.likeCount.isNotBlank()) {
                                                    Text(
                                                        text = "👍 ${c.likeCount}",
                                                        color = CinemaColors.TextSecondary,
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        WatchPanel.UP_NEXT -> {
                            val rel = details?.relatedVideos ?: emptyList()
                            if (rel.isEmpty()) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
                                }
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(rel, key = { it.id }) { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable {
                                                    activePanel = WatchPanel.NONE
                                                    onOpenVideo(item)
                                                }
                                                .padding(6.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .width(136.dp)
                                                    .aspectRatio(16f / 9f)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(CinemaColors.SurfaceDark)
                                            ) {
                                                AsyncImage(
                                                    model = item.thumbnailUrl,
                                                    contentDescription = item.title,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                                if (item.duration.isNotBlank()) {
                                                    Text(
                                                        text = item.duration,
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        modifier = Modifier
                                                            .align(Alignment.BottomEnd)
                                                            .padding(4.dp)
                                                            .background(Color(0xB8000000), RoundedCornerShape(5.dp))
                                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Column(
                                                modifier = Modifier.weight(1f),
                                                verticalArrangement = Arrangement.spacedBy(3.dp)
                                            ) {
                                                Text(
                                                    text = item.title,
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = item.channelName,
                                                    color = CinemaColors.TextSecondary,
                                                    fontSize = 11.5.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (item.meta.isNotBlank()) {
                                                    Text(
                                                        text = item.meta,
                                                        color = CinemaColors.TextSecondary,
                                                        fontSize = 11.sp,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        WatchPanel.NONE -> {}
                    }
                }
            }
        }

        // Save to Playlist Picker Dialog
        if (showPlaylistDialog) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlaylistDialog = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(24.dp)
                        .widthIn(max = 320.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Save to Playlist", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        val richVideo = video.copy(
                            title = displayTitle,
                            channelName = displayChannel,
                            channelId = displayChannelId,
                            channelAvatar = displayAvatar
                        )
                        playlists.forEach { pl ->
                            val saved = pl.videos.any { it.id == video.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x14FFFFFF))
                                    .clickable { onToggleVideoInPlaylist(pl.id, richVideo) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(pl.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                if (saved) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassCircleButton(
    icon: ImageVector,
    contentDescription: String,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    onClick: () -> Unit
) {
    Surface(
        color = CinemaColors.GlassFill,
        shape = CircleShape,
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier
            .size(size)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = contentDescription, tint = Color.White, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun WatchPanelPill(
    icon: ImageVector,
    label: String?,
    active: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) CinemaColors.PillActiveBg else CinemaColors.GlassFill,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, CinemaColors.GlassStroke),
        modifier = Modifier
            .height(42.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = if (label != null) 14.dp else 11.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) Color.Black else Color.White,
                modifier = Modifier.size(18.dp)
            )
            if (label != null) {
                Spacer(Modifier.width(6.dp))
                Text(
                    text = label,
                    color = if (active) Color.Black else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
