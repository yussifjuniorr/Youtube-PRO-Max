package com.cinema.youtube.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object CinemaColors {
    val BgBlack = Color(0xFF050505)
    val SurfaceDark = Color(0xFF141417)
    val GlassFill = Color(0xDD1E1E22)
    val GlassStrong = Color(0xF218181C)
    val GlassStroke = Color(0x28FFFFFF)
    val TextPrimary = Color(0xFFF5F5F7)
    val TextSecondary = Color(0xA6EBEBF5)
    val YtRed = Color(0xFFFF0033)
    val PillActiveBg = Color(0xEBFFFFFF)
    val PillActiveText = Color(0xFF000000)
}

private val CinemaDarkScheme = darkColorScheme(
    primary = CinemaColors.TextPrimary,
    onPrimary = Color.Black,
    secondary = CinemaColors.YtRed,
    background = CinemaColors.BgBlack,
    surface = CinemaColors.SurfaceDark,
    onBackground = CinemaColors.TextPrimary,
    onSurface = CinemaColors.TextPrimary
)

@Composable
fun CinemaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CinemaDarkScheme,
        content = content
    )
}
