package com.cinema.youtube

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.data.LocalStore
import com.cinema.youtube.model.ChannelInfo
import com.cinema.youtube.model.HomeShelf
import com.cinema.youtube.model.VideoItem
import com.cinema.youtube.ui.ChannelScreen
import com.cinema.youtube.ui.CinemaColors
import com.cinema.youtube.ui.CinemaTheme
import com.cinema.youtube.ui.FloatingCinemaNav
import com.cinema.youtube.ui.HistoryScreen
import com.cinema.youtube.ui.HomeScreen
import com.cinema.youtube.ui.PlaylistsScreen
import com.cinema.youtube.ui.SearchResultsScreen
import com.cinema.youtube.ui.SettingsDialog
import com.cinema.youtube.ui.SubscriptionsScreen
import com.cinema.youtube.ui.TopTab
import com.cinema.youtube.ui.WatchScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var store: LocalStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.parseColor("#050505"))
        )
        store = LocalStore(applicationContext)

        setContent {
            CinemaTheme {
                val scope = rememberCoroutineScope()

                var appPrefs by remember { mutableStateOf(store.getAppPrefs()) }
                var subscriptions by remember { mutableStateOf(store.getSubscriptions()) }
                var playlists by remember { mutableStateOf(store.getPlaylists()) }
                var history by remember { mutableStateOf(store.getHistory()) }
                var recentSearches by remember { mutableStateOf(store.getRecentSearches()) }

                var activeTab by remember { mutableStateOf(TopTab.HOME) }
                var isSearching by remember { mutableStateOf(false) }
                var searchText by remember { mutableStateOf("") }
                var activeSearchQuery by remember { mutableStateOf<String?>(null) }
                var searchResults by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var searchLoading by remember { mutableStateOf(false) }

                var heroVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var homeShelves by remember { mutableStateOf<List<HomeShelf>>(emptyList()) }
                var subFeedVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var homeLoading by remember { mutableStateOf(true) }
                var homeReloadKey by remember { mutableIntStateOf(0) }

                var activeChannelId by remember { mutableStateOf<String?>(null) }
                var activeChannelInfo by remember { mutableStateOf<ChannelInfo?>(null) }
                var channelLoading by remember { mutableStateOf(false) }

                var watchingVideo by remember { mutableStateOf<VideoItem?>(null) }
                var isLandscape by remember { mutableStateOf(false) }
                var showSettings by remember { mutableStateOf(false) }

                fun setImmersive(enabled: Boolean) {
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    if (enabled) {
                        controller.systemBarsBehavior =
                            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        controller.hide(WindowInsetsCompat.Type.systemBars())
                    } else {
                        controller.show(WindowInsetsCompat.Type.systemBars())
                    }
                }

                fun updateLandscape(landscape: Boolean) {
                    isLandscape = landscape
                    requestedOrientation = if (landscape) {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }
                    setImmersive(landscape)
                }

                // Load Home shelves + Subscription feed
                LaunchedEffect(appPrefs, homeReloadKey) {
                    homeLoading = true
                    val (hero, shelves) = InnerTubeClient.fetchHomeShelves(
                        gl = appPrefs.regionCode,
                        hl = appPrefs.languageCode,
                        subscriptions = subscriptions
                    )
                    heroVideos = hero
                    homeShelves = shelves
                    homeLoading = false
                }

                LaunchedEffect(subscriptions) {
                    subFeedVideos = InnerTubeClient.fetchSubscriptionFeed(subscriptions)
                }

                // Load Channel when activeChannelId changes
                LaunchedEffect(activeChannelId) {
                    val cid = activeChannelId ?: return@LaunchedEffect
                    channelLoading = true
                    activeChannelInfo = null
                    activeChannelInfo = InnerTubeClient.fetchChannel(cid, appPrefs.regionCode, appPrefs.languageCode)
                    channelLoading = false
                }

                // Manage Back button cleanly across all overlays
                BackHandler(
                    enabled = watchingVideo != null ||
                        activeChannelId != null ||
                        activeSearchQuery != null ||
                        isSearching ||
                        activeTab != TopTab.HOME
                ) {
                    when {
                        watchingVideo != null -> {
                            updateLandscape(false)
                            watchingVideo = null
                        }
                        activeChannelId != null -> {
                            activeChannelId = null
                        }
                        isSearching -> {
                            isSearching = false
                            searchText = ""
                        }
                        activeSearchQuery != null -> {
                            activeSearchQuery = null
                            searchResults = emptyList()
                        }
                        activeTab != TopTab.HOME -> {
                            activeTab = TopTab.HOME
                        }
                    }
                }

                val continueWatching = remember(history) {
                    history
                        .filter { it.progressPercent in 3..94 }
                        .map { it.video.copy(progressPercent = it.progressPercent) }
                        .take(15)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(CinemaColors.BgBlack)
                ) {
                    val currentWatch = watchingVideo
                    val currentChannel = activeChannelId

                    when {
                        currentWatch != null -> {
                            WatchScreen(
                                video = currentWatch,
                                initialPositionMs = store.getSavedPosition(currentWatch.id),
                                gl = appPrefs.regionCode,
                                hl = appPrefs.languageCode,
                                isSubscribed = { cid -> subscriptions.any { it.id == cid } },
                                playlists = playlists,
                                isLandscape = isLandscape,
                                onToggleLandscape = { updateLandscape(!isLandscape) },
                                onBack = {
                                    updateLandscape(false)
                                    watchingVideo = null
                                },
                                onOpenVideo = { nextVid -> watchingVideo = nextVid },
                                onOpenChannel = { cid ->
                                    updateLandscape(false)
                                    watchingVideo = null
                                    activeChannelId = cid
                                },
                                onToggleSubscribe = { ch ->
                                    subscriptions = store.toggleSubscription(ch)
                                },
                                onToggleVideoInPlaylist = { plId, v ->
                                    playlists = store.toggleVideoInPlaylist(plId, v)
                                },
                                onSaveProgress = { v, pos, dur ->
                                    history = store.saveHistoryEntry(v, pos, dur)
                                }
                            )
                        }

                        currentChannel != null -> {
                            ChannelScreen(
                                channel = activeChannelInfo,
                                isLoading = channelLoading,
                                isSubscribed = subscriptions.any { it.id == currentChannel },
                                onBack = { activeChannelId = null },
                                onToggleSubscribe = { ch -> subscriptions = store.toggleSubscription(ch) },
                                onPlayVideo = { vid -> watchingVideo = vid }
                            )
                        }

                        activeSearchQuery != null -> {
                            SearchResultsScreen(
                                query = activeSearchQuery ?: "",
                                results = searchResults,
                                isLoading = searchLoading,
                                onPlayVideo = { vid -> watchingVideo = vid }
                            )
                        }

                        else -> {
                            when (activeTab) {
                                TopTab.HOME -> HomeScreen(
                                    heroVideos = heroVideos,
                                    shelves = homeShelves,
                                    continueWatching = continueWatching,
                                    isLoading = homeLoading,
                                    onRefresh = { homeReloadKey++ },
                                    onPlayVideo = { vid -> watchingVideo = vid },
                                    onOpenChannel = { cid -> activeChannelId = cid }
                                )

                                TopTab.SUBSCRIPTIONS -> SubscriptionsScreen(
                                    subscriptions = subscriptions,
                                    subVideos = subFeedVideos,
                                    onOpenChannel = { cid -> activeChannelId = cid },
                                    onPlayVideo = { vid -> watchingVideo = vid }
                                )

                                TopTab.PLAYLISTS -> PlaylistsScreen(
                                    playlists = playlists,
                                    onCreatePlaylist = { name -> playlists = store.createPlaylist(name) },
                                    onDeletePlaylist = { id -> playlists = store.deletePlaylist(id) },
                                    onPlayVideo = { vid -> watchingVideo = vid }
                                )

                                TopTab.HISTORY -> HistoryScreen(
                                    history = history,
                                    onPlayVideo = { vid -> watchingVideo = vid },
                                    onClearHistory = {
                                        store.clearHistory()
                                        history = emptyList()
                                    }
                                )
                            }
                        }
                    }

                    // Floating Cinema Pill Bar (shown everywhere except Watch & Channel screens)
                    if (watchingVideo == null && activeChannelId == null) {
                        FloatingCinemaNav(
                            activeTab = activeTab,
                            isSearching = isSearching,
                            searchText = searchText,
                            recentSearches = recentSearches,
                            hl = appPrefs.languageCode,
                            onTabSelected = { tab ->
                                activeSearchQuery = null
                                activeTab = tab
                            },
                            onSearchModeChange = { isSearching = it },
                            onSearchTextChange = { searchText = it },
                            onSubmitSearch = { q ->
                                val cleaned = q.trim()
                                if (cleaned.isNotEmpty()) {
                                    isSearching = false
                                    activeSearchQuery = cleaned
                                    recentSearches = store.addRecentSearch(cleaned)
                                    scope.launch {
                                        searchLoading = true
                                        searchResults = InnerTubeClient.searchVideos(
                                            cleaned,
                                            appPrefs.regionCode,
                                            appPrefs.languageCode
                                        )
                                        searchLoading = false
                                    }
                                }
                            },
                            onClearRecentSearches = {
                                store.clearRecentSearches()
                                recentSearches = emptyList()
                            },
                            onOpenSettings = { showSettings = true }
                        )
                    }

                    if (showSettings) {
                        SettingsDialog(
                            prefs = appPrefs,
                            onUpdatePrefs = { updated ->
                                appPrefs = updated
                                store.saveAppPrefs(updated)
                            },
                            onDismiss = { showSettings = false }
                        )
                    }
                }
            }
        }
    }
}
