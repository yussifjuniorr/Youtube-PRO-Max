package com.cinema.youtube.data

import com.cinema.youtube.model.CaptionTrack
import com.cinema.youtube.model.ExtractedVideoStreams
import com.cinema.youtube.model.StreamChoice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request as NpeRequest
import org.schabi.newpipe.extractor.downloader.Response as NpeResponse
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.io.IOException
import java.util.concurrent.TimeUnit

object NativeStreamEngine {

    private const val CHROME_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36"

    val playerOkHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    @Volatile
    private var initialized = false

    private fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (!initialized) {
                NewPipe.init(OkHttpNpeDownloader(playerOkHttpClient))
                initialized = true
            }
        }
    }

    private class OkHttpNpeDownloader(
        private val client: OkHttpClient
    ) : Downloader() {

        @Throws(IOException::class, ReCaptchaException::class)
        override fun execute(request: NpeRequest): NpeResponse {
            val httpMethod = request.httpMethod()
            val url = request.url()
            val dataToSend = request.dataToSend()

            val requestBody = when {
                dataToSend != null -> dataToSend.toRequestBody(null, 0, dataToSend.size)
                httpMethod.equals("POST", ignoreCase = true) || httpMethod.equals("PUT", ignoreCase = true) ->
                    ByteArray(0).toRequestBody(null, 0, 0)
                else -> null
            }

            val builder = okhttp3.Request.Builder()
                .method(httpMethod, requestBody)
                .url(url)
                .header("User-Agent", CHROME_UA)

            for ((headerName, headerValues) in request.headers()) {
                if (headerValues.isNullOrEmpty()) continue
                builder.removeHeader(headerName)
                for (value in headerValues) {
                    builder.addHeader(headerName, value)
                }
            }

            client.newCall(builder.build()).execute().use { resp ->
                if (resp.code == 429) {
                    throw ReCaptchaException("reCaptcha Challenge requested", url)
                }
                val bodyStr = resp.body?.string()
                val latestUrl = resp.request.url.toString()
                return NpeResponse(
                    resp.code,
                    resp.message,
                    resp.headers.toMultimap(),
                    bodyStr,
                    latestUrl
                )
            }
        }
    }

    suspend fun extractStreams(videoId: String): ExtractedVideoStreams = withContext(Dispatchers.IO) {
        ensureInitialized()

        var primaryError: String? = null
        val choices = mutableListOf<StreamChoice>()
        val captions = mutableListOf<CaptionTrack>()
        var title = ""
        var uploader = ""

        // 1. Primary Native Engine: Official TeamNewPipe NewPipeExtractor (decrypts signatureCipher & n-throttling locally!)
        try {
            val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$videoId")
            title = info.name ?: ""
            uploader = info.uploaderName ?: ""

            // Find best compatible M4A (AAC) audio and best WebM (Opus) audio
            val allAudios = info.audioStreams
                .filter { it.isUrl && (it.content ?: "").startsWith("http") && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }

            val bestM4aAudio = allAudios
                .filter { (it.format?.mimeType ?: "").contains("mp4", ignoreCase = true) }
                .maxByOrNull { it.averageBitrate }
            val bestWebmAudio = allAudios
                .filter { (it.format?.mimeType ?: "").contains("webm", ignoreCase = true) }
                .maxByOrNull { it.averageBitrate }
            val anyBestAudio = bestM4aAudio ?: bestWebmAudio ?: allAudios.maxByOrNull { it.averageBitrate }

            // Collect Adaptive Video-Only HD Streams (1440p / 1080p / 720p / 480p / 360p / 240p)
            data class CandidateVid(
                val height: Int,
                val label: String,
                val url: String,
                val isMp4Avc: Boolean,
                val isWebm: Boolean,
                val bitrate: Int
            )

            val adaptiveVids = info.videoOnlyStreams
                .filter { it.isUrl && (it.content ?: "").startsWith("http") && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
                .mapNotNull { vs ->
                    val h = if (vs.height > 0) vs.height
                    else (vs.resolution ?: "").substringBefore("p").filter { it.isDigit() }.toIntOrNull() ?: 0
                    if (h !in 144..1440) return@mapNotNull null
                    val mime = (vs.format?.mimeType ?: "").lowercase()
                    val isMp4 = mime.contains("mp4")
                    val isWebm = mime.contains("webm")
                    val lbl = (vs.resolution ?: "").takeIf { it.isNotBlank() } ?: "${h}p"
                    CandidateVid(h, lbl, (vs.content ?: ""), isMp4, isWebm, vs.bitrate)
                }

            if (anyBestAudio != null && adaptiveVids.isNotEmpty()) {
                val grouped = adaptiveVids.groupBy { it.height }
                val heights = grouped.keys.sortedDescending()
                for (h in heights) {
                    val bestForH = grouped[h]!!
                        .sortedWith(compareByDescending<CandidateVid> { it.isMp4Avc }.thenByDescending { it.bitrate })
                        .first()
                    val matchedAudio = when {
                        bestForH.isMp4Avc && bestM4aAudio != null -> (bestM4aAudio.content ?: "")
                        bestForH.isWebm && bestWebmAudio != null -> (bestWebmAudio.content ?: "")
                        else -> (anyBestAudio.content ?: "")
                    }
                    choices.add(
                        StreamChoice(
                            label = "${h}p",
                            height = h,
                            videoUrl = bestForH.url,
                            audioUrl = matchedAudio,
                            isHls = false,
                            sourceTag = "HD"
                        )
                    )
                }
            }

            // Add HLS stream if available (great for live streams or iOS adaptive playback)
            val hlsUrl = info.hlsUrl
            if (!hlsUrl.isNullOrBlank() && hlsUrl.startsWith("http")) {
                choices.add(
                    StreamChoice(
                        label = "Auto HD",
                        height = 1080,
                        videoUrl = hlsUrl,
                        audioUrl = null,
                        isHls = true,
                        sourceTag = "HLS"
                    )
                )
            }

            // Add Progressive Muxed MP4 fallback streams (single URL with video+audio)
            val muxed = info.videoStreams
                .filter { it.isUrl && (it.content ?: "").startsWith("http") && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
                .sortedByDescending { it.height }

            for (vs in muxed) {
                val h = if (vs.height > 0) vs.height
                else (vs.resolution ?: "").substringBefore("p").filter { it.isDigit() }.toIntOrNull() ?: 360
                choices.add(
                    StreamChoice(
                        label = "${h}p",
                        height = h,
                        videoUrl = (vs.content ?: ""),
                        audioUrl = null,
                        isHls = false,
                        sourceTag = "MP4"
                    )
                )
            }

            // Extract Captions / Subtitles
            val seenLangs = mutableSetOf<String>()
            for (sub in info.subtitles) {
                val rawUrl = sub.content ?: ""
                if (!sub.isUrl || !rawUrl.startsWith("http")) continue
                val code = (sub.languageTag ?: "").ifBlank { "und" }
                if (!seenLangs.add(code)) continue
                                val vttUrl = when {
                    rawUrl.contains("fmt=vtt") -> rawUrl
                    rawUrl.contains("fmt=") -> rawUrl.replace(Regex("fmt=[^&]+"), "fmt=vtt")
                    rawUrl.contains("?") -> "$rawUrl&fmt=vtt"
                    else -> "$rawUrl?fmt=vtt"
                }
                val label = (sub.displayLanguageName ?: "").ifBlank { code.uppercase() }
                captions.add(
                    CaptionTrack(
                        label = label,
                        languageCode = code,
                        url = vttUrl,
                        mimeType = "text/vtt"
                    )
                )
            }
        } catch (e: Exception) {
            primaryError = e.message ?: e.javaClass.simpleName
        }

        // 2. Native Backup Fallback (Piped API) — only if NewPipeExtractor returned nothing
        if (choices.isEmpty()) {
            val piped = extractViaPipedBackup(videoId, captions)
            if (piped.isNotEmpty()) {
                choices.addAll(piped)
            }
        }

        // Deduplicate choices cleanly while preserving backup entries
        val cleanChoices = choices.distinctBy { "${it.label}_${it.sourceTag}" }

        ExtractedVideoStreams(
            choices = cleanChoices,
            captions = captions,
            title = title,
            channelName = uploader,
            errorMessage = if (cleanChoices.isEmpty()) {
                primaryError ?: "تعذّر استخراج روابط الفيديو، اضغط إعادة المحاولة."
            } else null
        )
    }

    private fun extractViaPipedBackup(
        videoId: String,
        captionsOut: MutableList<CaptionTrack>
    ): List<StreamChoice> {
        val hosts = listOf(
            "https://api.piped.private.coffee",
            "https://pipedapi.kavin.rocks",
            "https://pipedapi.adminforge.de"
        )
        for (host in hosts) {
            try {
                val req = okhttp3.Request.Builder()
                    .url("$host/streams/$videoId")
                    .header("User-Agent", CHROME_UA)
                    .build()
                val json = playerOkHttpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) null else resp.body?.string()?.let { JSONObject(it) }
                } ?: continue

                val out = mutableListOf<StreamChoice>()
                val hls = json.optString("hls")
                if (hls.startsWith("http")) {
                    out.add(StreamChoice("Auto HD", 1080, hls, null, isHls = true, sourceTag = "HLS"))
                }

                var bestAudio: String? = null
                var bestBr = -1
                val audios = json.optJSONArray("audioStreams")
                if (audios != null) {
                    for (i in 0 until audios.length()) {
                        val a = audios.optJSONObject(i) ?: continue
                        val u = a.optString("url")
                        val br = a.optInt("bitrate", 0)
                        if (u.startsWith("http") && br > bestBr) {
                            bestBr = br
                            bestAudio = u
                        }
                    }
                }

                val vids = json.optJSONArray("videoStreams")
                if (vids != null) {
                    val seenH = mutableSetOf<Int>()
                    for (i in 0 until vids.length()) {
                        val v = vids.optJSONObject(i) ?: continue
                        val u = v.optString("url")
                        if (!u.startsWith("http")) continue
                        val h = v.optInt("height", 0)
                        val videoOnly = v.optBoolean("videoOnly", true)
                        if (h in 240..1440 && seenH.add(h)) {
                            if (!videoOnly) {
                                out.add(StreamChoice("${h}p", h, u, null, sourceTag = "MP4"))
                            } else if (bestAudio != null) {
                                out.add(StreamChoice("${h}p", h, u, bestAudio, sourceTag = "HD"))
                            }
                        }
                    }
                }

                val subs = json.optJSONArray("subtitles")
                if (subs != null && captionsOut.isEmpty()) {
                    for (i in 0 until subs.length()) {
                        val s = subs.optJSONObject(i) ?: continue
                        val u = s.optString("url")
                        val code = s.optString("code").ifBlank { "sub_$i" }
                        val name = s.optString("name").ifBlank { code }
                        if (u.startsWith("http")) {
                            captionsOut.add(CaptionTrack(name, code, u))
                        }
                    }
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }
}
