package com.cinema.youtube.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.ClosedCaptionOff
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.rounded.ThumbUpOffAlt
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.SingleSampleMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.cinema.youtube.data.InnerTubeClient
import com.cinema.youtube.data.NativeStreamEngine
import com.cinema.youtube.model.CaptionTrack
import com.cinema.youtube.model.CommentItem
import com.cinema.youtube.model.GoogleSession
import com.cinema.youtube.model.StreamChoice
import com.cinema.youtube.model.SubscribedChannel
import com.cinema.youtube.model.UserPlaylist
import com.cinema.youtube.model.VideoDetails
import com.cinema.youtube.model.VideoItem
import kotlinx.coroutines.delay

private enum class TabletWatchTab { UP_NEXT, COMMENTS, DETAILS }

@OptIn(UnstableApi::class)
@Composable
fun WatchScreen(
    video: VideoItem,
    initialPositionSec: Long,
    gl: String,
    hl: String,
    session: GoogleSession?,
    isTablet: Boolean,
    isLandscape: Boolean,
    isInPipMode: Boolean,
    isLiked: Boolean,
    isSubscribed: (String) -> Boolean,
    playlists: List<UserPlaylist>,
    onToggleLike: (String) -> Unit,
    onSetLandscape: (Boolean) -> Unit,
    onEnterPip: () -> Unit,
    onBack: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onOpenChannel: (String) -> Unit,
    onToggleSubscribe: (SubscribedChannel) -> Unit,
    onToggleVideoInPlaylist: (String, VideoItem) -> Unit,
    onSaveProgress: (VideoItem, Long, Long) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    var details by remember(video.id) { mutableStateOf<VideoDetails?>(null) }
    var comments by remember(video.id) { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsLoaded by remember(video.id) { mutableStateOf(false) }

    // 100% Native Stream & ExoPlayer State (ZERO WebView!)
    var streams by remember(video.id) { mutableStateOf<List<StreamChoice>>(emptyList()) }
    var captions by remember(video.id) { mutableStateOf<List<CaptionTrack>>(emptyList()) }
    var selectedCaption by remember(video.id) { mutableStateOf<CaptionTrack?>(null) }
    var currentStreamIndex by remember(video.id) { mutableIntStateOf(0) }
    var extracting by remember(video.id) { mutableStateOf(true) }
    var streamError by remember(video.id) { mutableStateOf<String?>(null) }
    var reloadNonce by remember(video.id) { mutableIntStateOf(0) }

    var hasRenderedFrame by remember(video.id) { mutableStateOf(false) }
    var isPlaying by remember(video.id) { mutableStateOf(false) }
    var isBuffering by remember(video.id) { mutableStateOf(true) }
    var positionMs by remember(video.id) { mutableLongStateOf(initialPositionSec * 1000L) }
    var durationMs by remember(video.id) { mutableLongStateOf(0L) }
    var bufferedMs by remember(video.id) { mutableLongStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var sliderFraction by remember(video.id) { mutableFloatStateOf(0f) }
    var restoredInitialSeek by remember(video.id) { mutableStateOf(false) }

    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var isBoost2x by remember { mutableStateOf(false) }
    var isZoomFill by remember { mutableStateOf(false) }

    var showControls by remember(video.id) { mutableStateOf(true) }
    var showPlayerSettings by remember { mutableStateOf(false) }
    var showCommentsSheet by remember(video.id) { mutableStateOf(false) }
    var showDescriptionSheet by remember(video.id) { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var tabletTab by remember { mutableStateOf(TabletWatchTab.UP_NEXT) }
    var useFallbackThumb by remember(video.id) { mutableStateOf(false) }

    // Gesture feedback states
    var doubleTapSide by remember { mutableIntStateOf(0) }
    var doubleTapSeconds by remember { mutableIntStateOf(0) }
    var doubleTapNonce by remember { mutableIntStateOf(0) }

    var gestureType by remember { mutableIntStateOf(0) }
    var gesturePercent by remember { mutableFloatStateOf(0.5f) }
    var gestureNonce by remember { mutableIntStateOf(0) }

    val latestDetails by rememberUpdatedState(details)
    val latestOnOpenVideo by rememberUpdatedState(onOpenVideo)

    LaunchedEffect(doubleTapNonce) {
        if (doubleTapNonce > 0) {
            delay(800)
            doubleTapSide = 0
            doubleTapSeconds = 0
        }
    }

    LaunchedEffect(gestureNonce) {
        if (gestureNonce > 0) {
            delay(750)
            gestureType = 0
        }
    }

    // Fast-start Hardware Media3 ExoPlayer with OkHttp HTTP/2 DataSource
    val dataSourceFactory = remember {
        OkHttpDataSource.Factory(NativeStreamEngine.playerOkHttpClient)
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36")
    }

    val exoPlayer = remember(context) {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .build()
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply {
                playWhenReady = true
            }
    }

    fun playChoice(choice: StreamChoice, seekMs: Long, captionTrack: CaptionTrack? = selectedCaption) {
        val baseSource = when {
            choice.isHls -> {
                HlsMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
            choice.isDash -> {
                DashMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
            !choice.audioUrl.isNullOrBlank() -> {
                val vidSrc = ProgressiveMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
                val audSrc = ProgressiveMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(choice.audioUrl))
                MergingMediaSource(vidSrc, audSrc)
            }
            else -> {
                ProgressiveMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(choice.videoUrl))
            }
        }

        val finalSource = if (captionTrack != null && captionTrack.url.startsWith("http")) {
            val subConfig = MediaItem.SubtitleConfiguration.Builder(Uri.parse(captionTrack.url))
                .setMimeType(MimeTypes.TEXT_VTT)
                .setLanguage(captionTrack.languageCode)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            val subSource = SingleSampleMediaSource.Factory(dataSourceFactory)
                .createMediaSource(subConfig, C.TIME_UNSET)
            MergingMediaSource(baseSource, subSource)
        } else {
            baseSource
        }

        exoPlayer.setMediaSource(finalSource)
        exoPlayer.prepare()
        if (seekMs > 2_000L) {
            exoPlayer.seekTo(seekMs)
        }
        exoPlayer.playbackParameters = PlaybackParameters(if (isBoost2x) 2f else playbackSpeed)
        exoPlayer.playWhenReady = true
    }

    // ExoPlayer Listener with automatic stream fallback + auto-next on video end
    DisposableEffect(exoPlayer, streams, currentStreamIndex, selectedCaption) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onRenderedFirstFrame() {
                hasRenderedFrame = true
                isBuffering = false
            }

            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_READY && exoPlayer.duration > 0) {
                    durationMs = exoPlayer.duration
                }
                if (state == Player.STATE_ENDED) {
                    val next = latestDetails?.relatedVideos?.firstOrNull()
                    if (next != null) {
                        latestOnOpenVideo(next)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val resumeMs = exoPlayer.currentPosition.coerceAtLeast(positionMs)
                if (selectedCaption != null && currentStreamIndex in streams.indices) {
                    selectedCaption = null
                    playChoice(streams[currentStreamIndex], resumeMs, null)
                    return
                }
                val nextIdx = currentStreamIndex + 1
                if (nextIdx < streams.size) {
                    currentStreamIndex = nextIdx
                    playChoice(streams[nextIdx], resumeMs, null)
                } else {
                    isBuffering = false
                    streamError = "تعذّر تشغيل الفيديو (${error.errorCodeName}). اضغط إعادة المحاولة."
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Save progress when leaving video
    DisposableEffect(video.id) {
        onDispose {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (pos > 2_000L && dur > 5_000L) {
                val d = latestDetails
                onSaveProgress(
                    video.copy(
                        title = d?.title?.ifBlank { video.title } ?: video.title,
                        channelName = d?.channelName?.ifBlank { video.channelName } ?: video.channelName,
                        channelId = d?.channelId?.ifBlank { video.channelId } ?: video.channelId,
                        channelAvatar = d?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
                    ),
                    pos,
                    dur
                )
            }
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    // Extract Native Streams via NewPipeExtractor (ZERO WebView!)
    LaunchedEffect(video.id, reloadNonce) {
        extracting = true
        streamError = null
        hasRenderedFrame = false
        isBuffering = true
        durationMs = 0L
        bufferedMs = 0L
        sliderFraction = 0f
        exoPlayer.stop()

        val extracted = NativeStreamEngine.extractStreams(video.id)
        extracting = false
        captions = extracted.captions

        if (extracted.choices.isEmpty()) {
            isBuffering = false
            streamError = extracted.errorMessage ?: "لم يتم العثور على روابط تشغيل لهذا الفيديو."
        } else {
            streams = extracted.choices
            // Default to crisp 720p HD (or Auto HD HLS, or first available) for instant smooth start
            val preferredIdx = extracted.choices.indexOfFirst { !it.isHls && it.height == 720 }
                .takeIf { it >= 0 }
                ?: extracted.choices.indexOfFirst { it.isHls || it.height in 480..1080 }
                    .takeIf { it >= 0 }
                ?: 0
            currentStreamIndex = preferredIdx
            val seekTarget = if (!restoredInitialSeek) {
                restoredInitialSeek = true
                initialPositionSec * 1000L
            } else positionMs
            playChoice(extracted.choices[preferredIdx], seekTarget, null)
        }
    }

    // Fetch Native Metadata, Related Videos & Comments in parallel
    LaunchedEffect(video.id) {
        details = InnerTubeClient.fetchWatchDetails(video.id, gl, hl, session)
        val token = details?.commentsContinuation
        if (!token.isNullOrBlank()) {
            comments = InnerTubeClient.fetchComments(token, gl, hl)
            commentsLoaded = true
        }
    }

    // Poll ExoPlayer progress smoothly every 400ms + periodic history save
    LaunchedEffect(video.id, exoPlayer) {
        var tick = 0
        while (true) {
            delay(400)
            if (!isSeeking) {
                positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                bufferedMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
                if (exoPlayer.duration > 0) {
                    durationMs = exoPlayer.duration
                    sliderFraction = (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                }
            }
            tick++
            if (tick % 16 == 0 && durationMs > 5_000L && isPlaying) {
                val d = latestDetails
                onSaveProgress(
                    video.copy(
                        title = d?.title?.ifBlank { video.title } ?: video.title,
                        channelName = d?.channelName?.ifBlank { video.channelName } ?: video.channelName,
                        channelId = d?.channelId?.ifBlank { video.channelId } ?: video.channelId,
                        channelAvatar = d?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
                    ),
                    positionMs,
                    durationMs
                )
            }
        }
    }

    // Auto-hide HUD after 3.2s when playing
    LaunchedEffect(showControls, isPlaying, isSeeking, showPlayerSettings, hasRenderedFrame) {
        if (showControls && isPlaying && hasRenderedFrame && !isSeeking && !showPlayerSettings) {
            delay(3200)
            showControls = false
        }
    }

    val displayTitle = details?.title?.ifBlank { video.title } ?: video.title
    val displayChannel = details?.channelName?.ifBlank { video.channelName } ?: video.channelName
    val displayChannelId = details?.channelId?.ifBlank { video.channelId } ?: video.channelId
    val displayAvatar = details?.channelAvatar?.ifBlank { video.channelAvatar } ?: video.channelAvatar
    val relatedVideos = details?.relatedVideos ?: emptyList()
    val activeQualityLabel = streams.getOrNull(currentStreamIndex)?.label ?: "HD"

    fun shareCurrentVideo() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, displayTitle)
            putExtra(Intent.EXTRA_TEXT, "$displayTitle\nhttps://youtu.be/${video.id}")
        }
        runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share video")) }
    }

    // ---------- 100% NATIVE HARDWARE EXOPLAYER VIEWPORT ----------
    val nativePlayerBox: @Composable (Modifier) -> Unit = { boxModifier ->
        Box(
            modifier = boxModifier
                .background(Color.Black)
                .pointerInput(video.id, isInPipMode) {
                    if (isInPipMode) return@pointerInput
                    detectTapGestures(
                        onPress = {
                            tryAwaitRelease()
                            if (isBoost2x) {
                                isBoost2x = false
                                exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
                            }
                        },
                        onLongPress = {
                            if (isPlaying) {
                                isBoost2x = true
                                exoPlayer.playbackParameters = PlaybackParameters(2f)
                            }
                        },
                        onTap = {
                            showControls = !showControls
                        },
                        onDoubleTap = { offset ->
                            val isRight = offset.x >= size.width / 2f
                            val deltaMs = if (isRight) 10_000L else -10_000L
                            val target = (exoPlayer.currentPosition + deltaMs).coerceIn(
                                0L,
                                if (durationMs > 0L) durationMs else Long.MAX_VALUE
                            )
                            exoPlayer.seekTo(target)
                            positionMs = target
                            val side = if (isRight) 1 else -1
                            doubleTapSeconds = if (doubleTapSide == side) doubleTapSeconds + 10 else 10
                            doubleTapSide = side
                            doubleTapNonce++
                        }
                    )
                }
                .pointerInput(video.id, isInPipMode) {
                    if (isInPipMode) return@pointerInput
                    var dragMode = 0
                    var accumDelta = 0f
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            accumDelta = 0f
                            dragMode = when {
                                offset.x < size.width * 0.40f -> 1
                                offset.x > size.width * 0.60f -> 2
                                else -> 0
                            }
                        },
                        onVerticalDrag = { _, dragAmount ->
                            if (dragMode == 1 && activity != null) {
                                val lp = activity.window.attributes
                                val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                val next = (cur - dragAmount / (size.height.coerceAtLeast(300) * 1.1f)).coerceIn(0.05f, 1f)
                                lp.screenBrightness = next
                                activity.window.attributes = lp
                                gestureType = 1
                                gesturePercent = next
                                gestureNonce++
                            } else if (dragMode == 2 && audioManager != null) {
                                accumDelta -= dragAmount
                                val stepPx = (size.height.coerceAtLeast(300) / 16f)
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                var curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                if (kotlin.math.abs(accumDelta) >= stepPx) {
                                    val steps = (accumDelta / stepPx).toInt()
                                    accumDelta -= steps * stepPx
                                    curVol = (curVol + steps).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, curVol, 0)
                                }
                                gestureType = 2
                                gesturePercent = curVol.toFloat() / maxVol.toFloat()
                                gestureNonce++
                            }
                        }
                    )
                }
        ) {
            // Layer 1: Native Hardware-Accelerated Media3 PlayerView (Zero WebView!)
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = if (isZoomFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                        keepScreenOn = true
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { pv ->
                    if (pv.player !== exoPlayer) pv.player = exoPlayer
                    val desired = if (isZoomFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                    if (pv.resizeMode != desired) pv.resizeMode = desired
                }
            )

            // Layer 2: Crisp Video Thumbnail Backdrop until First Hardware Video Frame Renders
            if (!hasRenderedFrame) {
                AsyncImage(
                    model = if (useFallbackThumb) video.thumbnailUrl else video.heroThumbnailUrl,
                    contentDescription = displayTitle,
                    contentScale = ContentScale.Crop,
                    onError = { useFallbackThumb = true },
                    modifier = Modifier.fillMaxSize()
                )
                Box(modifier = Modifier.fillMaxSize().background(Color(0x66000000)))
            }

            // In Picture-in-Picture mode, render pure video with zero overlays!
            if (isInPipMode) return@Box

            // Layer 3: Hold-for-2x Speed Badge
            AnimatedVisibility(
                visible = isBoost2x,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
            ) {
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text("2x", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Rounded.FastForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Layer 4: Double-Tap ±10s Seek Pill
            AnimatedVisibility(
                visible = doubleTapSide != 0,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(if (doubleTapSide < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 28.dp)
            ) {
                Surface(
                    color = Color(0xBA000000),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp)
                    ) {
                        Icon(
                            imageVector = if (doubleTapSide < 0) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Text("${doubleTapSeconds}s", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Layer 5: Brightness / Volume Swipe HUD
            AnimatedVisibility(
                visible = gestureType != 0,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Surface(
                    color = Color(0xCC121216),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp)
                    ) {
                        Icon(
                            imageVector = if (gestureType == 1) Icons.Rounded.Brightness6 else Icons.Rounded.VolumeUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Box(
                            modifier = Modifier.width(105.dp).height(5.dp).clip(RoundedCornerShape(999.dp)).background(Color(0x40FFFFFF))
                        ) {
                            Box(
                                modifier = Modifier.fillMaxHeight().fillMaxWidth(gesturePercent.coerceIn(0f, 1f)).background(Color.White)
                            )
                        }
                        Text("${(gesturePercent * 100).toInt()}%", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Layer 6: Error Recovery Card (only if all streams failed)
            if (streamError != null) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier.align(Alignment.Center).padding(16.dp).widthIn(max = 310.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = streamError ?: "",
                            color = CinemaColors.TextPrimary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 3
                        )
                        Button(
                            onClick = { reloadNonce++ },
                            shape = RoundedCornerShape(999.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إعادة المحاولة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Layer 7: Native Pro Cinema Player HUD
            AnimatedVisibility(
                visible = (showControls || !hasRenderedFrame || !isPlaying) && streamError == null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isLandscape) 96.dp else 64.dp)
                            .align(Alignment.TopCenter)
                            .background(Brush.verticalGradient(listOf(Color(0xC8000000), Color.Transparent)))
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isLandscape) 124.dp else 82.dp)
                            .align(Alignment.BottomCenter)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD8000000))))
                    )

                    // Top Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (isLandscape) Modifier.statusBarsPadding() else Modifier)
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .align(Alignment.TopCenter),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            PlayerGlassIcon(
                                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                size = if (isLandscape) 40.dp else 34.dp,
                                onClick = { if (isLandscape) onSetLandscape(false) else onBack() }
                            )
                            if (isLandscape) {
                                Text(
                                    text = displayTitle,
                                    color = Color.White,
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 360.dp)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (captions.isNotEmpty()) {
                                PlayerGlassIcon(
                                    icon = if (selectedCaption != null) Icons.Rounded.ClosedCaption else Icons.Rounded.ClosedCaptionOff,
                                    contentDescription = "Captions",
                                    size = if (isLandscape) 38.dp else 33.dp,
                                    tint = if (selectedCaption != null) CinemaColors.YtRed else Color.White,
                                    onClick = {
                                        val nextCap = if (selectedCaption == null) {
                                            captions.firstOrNull { it.languageCode.startsWith(hl) } ?: captions.first()
                                        } else null
                                        selectedCaption = nextCap
                                        if (currentStreamIndex in streams.indices) {
                                            playChoice(streams[currentStreamIndex], exoPlayer.currentPosition, nextCap)
                                        }
                                    }
                                )
                            }
                            PlayerGlassIcon(
                                icon = Icons.Rounded.PictureInPictureAlt,
                                contentDescription = "PiP",
                                size = if (isLandscape) 38.dp else 33.dp,
                                onClick = onEnterPip
                            )
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Settings,
                                contentDescription = "Settings",
                                size = if (isLandscape) 38.dp else 33.dp,
                                onClick = { showPlayerSettings = true }
                            )
                        }
                    }

                    // Center Controls: -10s | Play/Pause (or Spinner) | +10s | Next
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(if (isLandscape) 28.dp else 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (hasRenderedFrame) {
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Replay10,
                                contentDescription = "-10s",
                                size = if (isLandscape) 48.dp else 40.dp,
                                onClick = {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L))
                                }
                            )
                        }

                        Surface(
                            color = Color(0xF2FFFFFF),
                            shape = CircleShape,
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .size(if (isLandscape) 62.dp else 54.dp)
                                .clickable {
                                    if (!extracting && streams.isNotEmpty()) {
                                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                    }
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (extracting || isBuffering) {
                                    CircularProgressIndicator(color = Color.Black, strokeWidth = 2.8.dp, modifier = Modifier.size(26.dp))
                                } else {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.Black,
                                        modifier = Modifier.size(if (isLandscape) 34.dp else 30.dp)
                                    )
                                }
                            }
                        }

                        if (hasRenderedFrame) {
                            PlayerGlassIcon(
                                icon = Icons.Rounded.Forward10,
                                contentDescription = "+10s",
                                size = if (isLandscape) 48.dp else 40.dp,
                                onClick = {
                                    val target = exoPlayer.currentPosition + 10_000L
                                    exoPlayer.seekTo(if (durationMs > 0) target.coerceAtMost(durationMs) else target)
                                }
                            )
                            if (isLandscape && relatedVideos.isNotEmpty()) {
                                PlayerGlassIcon(
                                    icon = Icons.Rounded.SkipNext,
                                    contentDescription = "Next",
                                    size = 44.dp,
                                    onClick = { onOpenVideo(relatedVideos.first()) }
                                )
                            }
                        }
                    }

                    // Bottom Bar: Live Time + Speed/Quality + Fullscreen + Red Seekbar with Buffer Track
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(
                                horizontal = if (isLandscape) 18.dp else 10.dp,
                                vertical = if (isLandscape) 12.dp else 4.dp
                            )
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${formatPlayerTime(positionMs)} / ${formatPlayerTime(durationMs)}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (isLandscape) {
                                    PlayerMiniPill(
                                        text = if (isZoomFill) "Fill" else "Fit",
                                        onClick = { isZoomFill = !isZoomFill }
                                    )
                                }
                                PlayerMiniPill(
                                    text = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                    onClick = { showPlayerSettings = true }
                                )
                                PlayerMiniPill(
                                    text = activeQualityLabel,
                                    onClick = { showPlayerSettings = true }
                                )
                                Icon(
                                    imageVector = if (isLandscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                    contentDescription = "Fullscreen",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .clickable { onSetLandscape(!isLandscape) }
                                        .padding(5.dp)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier.fillMaxWidth().height(26.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (durationMs > 0L && bufferedMs > 0L) {
                                val bufFrac = (bufferedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(Color(0x33FFFFFF))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth(bufFrac)
                                            .background(Color(0x66FFFFFF))
                                    )
                                }
                            }
                            Slider(
                                value = sliderFraction,
                                onValueChange = { v ->
                                    isSeeking = true
                                    sliderFraction = v
                                    if (durationMs > 0L) positionMs = (v * durationMs).toLong()
                                },
                                onValueChangeFinished = {
                                    if (durationMs > 0L) {
                                        val seekMs = (sliderFraction * durationMs).toLong()
                                        exoPlayer.seekTo(seekMs)
                                        positionMs = seekMs
                                    }
                                    isSeeking = false
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = CinemaColors.YtRed,
                                    activeTrackColor = CinemaColors.YtRed,
                                    inactiveTrackColor = Color(0x40FFFFFF)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }

    // ---------- ADAPTIVE LAYOUT (Tablet Split vs Mobile Portrait vs Fullscreen/PiP) ----------
    val showSideBySideTablet = isTablet && !isLandscape && !isInPipMode
    val showFullScreenOnly = isLandscape || isInPipMode

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaColors.BgBlack)
    ) {
        if (showSideBySideTablet) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(top = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.64f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                        .padding(start = 18.dp, end = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    nativePlayerBox(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(18.dp))
                    )

                    WatchInfoSection(
                        displayTitle = displayTitle,
                        displayChannel = displayChannel,
                        displayChannelId = displayChannelId,
                        displayAvatar = displayAvatar,
                        details = details,
                        isLiked = isLiked,
                        isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                        qualityLabel = activeQualityLabel,
                        speedLabel = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                        onOpenDescription = { tabletTab = TabletWatchTab.DETAILS },
                        onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                        onToggleSubscribe = {
                            if (displayChannelId.isNotBlank()) {
                                onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                            }
                        },
                        onToggleLike = { onToggleLike(video.id) },
                        onSave = { showPlaylistDialog = true },
                        onShare = { shareCurrentVideo() },
                        onOpenPlayerSettings = { showPlayerSettings = true }
                    )
                }

                Surface(
                    color = CinemaColors.SurfaceDark,
                    shape = RoundedCornerShape(topStart = 20.dp),
                    border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                    modifier = Modifier
                        .weight(0.36f)
                        .fillMaxHeight()
                        .padding(end = 12.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                TabletWatchTab.UP_NEXT to "Up next",
                                TabletWatchTab.COMMENTS to "Comments",
                                TabletWatchTab.DETAILS to "Details"
                            ).forEach { (tab, label) ->
                                val active = tabletTab == tab
                                Surface(
                                    color = if (active) Color.White else Color(0x1AFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.weight(1f).clickable { tabletTab = tab }
                                ) {
                                    Text(
                                        text = label,
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 8.dp)
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = CinemaColors.DividerSubtle)
                        Box(modifier = Modifier.weight(1f)) {
                            when (tabletTab) {
                                TabletWatchTab.UP_NEXT -> UpNextCompactList(relatedVideos, onOpenVideo)
                                TabletWatchTab.COMMENTS -> CommentsListBody(comments, !commentsLoaded && details?.commentsContinuation != null)
                                TabletWatchTab.DETAILS -> DescriptionBody(details)
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (!showFullScreenOnly) Modifier.statusBarsPadding() else Modifier)
            ) {
                nativePlayerBox(
                    if (showFullScreenOnly) {
                        Modifier.fillMaxSize()
                    } else {
                        Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    }
                )

                if (!showFullScreenOnly) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .navigationBarsPadding(),
                        contentPadding = PaddingValues(bottom = 28.dp)
                    ) {
                        item(key = "watch_info") {
                            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                                WatchInfoSection(
                                    displayTitle = displayTitle,
                                    displayChannel = displayChannel,
                                    displayChannelId = displayChannelId,
                                    displayAvatar = displayAvatar,
                                    details = details,
                                    isLiked = isLiked,
                                    isSubscribed = displayChannelId.isNotBlank() && isSubscribed(displayChannelId),
                                    qualityLabel = activeQualityLabel,
                                    speedLabel = "${if (playbackSpeed == 1f) "1" else playbackSpeed}x",
                                    onOpenDescription = { showDescriptionSheet = true },
                                    onOpenChannel = { if (displayChannelId.isNotBlank()) onOpenChannel(displayChannelId) },
                                    onToggleSubscribe = {
                                        if (displayChannelId.isNotBlank()) {
                                            onToggleSubscribe(SubscribedChannel(displayChannelId, displayChannel, displayAvatar))
                                        }
                                    },
                                    onToggleLike = { onToggleLike(video.id) },
                                    onSave = { showPlaylistDialog = true },
                                    onShare = { shareCurrentVideo() },
                                    onOpenPlayerSettings = { showPlayerSettings = true }
                                )
                            }
                        }

                        item(key = "comments_preview") {
                            Surface(
                                color = CinemaColors.SurfaceDark,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, CinemaColors.DividerSubtle),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp)
                                    .clickable { showCommentsSheet = true }
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (comments.isNotEmpty()) "Comments (${comments.size}+)" else "Comments",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text("View all", color = CinemaColors.TextSecondary, fontSize = 12.sp)
                                    }
                                    val top = comments.firstOrNull()
                                    if (top != null) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            ChannelAvatar(url = top.avatarUrl, name = top.author, size = 26.dp)
                                            Text(
                                                text = top.text,
                                                color = CinemaColors.TextPrimary,
                                                fontSize = 12.5.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = if (!commentsLoaded && details?.commentsContinuation != null) "Loading comments..." else "Tap to read comments",
                                            color = CinemaColors.TextSecondary,
                                            fontSize = 12.5.sp
                                        )
                                    }
                                }
                            }
                        }

                        item(key = "up_next_header") {
                            Text(
                                text = "Up next",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 10.dp)
                            )
                        }

                        if (relatedVideos.isEmpty()) {
                            item(key = "up_next_spinner") {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
                                }
                            }
                        } else {
                            items(relatedVideos, key = { "rel_${it.id}" }) { rel ->
                                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                    CinemaVideoCard(item = rel, showAvatar = true, onClick = { onOpenVideo(rel) })
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---------- NATIVE PLAYER SETTINGS MODAL (Quality / Speed / Captions / Fit) ----------
        if (showPlayerSettings) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlayerSettings = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(20.dp)
                        .widthIn(max = 400.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Player Settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp).clip(CircleShape).clickable { showPlayerSettings = false }.padding(3.dp)
                            )
                        }

                        Text("Quality", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(streams.indices.toList()) { idx ->
                                val ch = streams[idx]
                                val active = idx == currentStreamIndex
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        currentStreamIndex = idx
                                        playChoice(ch, exoPlayer.currentPosition, selectedCaption)
                                        showPlayerSettings = false
                                    }
                                ) {
                                    Text(
                                        text = "${ch.label} · ${ch.sourceTag}",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CinemaColors.DividerSubtle)

                        Text("Playback Speed", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)) { sp ->
                                val active = playbackSpeed == sp
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        playbackSpeed = sp
                                        exoPlayer.playbackParameters = PlaybackParameters(sp)
                                    }
                                ) {
                                    Text(
                                        text = if (sp == 1f) "Normal" else "${sp}x",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CinemaColors.DividerSubtle)

                        Text("Captions (Subtitles)", color = CinemaColors.TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                val active = selectedCaption == null
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        selectedCaption = null
                                        if (currentStreamIndex in streams.indices) {
                                            playChoice(streams[currentStreamIndex], exoPlayer.currentPosition, null)
                                        }
                                    }
                                ) {
                                    Text(
                                        text = "Off",
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                            items(captions) { cap ->
                                val active = selectedCaption?.languageCode == cap.languageCode
                                Surface(
                                    color = if (active) Color.White else Color(0x1EFFFFFF),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.clickable {
                                        selectedCaption = cap
                                        if (currentStreamIndex in streams.indices) {
                                            playChoice(streams[currentStreamIndex], exoPlayer.currentPosition, cap)
                                        }
                                        showPlayerSettings = false
                                    }
                                ) {
                                    Text(
                                        text = cap.label,
                                        color = if (active) Color.Black else Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CinemaColors.DividerSubtle)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Rounded.AspectRatio, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Text("Video Fit", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(false to "Fit", true to "Zoom Fill").forEach { (zoom, label) ->
                                    val active = isZoomFill == zoom
                                    Surface(
                                        color = if (active) Color.White else Color(0x1EFFFFFF),
                                        shape = RoundedCornerShape(999.dp),
                                        modifier = Modifier.clickable { isZoomFill = zoom }
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (active) Color.Black else Color.White,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showCommentsSheet) {
            WatchSheetOverlay(title = "Comments", onDismiss = { showCommentsSheet = false }) {
                CommentsListBody(comments, !commentsLoaded && details?.commentsContinuation != null)
            }
        }

        if (showDescriptionSheet) {
            WatchSheetOverlay(title = "Description", onDismiss = { showDescriptionSheet = false }) {
                DescriptionBody(details)
            }
        }

        if (showPlaylistDialog) {
            val localPlaylists = playlists.filterNot { it.isRemote }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable { showPlaylistDialog = false },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = CinemaColors.GlassStrong,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, CinemaColors.GlassStroke),
                    modifier = Modifier
                        .padding(24.dp)
                        .widthIn(max = 320.dp)
                        .fillMaxWidth()
                        .clickable(enabled = false) {}
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Save to Playlist", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        val richVideo = video.copy(
                            title = displayTitle,
                            channelName = displayChannel,
                            channelId = displayChannelId,
                            channelAvatar = displayAvatar
                        )
                        localPlaylists.forEach { pl ->
                            val saved = pl.videos.any { it.id == video.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x14FFFFFF))
                                    .clickable { onToggleVideoInPlaylist(pl.id, richVideo) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(pl.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                if (saved) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerGlassIcon(
    icon: ImageVector,
    contentDescription: String,
    size: Dp = 38.dp,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Surface(
        color = Color(0x99121216),
        shape = CircleShape,
        border = BorderStroke(1.dp, Color(0x28FFFFFF)),
        modifier = Modifier
            .size(size)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = contentDescription, tint = tint, modifier = Modifier.size(size * 0.54f))
        }
    }
}

@Composable
private fun PlayerMiniPill(text: String, onClick: () -> Unit) {
    Surface(
        color = Color(0x99121216),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, Color(0x28FFFFFF)),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.5.dp)
        )
    }
}

@Composable
private fun WatchInfoSection(
    displayTitle: String,
    displayChannel: String,
    displayChannelId: String,
    displayAvatar: String,
    details: VideoDetails?,
    isLiked: Boolean,
    isSubscribed: Boolean,
    qualityLabel: String,
    speedLabel: String,
    onOpenDescription: () -> Unit,
    onOpenChannel: () -> Unit,
    onToggleSubscribe: () -> Unit,
    onToggleLike: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onOpenPlayerSettings: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenDescription),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = displayTitle,
                color = Color.White,
                fontSize = 17.5.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 23.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val metaLine = listOfNotNull(
                details?.viewCount?.takeIf { it.isNotBlank() },
                details?.publishDate?.takeIf { it.isNotBlank() },
                "more"
            ).joinToString(" · ")
            Text(text = metaLine, color = CinemaColors.TextSecondary, fontSize = 12.5.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onOpenChannel)
            ) {
                ChannelAvatar(url = displayAvatar, name = displayChannel, size = 40.dp)
                Column {
                    Text(
                        text = displayChannel.ifBlank { "Channel" },
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    details?.subscriberCount?.takeIf { it.isNotBlank() }?.let {
                        Text(it, color = CinemaColors.TextSecondary, fontSize = 12.sp)
                    }
                }
            }

            if (displayChannelId.isNotBlank()) {
                Surface(
                    color = if (isSubscribed) Color(0x26FFFFFF) else Color.White,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.clickable(onClick = onToggleSubscribe)
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                WatchActionPill(
                    icon = if (isLiked) Icons.Rounded.ThumbUp else Icons.Rounded.ThumbUpOffAlt,
                    label = details?.likeCount?.takeIf { it.isNotBlank() } ?: "Like",
                    active = isLiked,
                    onClick = onToggleLike
                )
            }
            item { WatchActionPill(icon = Icons.Rounded.BookmarkAdd, label = "Save", onClick = onSave) }
            item { WatchActionPill(icon = Icons.Rounded.Share, label = "Share", onClick = onShare) }
            item { WatchActionPill(icon = Icons.Rounded.HighQuality, label = qualityLabel, onClick = onOpenPlayerSettings) }
            item { WatchActionPill(icon = Icons.Rounded.Speed, label = speedLabel, onClick = onOpenPlayerSettings) }
        }
    }
}

@Composable
private fun WatchActionPill(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) Color.White else CinemaColors.SurfaceElevated,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, if (active) Color.White else CinemaColors.DividerSubtle),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(17.dp))
            Text(label, color = if (active) Color.Black else Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun WatchSheetOverlay(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            color = CinemaColors.GlassStrong,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            border = BorderStroke(1.dp, CinemaColors.GlassStroke),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.68f)
                .navigationBarsPadding()
                .clickable(enabled = false) {}
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp).clip(CircleShape).clickable(onClick = onDismiss).padding(4.dp)
                    )
                }
                HorizontalDivider(color = CinemaColors.DividerSubtle)
                Box(modifier = Modifier.weight(1f)) { content() }
            }
        }
    }
}

@Composable
private fun DescriptionBody(details: VideoDetails?) {
    val desc = details?.description ?: ""
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!details?.title.isNullOrBlank()) {
            Text(details!!.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        val meta = listOfNotNull(
            details?.viewCount?.takeIf { it.isNotBlank() },
            details?.publishDate?.takeIf { it.isNotBlank() }
        ).joinToString(" · ")
        if (meta.isNotBlank()) {
            Text(meta, color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }
        if (desc.isNotBlank()) {
            Text(desc, color = CinemaColors.TextPrimary, fontSize = 13.5.sp, lineHeight = 20.sp)
        } else {
            Text("No description available.", color = CinemaColors.TextSecondary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CommentsListBody(comments: List<CommentItem>, loading: Boolean) {
    when {
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        comments.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No comments available", color = CinemaColors.TextSecondary, fontSize = 14.sp)
        }
        else -> LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(comments) { c ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ChannelAvatar(url = c.avatarUrl, name = c.author, size = 32.dp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(c.author, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (c.publishedTime.isNotBlank()) {
                                Text(c.publishedTime, color = CinemaColors.TextSecondary, fontSize = 11.sp)
                            }
                        }
                        Text(c.text, color = CinemaColors.TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
                        if (c.likeCount.isNotBlank()) {
                            Text("👍 ${c.likeCount}", color = CinemaColors.TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpNextCompactList(related: List<VideoItem>, onSelect: (VideoItem) -> Unit) {
    if (related.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(related, key = { "tn_${it.id}" }) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelect(item) }
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(126.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(CinemaColors.SurfaceElevated)
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (item.duration.isNotBlank()) {
                        Text(
                            text = item.duration,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .background(Color(0xC2000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 1.5.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(item.title, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.channelName, color = CinemaColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

private fun formatPlayerTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
