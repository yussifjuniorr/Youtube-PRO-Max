import java.net.HttpURLConnection
import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Resolve latest stable NewPipeExtractor release at build time so YouTube stream extraction is always up-to-date
val resolvedNewPipeVersion: String = run {
    try {
        val conn = URL("https://api.github.com/repos/TeamNewPipe/NewPipeExtractor/releases/latest")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 6000
        conn.readTimeout = 6000
        conn.setRequestProperty("User-Agent", "CinemaYouTube-GradleBuild")
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        if (conn.responseCode == 200) {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            Regex("\"tag_name\"\\s*:\\s*\"([^\"]+)\"").find(body)?.groupValues?.get(1)
        } else null
    } catch (_: Exception) {
        null
    }
} ?: "v0.24.6"

println("CinemaYouTube: Using NewPipeExtractor $resolvedNewPipeVersion")

android {
    namespace = "com.cinema.youtube"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cinema.youtube.nativeapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "5.0.0"
        multiDexEnabled = true
    }

    signingConfigs {
        create("release") {
            storeFile = file("cinema-release.jks")
            storePassword = "CinemaYT2026!Release"
            keyAlias = "cinema_release"
            keyPassword = "CinemaYT2026!Release"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        release {
            isDebuggable = false
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isDebuggable = true
        }
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE*"
            excludes += "/META-INF/NOTICE*"
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.0.4")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.activity:activity-compose:1.9.0")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // 100% Native Hardware-Accelerated Media3 ExoPlayer + OkHttp HTTP/2 DataSource
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")

    // Proven Open-Source YouTube Stream Extraction Engine (Zero WebView!)
    implementation("com.github.TeamNewPipe:NewPipeExtractor:$resolvedNewPipeVersion")

    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
