# Cinema YouTube Native (v5.0 — 100% Native ExoPlayer + NewPipeExtractor)

Zero YouTube WebView for playback! Built 100% natively with **Kotlin + Jetpack Compose + Media3 ExoPlayer (OkHttp HTTP/2) + NewPipeExtractor**:
- **True Native Ad-Free Playback:** Uses TeamNewPipe's official `NewPipeExtractor` engine (with local JS signature & throttling decryption) feeding hardware-accelerated `Media3 ExoPlayer` (`SurfaceView`) — zero lag, zero WebView crashes, instant seeking, full HD 1080p/720p/480p/360p, and 100% ad-free.
- **Pro Cinema Native Player UI:** Big Play/Pause, ±10s skip, double-tap ±10s with animation, hold-for-2x speed, vertical swipe for brightness & volume, scrubbable YouTube-red seekbar with buffered track, Quality/Speed/Captions/Fit-Zoom settings, seamless Fullscreen rotation without reload, and Picture-in-Picture (PiP).
- **Direct Google Account Sync:** Sign in to sync your real Home feed, Subscriptions, Playlists, and History via SAPISIDHASH.
- **Adaptive Mobile & Tablet UI:** Clean docked Scaffold + Spotlight card on Mobile (`< 600dp`), and Apple TV+ floating glass bar + widescreen Hero + split-screen Watch on Tablet (`>= 600dp`).
